# Reproduction manifest - GOV-CLAUDE-HARNESS-R1-WEB-01

Environment: Claude Code on the Web, version 2.1.332, a fresh single-repository
session on branch `claude/harness-optimization` at
`1f40de942d2ab29a4b1eab42e6bd4259470d39e9` (tree `ec4a1a7b…`), permission mode `auto`.
`<SCRATCH>` is the session scratchpad directory outside the repository. Every probe
target does not exist.

1. Preflight (WEB-01): `git rev-parse --abbrev-ref HEAD`, `git rev-parse HEAD 'HEAD^{tree}'`,
   `git status --porcelain=v1 -uall`, `git rev-parse HEAD:<path>` and
   `git hash-object <path>` for the four R1 files, `claude --version`,
   `git ls-remote origin`, and session metadata (`get_session`).
2. Fix and hash `EXPECTED_RESULTS.json` before any probe
   (sha256 `65146993bbcda26366d2d5137b4c4663398c915aabd0af2f5889b4208bca52cc`,
   2026-11-28T01:16:49Z).
3. Runtime WEB-03, one real tool call each:
   - A: Bash `cd /home/user/aws-terraform-portfolio/docs && rm ../.claude/web01-nonexistent-probe`
   - B: Bash `echo web01 > <SCRATCH>/probe/web01-probe.tfplan.1`
   - C: Bash `echo web01 > /home/user/aws-terraform-portfolio/infra/web01-nonexistent-dir/.terraform.lock.hcl`
   - D: Read `/home/user/aws-terraform-portfolio/README.md` (limit 3)
4. Runtime WEB-04: Read `<SCRATCH>/probe/{web01.tfplan.1, backend_override.tf.json,
   web01.local.tfvars.json, web01.keystore}`, plus one limited re-check, Read
   `<SCRATCH>/probe/web01-control.txt`.
5. Direct input (not runtime evidence): `python3 -B raw/direct_guard.py <SCRATCH> <out.json>`
   sends 12 synthetic events to the unmodified guard. Also
   `python3 -B .claude/hooks/pre_tool_guard.py --self-test`.
6. WEB-05: no runtime probe; supporting static string search of the CLI binary for
   `onFailure`.
7. WEB-06 and WEB-07: observation of the runtime-provided skill and agent lists, and
   the `effort_level` in session metadata.

Expected and actual decisions are in `EXPECTED_RESULTS.json` and
`ACTUAL_WEB_RESULTS.json`. Runtime denial messages are transcribed verbatim from the
session's tool results.
