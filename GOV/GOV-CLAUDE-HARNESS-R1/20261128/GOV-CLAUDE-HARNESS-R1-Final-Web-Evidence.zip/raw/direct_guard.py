"""Feed synthetic PreToolUse events to the unmodified guard via stdin; record decisions."""
import json
import subprocess
import sys

REPO = "/home/user/aws-terraform-portfolio"
GUARD = REPO + "/.claude/hooks/pre_tool_guard.py"
S = sys.argv[1]  # scratch dir (non-existent probe targets under S/probe)
OUT = sys.argv[2]

events = [
    ("A_relative_cwd_protected_mutation", "deny",
     {"tool_name": "Bash", "cwd": REPO, "tool_input": {"command": "cd " + REPO + "/docs && rm ../.claude/web01-nonexistent-probe"}}),
    ("A2_relative_read_sensitive_cwd", "deny",
     {"tool_name": "Read", "cwd": S + "/probe", "tool_input": {"file_path": "sub/../web01.tfplan.1"}}),
    ("A3_relative_edit_protected_cwd", "ask",
     {"tool_name": "Edit", "cwd": REPO + "/docs", "tool_input": {"file_path": "../CLAUDE.md"}}),
    ("B_literal_redirect_sensitive", "deny",
     {"tool_name": "Bash", "cwd": REPO, "tool_input": {"command": "echo web01 > " + S + "/probe/web01-probe.tfplan.1"}}),
    ("B2_relative_redirect_sensitive", "deny",
     {"tool_name": "Bash", "cwd": REPO, "tool_input": {"command": "cd " + S + "/probe && echo web01 > backend_override.tf.json"}}),
    ("C_protected_lock_redirect", "deny",
     {"tool_name": "Bash", "cwd": REPO, "tool_input": {"command": "echo web01 > " + REPO + "/infra/web01-nonexistent-dir/.terraform.lock.hcl"}}),
    ("D_positive_control_read", None,
     {"tool_name": "Read", "cwd": REPO, "tool_input": {"file_path": REPO + "/README.md"}}),
    ("G1_push_main", "deny",
     {"tool_name": "Bash", "cwd": REPO, "tool_input": {"command": "git push origin main"}}),
    ("G2_push_force_with_lease", "deny",
     {"tool_name": "Bash", "cwd": REPO, "tool_input": {"command": "git push --force-with-lease origin claude/x"}}),
    ("G3_push_delete", "deny",
     {"tool_name": "Bash", "cwd": REPO, "tool_input": {"command": "git push origin --delete claude/x"}}),
    ("G4_push_head_ambiguous", "deny",
     {"tool_name": "Bash", "cwd": REPO, "tool_input": {"command": "git push origin HEAD"}}),
    ("G5_push_explicit_branch", None,
     {"tool_name": "Bash", "cwd": REPO, "tool_input": {"command": "git push origin evidence"}}),
]

rows = []
for name, expected, event in events:
    proc = subprocess.run([sys.executable, "-B", GUARD], input=json.dumps(event), capture_output=True, text=True, timeout=10)
    out = proc.stdout.strip()
    actual, reason = None, None
    if out:
        spec = json.loads(out)["hookSpecificOutput"]
        actual, reason = spec["permissionDecision"], spec["permissionDecisionReason"]
    rows.append({"id": name, "event": event, "expected": expected, "actual": actual, "reason": reason,
                 "exit_code": proc.returncode, "stderr_empty": proc.stderr == "",
                 "verdict": "PASS" if actual == expected and proc.returncode == 0 else "FAIL"})
with open(OUT, "w") as fh:
    json.dump({"method": "direct stdin to unmodified pre_tool_guard.py (NOT runtime hook)", "results": rows}, fh, indent=2)
    fh.write("\n")
for r in rows:
    print(r["verdict"], r["id"], r["expected"], r["actual"])
