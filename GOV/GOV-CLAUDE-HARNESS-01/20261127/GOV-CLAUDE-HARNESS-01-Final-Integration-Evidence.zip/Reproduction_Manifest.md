# Reproduction manifest — GOV-CLAUDE-HARNESS-01-FINAL

Inputs: repository `takayuki-ishida-engineer/aws-terraform-portfolio`, commit
`d1777b777f3c4d7528ee50d587f6607ccca86a32` (base `9987ca5346b08906e3e1ece49ef33873284d8f64`).
Python 3 standard library only. No network, credentials or external packages.

1. Check out the commit and confirm the manifest:
   `git diff --name-status 9987ca5..d1777b7` lists 7 added and 5 modified paths.
2. Guard self-test (normal and optimized):
   `python3 .claude/hooks/pre_tool_guard.py --self-test`
   `python3 -O .claude/hooks/pre_tool_guard.py --self-test`
   Expected `self-test: 27 cases, 0 failures`.
3. Frozen fixtures: `python3 -I harness/run_fixtures.py Frozen_Expected_Fixture_Manifest.json <repo>`
   (and with a trailing `-O`). Expected `"failures": 0`, 71 results, manifest canonical
   SHA-256 `970cdf2e1da1c10062698f1088ae3cf773f51f18065b739a2ec3250a3eca4af7`.
   The same fixtures are embedded in `scripts/ci/test_ci.py` (`GUARD_FIXTURES`, digest-pinned).
4. CI checks: `python3 scripts/ci/impact.py check`, `python3 scripts/ci/pr_safety_workflow.py --check`,
   `python3 scripts/ci/safety_checks.py workflows|secrets|guards`,
   `python3 scripts/repository-hygiene/check_tracked_files.py`.
5. CI policy regression: the `ci_policy` step body of `.github/workflows/terraform-offline-ci.yml`
   (`python3 scripts/ci/runtime_test_runner.py --clean-python-stdin` with `test_ci`) in a
   credential-free environment (`KUBECONFIG=/dev/null`, `PYTHONDONTWRITEBYTECODE=1`,
   `AWS_*_FILE=/dev/null`). Expected 73 tests, 97 mutations.
6. Hosted CI: the PR #108 runs listed in `CI_Results.json`.
7. Web runtime: start a fresh single-repository Claude Code on the Web session on the
   commit and repeat the twelve read-only steps recorded in `Fresh_Web_Session_Evidence.json`.

The harness scripts used here are under `harness/` in this package.
