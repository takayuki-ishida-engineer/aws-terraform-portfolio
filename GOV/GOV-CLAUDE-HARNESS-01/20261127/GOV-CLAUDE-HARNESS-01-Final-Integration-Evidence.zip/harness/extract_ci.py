"""Extract hosted CI job logs (MCP get_job_logs JSON) and report key lines."""
import json
import re
import sys
from pathlib import Path

out = Path(sys.argv[1])
pairs = [(sys.argv[2], "job_140771049484_PR_Safety_CI_log_via_MCP.txt"),
         (sys.argv[3], "job_140771049437_Full_CI_log_via_MCP.txt")]
keys = re.compile(r"Full CI verdict|CI policy tooling tests passed|tested_tree|Tested tree|merge commit|"
                  r"Ran \d+ tests|Runner Image|Version: 2026|Current runner version|claude-code-harness|"
                  r"verified steps|exactly the selected|Python 3\.|Terraform v|##\[error\]|FAILED|Error:")
for source, name in pairs:
    content = json.loads(Path(source).read_text())["logs_content"]
    (out / name).write_text(content)
    lines = content.splitlines()
    print("==", name, len(lines), "lines")
    shown = 0
    for line in lines:
        if keys.search(line) and shown < 40:
            print(line[:220])
            shown += 1
