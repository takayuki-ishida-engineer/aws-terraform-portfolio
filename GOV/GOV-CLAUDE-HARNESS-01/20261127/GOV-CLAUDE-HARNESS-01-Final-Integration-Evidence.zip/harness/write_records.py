"""Write the writer ownership, FIND disposition and rollback evidence records."""
import json
import sys

E = sys.argv[1]
seven = ["CLAUDE.md", ".claude/settings.json", ".claude/hooks/pre_tool_guard.py",
         ".claude/skills/verify-change/SKILL.md", ".claude/skills/evidence-package/SKILL.md",
         ".claude/agents/code-reviewer.md", ".claude/agents/security-reviewer.md"]
ci = ["scripts/ci/impact_map.json", "scripts/ci/test_ci.py", "tests/expected-counts.json",
      ".github/workflows/terraform-offline-ci.yml", "scripts/ci/README.md"]
writer = {
    "record": "Writer ownership delta and release record", "decision": "OD-GOV-CLAUDE-WRITER-01",
    "task": "GOV-CLAUDE-HARNESS-01-FINAL",
    "preflight": {"open_prs": 0, "queued_or_running_ci": 0, "remote_branch_existed": False,
                  "active_writer_or_reservation": "none observed: no open PR, no queued or running workflow; "
                  "unpublished reservations outside GitHub are not visible to this session",
                  "evidence_writer_concurrency": "none observed at preflight; rechecked before publication"},
    "permanent_owner_candidates": {"GOV": seven, "CI-INT": ci},
    "temporary_writer_scope": {"holder": "GOV-CLAUDE-HARNESS-01-FINAL (Claude Code)", "paths": ci,
                               "mode": "bounded, temporary, exact files only; not CI-INT-01 authorization",
                               "release_condition": "released when this PR is merged or closed by Owner decision; "
                               "afterwards only CI-INT owns these paths"},
    "catalog": {"source": "Revision 6 Final Contracts writer_catalog / writer_catalog_r2 (status CANDIDATE); "
                "the immutable Final Plan original is not edited",
                "existing_entries": {".github": "CI-INT EXCLUSIVE", "scripts/ci": "CI-INT EXCLUSIVE",
                                     "AGENTS.md": "GOV EXCLUSIVE"},
                "successor_delta": [{"path": p, "owner": "GOV", "match": "EXACT", "write_mode": "EXCLUSIVE",
                                     "status": "PROPOSED_SUCCESSOR"} for p in seven]},
    "future_obligation": "CI-INT-01 integrates the seven GOV harness paths and this temporary CI writer record "
                         "into its trusted catalog and per-path ownership check (OWN-S1 exactly one owner).",
    "shared_concurrent_writer": "none",
}
find = {
    "FIND-01": {"title": "path normalization", "status": "FIXED",
                "how": "root from the hook file location; event cwd only for relative paths; lexical normpath and "
                       "realpath (symlinks); traversal, nested cwd, outside-repo and missing tails handled; no lstrip",
                "evidence": ["fixtures F38-F41, F48-F50", "self-test"]},
    "FIND-02": {"title": "fail closed on malformed input", "status": "FIXED",
                "how": "per-tool schema validation; any exception denies; unknown tool denies",
                "evidence": ["fixtures M01-M11"]},
    "FIND-03": {"title": "governance protection", "status": "FIXED",
                "how": "expanded protected list (ask for file tools, deny for shell mutation); absolute prohibitions "
                       "deny: main push, force push incl. force-with-lease, merge, destructive Git, AWS/STS/SDK, "
                       "Terraform plan/apply/destroy/import/state, kubectl, Helm cluster ops, credential exposure, "
                       "existing-evidence edits",
                "evidence": ["fixtures F02-F14, F17-F18, F20-F21, F25, F27-F29, F33, F37-F45, F51-F52, F59"]},
    "FIND-04": {"title": "read-only subagents", "status": "FIXED",
                "how": "tools Read, Grep, Glob; disallowedTools Bash, Edit, Write, NotebookEdit; Bash instruction removed",
                "evidence": ["test_ci frontmatter assertion", "fresh-session subagent check"]},
    "FIND-05": {"title": "sensitive file scope", "status": "FIXED",
                "how": "absolute //** Read/Edit deny rules and home credential stores; guard also checks Read/Grep "
                       "paths and Bash readers",
                "evidence": ["fixtures F35-F36, F49, F53-F57", "fresh-session Read deny outside the repository"]},
    "FIND-06": {"title": "verify-change change-set coverage", "status": "FIXED",
                "how": "union of committed, staged, unstaged and untracked paths vs manifest; whitespace and secret "
                       "checks for new files; local checks never replace hosted CI", "evidence": ["SKILL.md diff"]},
    "FIND-09": {"title": "evidence-package delivery", "status": "FIXED",
                "how": "evidence-branch publication under a scoped decision; original/derived separation; exclusion "
                       "records; MANIFEST, SHA256SUMS, inventory, self review; remote re-read",
                "evidence": ["SKILL.md diff"]},
    "FIND-12": {"title": "hook failure handling", "status": "FIXED_IN_CONFIGURATION / RUNTIME_PARTIAL",
                "how": "onFailure block on the command handler with the 10 s timeout; the guard never crashes open",
                "evidence": ["settings.json", "fresh-session startup notices"],
                "limitation": "runtime enforcement of a hook crash or timeout was not exercised; doing so would "
                              "require breaking the active guard"},
}
for key, note in (("FIND-07", "CLAUDE.md corrections of section 10 are applied"),
                  ("FIND-08", "CLAUDE.md corrections of section 10 are applied"),
                  ("FIND-10", "CI governance of sections 13-14 is applied"),
                  ("FIND-11", "CI regression of section 15 is applied")):
    find[key] = {"status": "NOT_IDENTIFIED_IN_RECEIVED_DECISION",
                 "note": "The decision text received by Claude does not define this finding; " + note +
                         ". The reviewer confirms the mapping."}
rollback = {
    "before_commit": "remove only the seven new manifest files individually and `git restore -- <path>` each of "
                     "the five tracked CI files",
    "after_commit": "scoped corrective commit, or a reviewed revert of d1777b777f3c4d7528ee50d587f6607ccca86a32 "
                    "through the normal PR process",
    "prohibited": ["blanket deletion of .claude/", "git reset --hard", "git clean", "force push"],
    "manifest": {"added": seven, "modified": ci},
    "verification": "git diff --name-status origin/main..d1777b77 lists exactly 7 added and 5 modified paths, so a "
                    "revert restores main's content for exactly these paths. Not executed (merge not authorized).",
}
for name, data in (("Writer_Ownership_Delta_and_Release.json", writer), ("FIND_Disposition.json", find),
                   ("Rollback_Manifest.json", rollback)):
    with open(E + "/" + name, "w") as handle:
        json.dump(data, handle, indent=1)
        handle.write("\n")
print("records written")
