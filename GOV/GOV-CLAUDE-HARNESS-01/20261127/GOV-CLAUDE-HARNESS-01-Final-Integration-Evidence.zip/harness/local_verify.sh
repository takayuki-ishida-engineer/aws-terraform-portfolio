#!/usr/bin/env bash
# Local verification for GOV-CLAUDE-HARNESS-01-FINAL (run from the repository root).
set -uo pipefail
S=/tmp/claude-0/-home-user-aws-terraform-portfolio/aa53f046-8e96-5e1c-870c-77c88c8dd8dc/scratchpad/harness2
step() { echo; echo "== $*"; }
rc() { echo "exit=$?"; }
step "identity"; git rev-parse --abbrev-ref HEAD; git rev-parse HEAD origin/main
step "AGENTS.md blob unchanged"; echo "worktree $(git hash-object AGENTS.md) main $(git rev-parse origin/main:AGENTS.md)"
step "change set (union) vs manifest"
{ git diff --name-only origin/main; git diff --cached --name-only; git ls-files --others --exclude-standard; } | sort -u > "$S/changed_paths.txt"
cat "$S/changed_paths.txt"
printf '%s\n' .claude/agents/code-reviewer.md .claude/agents/security-reviewer.md .claude/hooks/pre_tool_guard.py \
  .claude/settings.json .claude/skills/evidence-package/SKILL.md .claude/skills/verify-change/SKILL.md \
  .github/workflows/terraform-offline-ci.yml CLAUDE.md scripts/ci/README.md scripts/ci/impact_map.json \
  scripts/ci/test_ci.py tests/expected-counts.json | sort > "$S/manifest_paths.txt"
diff "$S/manifest_paths.txt" "$S/changed_paths.txt" && echo "MANIFEST MATCH (12 paths)"; rc
step "syntax"
python3 -m json.tool .claude/settings.json >/dev/null; rc
python3 -m json.tool scripts/ci/impact_map.json >/dev/null; rc
python3 -m json.tool tests/expected-counts.json >/dev/null; rc
python3 -c "import sys; sys.path.insert(0,'kubernetes/vendor/pyyaml'); import yaml; yaml.safe_load(open('.github/workflows/terraform-offline-ci.yml'))"; rc
python3 -m py_compile .claude/hooks/pre_tool_guard.py scripts/ci/test_ci.py; rc
cmp .claude/settings.json "$S/candidate/settings.json" && echo "settings = candidate"
step "guard self-test"; python3 .claude/hooks/pre_tool_guard.py --self-test; rc
python3 -O .claude/hooks/pre_tool_guard.py --self-test; rc
step "frozen fixtures (independent runner)"
python3 -I "$S/tools/run_fixtures.py" "$S/Frozen_Expected_Fixture_Manifest.json" . > "$S/fixtures_repo.json"; rc
python3 -I "$S/tools/run_fixtures.py" "$S/Frozen_Expected_Fixture_Manifest.json" . -O > "$S/fixtures_repo_O.json"; rc
step "CI checks"
for c in "impact.py check" "pr_safety_workflow.py --check" "safety_checks.py workflows" "safety_checks.py secrets" "safety_checks.py guards"; do
  python3 scripts/ci/$c > "$S/check_${c// /_}.log" 2>&1; echo "$c exit=$?"; done
python3 scripts/repository-hygiene/check_tracked_files.py > "$S/check_hygiene.log" 2>&1; echo "hygiene(tracked) exit=$?"
python3 scripts/ci/impact.py explain $(cat "$S/changed_paths.txt") .claude/unknown.json > "$S/explain.jsonl" 2>&1; echo "explain exit=$? (unknown path expected UNMAPPED)"
step "whitespace"
git diff --check origin/main; rc
for f in $(git ls-files --others --exclude-standard); do grep -nE '[[:space:]]+$' "$f" && echo "trailing ws: $f"; done; echo "untracked ws scan done"
step "ci_policy (documented entry point, credential-free env)"
env -i PATH=/usr/bin:/bin HOME="$S/home" KUBECONFIG=/dev/null PYTHONDONTWRITEBYTECODE=1 AWS_EC2_METADATA_DISABLED=true \
  AWS_SHARED_CREDENTIALS_FILE=/dev/null AWS_CONFIG_FILE=/dev/null bash -c '
python3 scripts/ci/runtime_test_runner.py --clean-python-stdin <<'"'"'PYCI'"'"'
import sys, unittest
sys.path.insert(0, "scripts/ci")
from expected_counts import load
import test_ci
expected = load("ci_policy")
result = unittest.TextTestRunner(verbosity=1).run(unittest.defaultTestLoader.loadTestsFromModule(test_ci))
if not result.wasSuccessful() or result.skipped or result.testsRun != expected["tests"] or len(test_ci.MUTATIONS) != expected["mutations"]:
    raise SystemExit("CI policy tooling tests failed, skipped or changed the reviewed counts.")
print("CI policy tooling tests passed:", result.testsRun, "- mutations detected:", len(test_ci.MUTATIONS))
PYCI' > "$S/ci_policy_local.log" 2>&1; echo "ci_policy exit=$?"
tail -4 "$S/ci_policy_local.log"
