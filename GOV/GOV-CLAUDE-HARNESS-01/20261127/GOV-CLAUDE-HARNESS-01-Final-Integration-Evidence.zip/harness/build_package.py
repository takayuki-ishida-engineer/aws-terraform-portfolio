"""Stage, scan and zip the GOV-CLAUDE-HARNESS-01 final integration evidence (outside the repository)."""
import hashlib
import json
import re
import shutil
import sys
import zipfile
from pathlib import Path

S = Path(sys.argv[1])
EV = S / "ev"
NAME = "GOV-CLAUDE-HARNESS-01-Final-Integration-Evidence"
DIST = S / "dist"
DIST.mkdir(exist_ok=True)
(EV / "harness").mkdir(exist_ok=True)
for script in ("freeze_fixtures.py", "run_fixtures.py", "local_verify.sh", "write_records.py", "extract_ci.py",
               "build_package.py"):
    shutil.copyfile(S / "tools" / script, EV / "harness" / script)
shutil.copyfile(S / "candidate" / "pre_tool_guard.py", EV / "harness" / "candidate_pre_tool_guard.py")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


# Fail-closed scan: real credential forms and personal data only (fixture text names variables, never values).
PATTERNS = {
    "aws_access_key_id": r"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b",
    "github_token": r"\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})",
    "private_key_block": "-----BEGIN [A-Z ]*" + "PRIVATE KEY-----",
    "signed_url": "X-Amz-" + "Signature=|[?&]sig=[A-Za-z0-9%]{20,}",
    "personal_mail": r"[A-Za-z0-9._%+-]+@(?:gmail|yahoo|outlook|hotmail|icloud)\.[a-z]{2,}",
}
hits = []
files = sorted(p for p in EV.rglob("*") if p.is_file())
for path in files:
    text = path.read_bytes().decode("utf-8", "replace")
    for label, pattern in PATTERNS.items():
        if re.search(pattern, text):
            hits.append((str(path.relative_to(EV)), label))
if hits:
    raise SystemExit("sensitive content scan failed: %r" % hits)

members = {str(p.relative_to(EV)): {"sha256": sha(p), "bytes": p.stat().st_size} for p in files}
inventory = {
    "artifact": "GOV-CLAUDE-HARNESS-01", "decision": "OD-GOV-CLAUDE-EV-01",
    "public_disclosure": "ELIGIBLE_FOR_PUBLICATION",
    "license_compliance": "PASS_PROJECT_ORIGINAL_AND_DERIVED_METADATA",
    "LC": {"LC-0%d" % i: "PASS" for i in range(1, 7)},
    "scope": "Project-original source patches, test fixtures, verification and CI logs of a public repository, "
             "and derived records. No third-party source, license body, secret, State, plan or credential value.",
    "inventory": [dict(path=k, classification="ELIGIBLE_OWN_ORIGINAL_OR_DERIVED", **v) for k, v in members.items()],
}
(EV / "REDISTRIBUTION_INVENTORY.json").write_text(json.dumps(inventory, indent=1) + "\n")
manifest = {
    "package": NAME, "task": "GOV-CLAUDE-HARNESS-01-FINAL",
    "decisions": ["OD-GOV-CLAUDE-HARNESS-02", "OD-GOV-CLAUDE-HARNESS-01 (previous)", "OD-GOV-CLAUDE-WRITER-01",
                  "OD-GOV-CLAUDE-EV-01", "OD-DELEGATION-01"],
    "policy": {"name": "MASTER_POLICY v15.2", "sha256": "1beba6eb94197247a52718ee05d162dcda27fc6716c809f11643e683714d56e4",
               "verification": "N/A - stated in the decision; the policy file was not supplied to this session"},
    "authorized_scope_digest": "N/A - no machine-readable scope document with a digest was supplied",
    "actor": "Claude Code session (git identity Claude <noreply@anthropic.com>)",
    "branch": "claude/harness-optimization",
    "base": "9987ca5346b08906e3e1ece49ef33873284d8f64 (tree c57429cad1ccc15384116318944c9e6342859350)",
    "head": "d1777b777f3c4d7528ee50d587f6607ccca86a32", "tree": "46ed7fc7c92bc2c935682ac34d2c8bd65f9f72ef",
    "pr": 108, "runs": {"PR Safety CI": [46078280287, 1], "Full CI": [46078280175, 1], "Offline Contracts": [46078280273, 1]},
    "action_identity": ["actions/checkout@3d3c42e5aac5ba805825da76410c181273ba90b1",
                        "hashicorp/setup-terraform@dfe3c3f87815947d99a8997f908cb6525fc44e9e"],
    "required_check_app": "PR Safety CI (App 15368, enforcement everyone) as stated by the Owner; not read back by Claude",
    "fresh_web_session": "session_0194dzts5ts1e8oJ8uUnjJxK",
    "result": {"implementation": "READY FOR INDEPENDENT REVIEW (pre-merge conditions met except independent review "
                                 "and Owner decision)", "setup_complete": "NOT DECLARED",
               "agents_restructuring": "DEFERRED", "token_benchmark": "NOT_TESTED / DEFERRED",
               "token_reduction": "N/A"},
    "frozen_fixture_digest": "970cdf2e1da1c10062698f1088ae3cf773f51f18065b739a2ec3250a3eca4af7",
    "limitations": ["effort level not visible at runtime (UNVERIFIED)",
                    "@AGENTS.md import loading is model self-report",
                    "onFailure runtime enforcement on a crashing hook NOT_TESTED",
                    "Full CI log captured as its last 5,000 lines only (MCP tail bound)",
                    "Offline Contracts job log not captured (metadata only)",
                    "guard Bash rules are text rules, not a parser; documented false positives and evasions",
                    "FIND-07/08/10/11 not defined in the decision text received",
                    "local untracked __pycache__ directories remain under protected paths (not committed)"],
    "redactions": "none required",
    "sensitive_scan": {"patterns": sorted(PATTERNS), "hits": 0},
    "members": members,
}
(EV / "MANIFEST.json").write_text(json.dumps(manifest, indent=1) + "\n")
final = sorted(p for p in EV.rglob("*") if p.is_file())
(EV / "SHA256SUMS").write_text("".join("%s  %s\n" % (sha(p), p.relative_to(EV)) for p in final))
final = sorted(p for p in EV.rglob("*") if p.is_file())
zpath = DIST / (NAME + ".zip")
with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as archive:
    for path in final:
        info = zipfile.ZipInfo(str(path.relative_to(EV)), date_time=(2026, 11, 27, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o644 << 16
        archive.writestr(info, path.read_bytes())
with zipfile.ZipFile(zpath) as archive:
    assert archive.testzip() is None
    count = len(archive.namelist())
print(json.dumps({"zip": str(zpath), "sha256": sha(zpath), "bytes": zpath.stat().st_size, "entries": count,
                  "inventory_sha256": sha(EV / "REDISTRIBUTION_INVENTORY.json")}))
