"""Freeze the expected guard fixture manifest before the guard and test changes."""
import datetime
import hashlib
import json
import sys
from pathlib import Path

OUT = Path(sys.argv[1])


def B(c):
    return {"tool_name": "Bash", "tool_input": {"command": c}}


def E(t, p, **k):
    key = "notebook_path" if t == "NotebookEdit" else "file_path"
    return {"tool_name": t, "tool_input": dict({key: p}, **k)}


TOKEN = "$" + "GH_TOKEN"
cases = [
    ("F01", B("git push -u origin claude/harness-optimization"), "allow"),
    ("F02", B("git push origin main"), "deny"),
    ("F03", B("git push origin HEAD:main"), "deny"),
    ("F04", B("git push --force-with-lease origin claude/x"), "deny"),
    ("F05", B("git push origin +claude/x"), "deny"),
    ("F06", B("gh pr merge 1 --squash"), "deny"),
    ("F07", B("gh pr merge --auto 1"), "deny"),
    ("F08", B("git reset --hard origin/main"), "deny"),
    ("F09", B("git clean -fdx"), "deny"),
    ("F10", B("git branch -D old"), "deny"),
    ("F11", B("aws sts get-caller-identity"), "deny"),
    ("F12", B("terraform -chdir=infra/x apply -auto-approve"), "deny"),
    ("F13", B("terraform plan -out=x"), "deny"),
    ("F14", B("terraform state rm aws_vpc.this"), "deny"),
    ("F15", B("terraform test -no-color"), "allow"),
    ("F16", B("terraform init -backend=false -input=false -lockfile=readonly"), "allow"),
    ("F17", B("kubectl apply -f x.yaml"), "deny"),
    ("F18", B("helm upgrade --install x ./chart"), "deny"),
    ("F19", B("helm template x kubernetes/charts/y"), "allow"),
    ("F20", B("echo " + TOKEN), "deny"),
    ("F21", B("env"), "deny"),
    ("F22", B("env -i PATH=/usr/bin python3 -V"), "allow"),
    ("F23", B("cat infra/services/dev/x/terraform.tfstate"), "deny"),
    ("F24", B("grep -rn tfstate scripts/repository-hygiene"), "allow"),
    ("F25", B("rm -rf /"), "deny"),
    ("F26", B("rm -rf {OUT}/build"), "allow"),
    ("F27", B("sed -i s/a/b/ AGENTS.md"), "deny"),
    ("F28", B("echo x > .claude/settings.json"), "deny"),
    ("F29", B("python3 -c \"open('scripts/ci/impact_map.json','w')\""), "deny"),
    ("F30", B("python3 scripts/ci/impact.py check"), "allow"),
    ("F31", B("git status --porcelain=v1 --untracked-files=all"), "allow"),
    ("F32", B("git diff --name-status --no-renames origin/main...HEAD"), "allow"),
    ("F33", B("rm docs/evidence/emulator-runs/index.md"), "deny"),
    ("F34", B("git apply change.patch"), "ask"),
    ("F35", E("Edit", "{REPO}/infra/services/dev/a/terraform.tfstate"), "deny"),
    ("F36", E("Write", "{REPO}/infra/services/dev/a/local.auto.tfvars"), "deny"),
    ("F37", E("Edit", "{REPO}/AGENTS.md"), "ask"),
    ("F38", E("Edit", "AGENTS.md"), "ask"),
    ("F39", E("Edit", "./CLAUDE.md"), "ask"),
    ("F40", dict(E("Edit", "../AGENTS.md"), cwd="{REPO}/infra"), "ask"),
    ("F41", dict(E("Edit", "ci/impact_map.json"), cwd="{REPO}/scripts"), "ask"),
    ("F42", E("Edit", "{REPO}/.github/workflows/pr-safety-ci.yml"), "ask"),
    ("F43", E("Edit", "{REPO}/infra/services/dev/ca-central-1/network/.terraform.lock.hcl"), "ask"),
    ("F44", E("Edit", "{REPO}/docs/evidence/emulator-runs/index.md"), "deny"),
    ("F45", E("Write", "{REPO}/docs/evidence/emulator-runs/999-attempt-1.json"), "ask"),
    ("F46", E("Edit", "{REPO}/infra/modules/vpc/main.tf"), "allow"),
    ("F47", E("Write", "{OUT}/notes.md"), "allow"),
    ("F48", E("Write", "{OUT}/link-to-agents"), "ask"),
    ("F49", E("Write", "{OUT}/link-state"), "deny"),
    ("F50", E("Write", "{REPO}/infra/../AGENTS.md"), "ask"),
    ("F51", E("Edit", "{REPO}/.claude/hooks/pre_tool_guard.py"), "ask"),
    ("F52", E("Write", "{REPO}/.claude/agents/new.md"), "ask"),
    ("F53", E("Read", "{REPO}/docs/x.tfstate"), "deny"),
    ("F54", E("Read", "{OUT}/.env"), "deny"),
    ("F55", E("Read", "{REPO}/AGENTS.md"), "allow"),
    ("F56", {"tool_name": "Grep", "tool_input": {"pattern": "x", "path": "{REPO}/infra/a/terraform.tfstate"}}, "deny"),
    ("F57", {"tool_name": "Grep", "tool_input": {"pattern": "x", "glob": "*.tfstate"}}, "deny"),
    ("F58", {"tool_name": "Grep", "tool_input": {"pattern": "def", "path": "{REPO}/scripts"}}, "allow"),
    ("F59", E("MultiEdit", "{REPO}/CLAUDE.md"), "ask"),
    ("F60", E("NotebookEdit", "{OUT}/n.ipynb"), "allow"),
]
malformed = [
    ("M01", "", "deny"),
    ("M02", "not json", "deny"),
    ("M03", "[]", "deny"),
    ("M04", '{"tool_input": {}}', "deny"),
    ("M05", '{"tool_name": "Bash", "tool_input": "x"}', "deny"),
    ("M06", '{"tool_name": "Bash", "tool_input": {}}', "deny"),
    ("M07", '{"tool_name": "Edit", "tool_input": {"file_path": ""}}', "deny"),
    ("M08", '{"tool_name": "Edit", "tool_input": {"file_path": "AGENTS.md"}, "cwd": "relative/dir"}', "deny"),
    ("M09", '{"tool_name": "Edit", "tool_input": {"file_path": "a\\u0000b"}}', "deny"),
    ("M10", '{"tool_name": "UnknownTool", "tool_input": {}}', "deny"),
    ("M11", '{"tool_name": "Bash", "tool_input": {"command": 123}}', "deny"),
]
fixtures = {
    "schema": "claude-harness-guard-fixtures/1",
    "default_cwd": "{REPO}",
    "setup": [["symlink", "{OUT}/link-to-agents", "{REPO}/AGENTS.md"], ["symlink", "{OUT}/link-state", "{OUT}/x.tfstate"]],
    "cases": [{"id": i, "event": e, "expect": x} for i, e, x in cases],
    "malformed": [{"id": i, "stdin": s, "expect": x} for i, s, x in malformed],
    "semantics": {"allow": "exit 0, empty stdout", "deny|ask": "exit 0, stdout hookSpecificOutput.permissionDecision"},
}
canon = json.dumps(fixtures, sort_keys=True, separators=(",", ":")).encode()
digest = hashlib.sha256(canon).hexdigest()
(OUT / "Frozen_Expected_Fixture_Manifest.json").write_text(json.dumps(fixtures, indent=1, sort_keys=True) + "\n")
(OUT / "Frozen_Expected_Fixture_Manifest.digest.json").write_text(json.dumps({
    "canonical_sha256": digest, "cases": len(cases), "malformed": len(malformed),
    "frozen_at_utc": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    "frozen_before": "pre_tool_guard.py rewrite and scripts/ci/test_ci.py change"}, indent=1) + "\n")
print(digest, len(cases), len(malformed))
