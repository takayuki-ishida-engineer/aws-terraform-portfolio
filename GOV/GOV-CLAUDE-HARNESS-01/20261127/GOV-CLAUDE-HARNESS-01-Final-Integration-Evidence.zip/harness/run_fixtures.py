"""Run the frozen guard fixtures against a guard inside a given repository root (inert JSON only)."""
import hashlib
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

manifest, repo, flags = Path(sys.argv[1]), Path(sys.argv[2]).resolve(), sys.argv[3:]
fixtures = json.loads(manifest.read_text())
canon = hashlib.sha256(json.dumps(fixtures, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
guard = repo / ".claude/hooks/pre_tool_guard.py"
results, failures = [], 0
with tempfile.TemporaryDirectory() as out:
    out = os.path.realpath(out)

    def sub(value):
        if isinstance(value, str):
            return value.replace("{REPO}", str(repo)).replace("{OUT}", out)
        if isinstance(value, dict):
            return {k: sub(v) for k, v in value.items()}
        return value

    for kind, link, target in fixtures["setup"]:
        os.symlink(sub(target), sub(link))

    def run(stdin):
        p = subprocess.run([sys.executable, *flags, str(guard)], input=stdin, capture_output=True, text=True,
                           timeout=20, env={"PATH": "/usr/bin:/bin", "HOME": out})
        decision = json.loads(p.stdout)["hookSpecificOutput"]["permissionDecision"] if p.stdout.strip() else "allow"
        return p.returncode, decision, p.stdout.strip()

    for case in fixtures["cases"]:
        event = sub(case["event"])
        event.setdefault("cwd", sub(fixtures["default_cwd"]))
        code, got, raw = run(json.dumps(event))
        ok = code == 0 and got == case["expect"]
        failures += not ok
        results.append({"id": case["id"], "expect": case["expect"], "got": got, "exit": code, "ok": ok,
                        "reason": json.loads(raw)["hookSpecificOutput"]["permissionDecisionReason"] if raw else ""})
    for case in fixtures["malformed"]:
        code, got, raw = run(case["stdin"])
        ok = code == 0 and got == case["expect"]
        failures += not ok
        results.append({"id": case["id"], "expect": case["expect"], "got": got, "exit": code, "ok": ok,
                        "reason": json.loads(raw)["hookSpecificOutput"]["permissionDecisionReason"] if raw else ""})
print(json.dumps({"manifest_canonical_sha256": canon, "python_flags": flags, "guard_sha256":
                  hashlib.sha256(guard.read_bytes()).hexdigest(), "total": len(results), "failures": failures,
                  "results": results}, indent=1))
sys.exit(1 if failures else 0)
