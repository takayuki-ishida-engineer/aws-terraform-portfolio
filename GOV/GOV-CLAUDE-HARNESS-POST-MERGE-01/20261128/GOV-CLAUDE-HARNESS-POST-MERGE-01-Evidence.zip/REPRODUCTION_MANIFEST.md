# Verification reproduction

On the merged tree use the existing checkout and run:

```sh
python3 scripts/ci/merge_check.py --squash 6226b5cd8cb14df685803bd1fbd9a71712744803 --reviewed-head 1f40de942d2ab29a4b1eab42e6bd4259470d39e9 --base 9987ca5346b08906e3e1ece49ef33873284d8f64 --verified-tree ec4a1a7b6dfb2cbded2d9614ab6b9f0769a6d6c5 --evidence pull_request
```

The local command used Python's -B flag to avoid bytecode writes. Read PR 108, main, harness and evidence branch refs from the GitHub API. CI readback identifies run 46094155578, attempt 1, job 140821582857. The fixed prior R1 artifact is referenced by commit, path, blob and SHA-256 in POST_MERGE_VERIFICATION.json.
