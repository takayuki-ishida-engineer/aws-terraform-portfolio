#!/usr/bin/env python3
"""Generate M1-TRUST-CLAUDE-01 evidence documents. Usage: build_trust_docs.py <trust_dir>"""
import datetime, json, os, sys

T = sys.argv[1]; PKG = os.path.join(T, "pkg")
raw = [json.loads(l) for l in open(os.path.join(PKG, "raw_probes.jsonl"), encoding="utf-8")]
disc = json.loads(raw[0]["stdout"])
refs = json.load(open(os.path.join(T, "existing_refs.json")))
for r in refs: r["entries"] = len(r["entries"])
now = datetime.datetime.now(datetime.timezone.utc)
def w(n, o):
    with open(os.path.join(PKG, n), "w", encoding="utf-8") as f: json.dump(o, f, ensure_ascii=False, indent=1); f.write("\n")
def until(s):
    d = datetime.datetime.fromisoformat(s.replace("Z", "+00:00")) - now
    return {"utc": s, "passed": d.total_seconds() <= 0, "remaining_hours": round(d.total_seconds() / 3600, 1)}

w("Exact_Baseline.json", {
 "task_id": "M1-TRUST-CLAUDE-01", "decision_id": "OD-M1-TRUST-CLAUDE-01", "publication_decision_id": "OD-M1-TRUST-EV-01",
 "authority": "OD-DELEGATION-01", "authority_text_sha256": "6bb61bcdd7ea92b4ced261bcf73a7ff91d2f55ec97ab4c02f746228df099f26c",
 "authority_digest_source": "MASTER POLICY v15.3 §02 Owner original text",
 "policy": {"version": "v15.3", "pages": 40, "authorized_size_bytes": 4497868,
            "authorized_sha256": "95b69c3065ca40692ec95aae254298bd98a808f773f7f5cdc0dc4e7ae160df19",
            "verification": "Prefix 4497868 bytes of the received upload re-hashed this task: match. Received file not modified.",
            "sections_applied": ["02", "03", "04", "05", "06", "09", "10", "18", "26", "27", "27-A"]},
 "repository": "takayuki-ishida-engineer/aws-terraform-portfolio",
 "main_head": "6226b5cd8cb14df685803bd1fbd9a71712744803", "main_tree": "ec4a1a7b6dfb2cbded2d9614ab6b9f0769a6d6c5",
 "evidence_head": "62f129642e110ca433473046deb2f7bd2b547952", "evidence_tree": "fe5bf81bcbf230828966e727c5624ffd35e87436",
 "evidence_tracked_files": 79, "evidence_index_records": 27, "open_pull_requests": 0, "worktree_tracked_changes": 0,
 "session_identity": "Claude Code on the web, session_0194dzttqawYxD4BrcRhGj5y — SAME session as M1-ENV-CLAUDE-01 (not a new session; the agent cannot start a new session). Local branch claude/great-bell-8t4hyf at main HEAD, no commits.",
 "effective_environment": "As M1-ENV-CLAUDE-01 ENV-01 (Ubuntu 24.04.5, x86_64, kernel 6.18.44-fc-v880, Claude Code 2.1.332, uid 0); environment probes not re-run.",
 "writer_state": "No open PR; evidence HEAD equals baseline; single writer = this session",
 "execution_utc": now.isoformat()})

w("Existing_Evidence_References.json", {"fixed_evidence_commit": "62f129642e110ca433473046deb2f7bd2b547952", "artifacts": refs,
 "byte_availability": {
  "available_here": "Receipts (sizes, SHA-256, versions, expiries, claim hashes, results) in WP-06/WP-07 public ZIPs; ENV qualification package.",
  "NOT_available_here": ["TUF root v14/v15/v16, timestamp v845, snapshot v166, targets v14 bodies", "trusted_root.json body",
                         "four Sigstore bundle bodies and embedded certificates", "release-cosign.pub / artifact.pub bodies",
                         "Cosign 3.1.6 and Grype 0.122.1 binaries/archives/checksum files"],
  "reason": "WP-06/WP-07 Mandatory_Self_Review: bodies retained in Codex private scratch, excluded from public ZIPs.",
  "rule": "Receipts are not treated as acquired bytes."},
 "not_performed": ["518 license identities", "scanner re-acquisition", "Final Plan search", "re-run of WP-07 mathematical checks", "re-run of ENV probes"]})

nodes = [
 {"node": "initial_anchor (Sigstore TUF root v14 bootstrap)", "class": "historical_evidence_only", "basis": "WP-07 receipt sha256 a0dfcc5d…22e2; authenticity source ET-A scoped to that Codex run; body absent here", "depends_on": ["distribution_channel"]},
 {"node": "root_rotation (v15, v16; old+new thresholds)", "class": "historical_evidence_only", "basis": "WP-07 historical log record; no verifier re-check", "depends_on": ["initial_anchor", "verifier_identity"]},
 {"node": "delegated_roles / targets v14", "class": "historical_evidence_only", "basis": "WP-07 receipt 6a697f7f…1acd", "depends_on": ["root_rotation"]},
 {"node": "authenticated_timestamp (TUF timestamp v845, snapshot v166)", "class": "historical_evidence_only", "basis": "receipts; current freshness unverified; expiry 2026-12-03T07:21:51Z", "depends_on": ["root_rotation", "distribution_channel"]},
 {"node": "distribution_channel (tuf-repo-cdn.sigstore.dev, github.com release assets over TLS)", "class": "unresolved", "basis": "Codex transport historical; Claude transport TRUST-03 NOT_QUALIFIED (RB-03)", "depends_on": ["tls_ca_trust_source"]},
 {"node": "tls_ca_trust_source", "class": "unresolved", "basis": "Agent proxy CA bundle (platform-provided); wrong-anchor negative INCONCLUSIVE and not repeatable", "depends_on": []},
 {"node": "publisher_identity (Cosign: Google OIDC email SAN; Grype: GitHub Actions OIDC URI SAN; Cosign KMS key)", "class": "historical_evidence_only", "basis": "WP-07 certificate claims MATCH_UNVALIDATED; KMS key bound to targets v14 by digest", "depends_on": ["fulcio_chain", "delegated_roles / targets v14"]},
 {"node": "fulcio_chain / CT", "class": "unresolved", "basis": "never verified", "depends_on": ["initial_anchor", "verifier_identity"]},
 {"node": "rekor_inclusion / checkpoint", "class": "unresolved", "basis": "only key-id/time-range metadata association", "depends_on": ["initial_anchor", "verifier_identity"]},
 {"node": "artifact_digest (cosign 318a99ad…94c6; grype ELF 322a7839…286b)", "class": "historical_evidence_only", "basis": "WP-06 publisher-digest receipts; bytes absent here", "depends_on": ["publisher_identity"]},
 {"node": "verifier_identity", "class": "unresolved", "basis": "TRUST-02: no full verifier present; custom Python verifier excluded; old Cosign prohibited", "depends_on": ["verifier_provenance"]},
 {"node": "verifier_provenance (openssl/gpgv/python cryptography)", "class": "local_consistency_only", "basis": "dpkg identity only; pip cryptography unattested; no apt lists or debs", "depends_on": []}]
w("Trust_Dependency_Graph.json", {"nodes": nodes,
 "cycles": ["A verifier obtained over the unqualified channel would need the anchor it is meant to verify (verifier_identity -> distribution_channel -> tls_ca_trust_source -> unresolved); not counted as success.",
            "Bootstrapping the TUF root using a verifier whose own provenance is attested only by Sigstore would be circular."],
 "independently_qualified_nodes": 0})

w("Initial_Anchor_Provenance.json", {"verdict": "UNRESOLVED (historical_evidence_only)",
 "candidate_anchor": {"name": "Sigstore TUF root (bootstrap v14 -> v16)", "receipts": "WP-07 Trust_Material_Delta.json existing_chain"},
 "provenance_gaps": ["Bytes absent in this environment", "Original acquisition via Codex transport, scoped to that run (ET-A)",
                     "No independent second channel established", "Transport here not qualified"],
 "existing_trust_roots_in_environment": "System CA store and agent proxy CA bundle exist but are TLS roots, not Sigstore/TUF anchors; not used."})

w("Verifier_Qualification_Matrix.json", {"verdict": "VERIFIER_BLOCKED", "discovery_utc": disc["utc"], "rows": [
 {"tool": "cosign", "present": False, "status": "ABSENT (old Cosign prohibited regardless)"},
 {"tool": "sigstore-python (module/CLI)", "present": False, "status": "ABSENT"},
 {"tool": "python-tuf / securesystemslib", "present": False, "status": "ABSENT"},
 {"tool": "rekor-cli / slsa-verifier / step / notation / gitsign", "present": False, "status": "ABSENT"},
 {"tool": "openssl", "present": True, "identity": disc["tools"]["openssl"], "semantics": "primitive signature/x509 only; no TUF, Rekor inclusion, CT/SCT policy, Fulcio identity policy", "provenance": "local_consistency_only (dpkg); no apt lists/debs to chain", "status": "NOT_QUALIFIED as full verifier"},
 {"tool": "gpgv / gpg", "present": True, "identity": {"gpgv": disc["tools"]["gpgv"], "gpg": disc["tools"]["gpg"]}, "semantics": "OpenPGP only; not Sigstore/TUF", "provenance": "local_consistency_only", "status": "NOT_APPLICABLE"},
 {"tool": "python cryptography", "present": True, "origin": disc["python_modules"]["cryptography"], "semantics": "primitives only", "provenance": "unattested pip install", "status": "NOT_QUALIFIED"},
 {"tool": "custom Python verifier (prior)", "present": "n/a", "status": "EXCLUDED by instruction"}],
 "candidate_verifiers_not_executed": ["Cosign 3.1.6", "sigstore-python 4.6.0"]})

w("Signature_Identity_Result_Matrix.json", {"note": "No verification re-run. Prior results carried as historical evidence; none promoted.", "rows": [
 {"subject": "cosign-linux-amd64 (KMS bundle)", "math_signature": "PASS (WP-07, historical)", "key_binding": "targets v14 digest (historical)", "publisher_authenticity": "HOLD", "rekor": "UNRESOLVED"},
 {"subject": "cosign-linux-amd64 (keyless)", "math_signature": "PASS (WP-06, embedded cert, historical)", "identity": "Google OIDC / email SAN claim MATCH_UNVALIDATED", "fulcio_ct": "UNRESOLVED", "rekor": "UNRESOLVED", "publisher_authenticity": "HOLD"},
 {"subject": "cosign_checksums.txt", "math_signature": "PASS (historical)", "identity": "MATCH_UNVALIDATED", "publisher_authenticity": "HOLD"},
 {"subject": "grype_0.122.1_checksums.txt", "math_signature": "PASS (historical)", "identity": "GitHub Actions OIDC / URI SAN claim MATCH_UNVALIDATED", "publisher_authenticity": "HOLD"},
 {"subject": "RFC3161 timestamps", "status": "NOT_TESTED (applicability unresolved)"}]})

neg = ["Wrong Artifact Digest", "Wrong Trusted Key", "Wrong Certificate Identity", "Wrong OIDC Issuer", "Invalid Transparency Proof",
       "Invalid or Untrusted Timestamp", "TUF rollback", "TUF freeze", "TUF replay", "TUF expiration"]
w("Positive_Negative_Result_Matrix.json", {"positives": {"full_verification": "NOT_TESTED (VERIFIER_BLOCKED)"},
 "negatives": {n: "NOT_TESTED (no qualified verifier; no bytes)" for n in neg}})

ages = {"grype_0.122.1": until("2026-12-02T14:14:20Z"), "sigstore-python_4.6.0": until("2026-12-06T20:18:35Z"), "cosign_3.1.6": until("2026-12-09T22:06:06Z")}
results = {
 "TRUST-01": {"verdict": "PASS (graph produced) / anchor UNRESOLVED", "independently_qualified_nodes": 0},
 "TRUST-02": {"verdict": "VERIFIER_BLOCKED"},
 "TRUST-03": {"verdict": "TRANSPORT_NOT_QUALIFIED", "detail": {
    "exact_endpoint": "known from evidence (tuf-repo-cdn.sigstore.dev, github.com release assets)",
    "effective_certificate_verification": "NOT_VERIFIED (ENV: wrong-CA run still reported ssl_verify=0)",
    "authenticated_ca_trust_source": "UNRESOLVED (agent proxy CA bundle; platform-provided)",
    "known_good_transport": "NOT_ESTABLISHED",
    "safe_wrong_anchor_negative": "NOT_TESTED (repeat of harness-denied operation class prohibited)",
    "proxy_direct_route_distinction": "INCONCLUSIVE (RB-03 retained)"},
    "consequence": "No external trust-material fetch performed; offline scope only."},
 "TRUST-04": {"verdict": "HOLD (Full TUF)", "retained_timestamp_expiry": until("2026-12-03T07:21:51Z"),
              "note": "Unexpired-receipt arithmetic is not current freshness; no current metadata obtained."},
 "TRUST-05": {"verdict": "HOLD (Cosign and Grype publisher trust)"},
 "TRUST-06": {"verdict": "NOT_TESTED (all negatives)"},
 "TRUST-07": {"verdict": "Delta recorded", "gates": {
    "initial_anchor": "UNRESOLVED", "eligible_verifier": "VERIFIER_BLOCKED", "TUF": "HOLD",
    "cosign_publisher_trust": "HOLD", "grype_publisher_trust": "HOLD", "negative_tests": "NOT_TESTED",
    "offline_reproducibility": "NOT_ESTABLISHED (trust-material bodies absent from public evidence and from this environment)",
    "release_age": ages, "version_adoption": "NOT_INCLUDED / NOT_AUTHORIZED"}}}
w("Actual_Result_Matrix.json", {"execution_utc": now.isoformat(), "raw_record_file": "raw_probes.jsonl", "results": results})

w("Compatibility_Delta.json", {"rows": [
 {"item": "Full verifier availability", "codex_wp07": "VERIFIER_BLOCKED", "claude": "VERIFIER_BLOCKED (no cosign/sigstore/tuf present)", "delta": "SAME"},
 {"item": "Trust material bytes", "codex_wp07": "retained in Codex scratch", "claude": "absent (receipts only)", "delta": "WORSE for offline verification"},
 {"item": "Transport", "codex_wp07": "curl GETs reported HTTP 200 (qualification not established)", "claude": "NOT_QUALIFIED (RB-03)", "delta": "NOT_VERIFIED in both"},
 {"item": "Isolation for a future verifier run", "codex_wp07": "Landlock ENOSYS / bwrap uid_map failure", "claude": "Landlock ABI 7, userns available (composed launcher unverified)", "delta": "IMPROVED (ENV) but irrelevant until a verifier is qualified"},
 {"item": "Primitive crypto tools", "codex_wp07": "OpenSSL used for math checks", "claude": "openssl 3.0.13, gpg 2.4.4, python cryptography present", "delta": "SAME class; not full verifiers"}]})

w("Remaining_Blocker_Register.json", {"blockers": [
 {"id": "TB-01", "blocker": "No existing qualified full Sigstore/TUF verifier in Claude environment", "status": "VERIFIER_BLOCKED",
  "unblock_requires": "Separate decision on obtaining a verifier through an independently authenticated channel plus isolation launcher; candidate verifiers under Release Age (sigstore-python 2026-12-06, Cosign 2026-12-09)"},
 {"id": "TB-02", "blocker": "Independent initial anchor", "status": "UNRESOLVED", "unblock_requires": "Second independent channel for Sigstore TUF root bytes and a qualified transport"},
 {"id": "TB-03", "blocker": "Transport qualification (RB-03)", "status": "NOT_QUALIFIED", "unblock_requires": "Decision on an observation method for wrong-anchor negative acceptable to the harness, or an alternate qualified environment"},
 {"id": "TB-04", "blocker": "Trust-material bodies not in public evidence", "status": "OPEN", "unblock_requires": "Redistribution-eligible publication of TUF metadata/bundles (public Sigstore material) by the holder, or re-acquisition after TB-03"},
 {"id": "TB-05", "blocker": "Fulcio/CT, Rekor inclusion/checkpoint, RFC3161", "status": "UNRESOLVED", "unblock_requires": "TB-01..TB-04"},
 {"id": "TB-06", "blocker": "Negative tests", "status": "NOT_TESTED", "unblock_requires": "TB-01"},
 {"id": "TB-07", "blocker": "Release Age", "status": "HOLD (separate gate)", "unblock_requires": "Dates pass AND trust established"},
 {"id": "TB-08", "blocker": "Harness denial: grep of guard source for its file-pattern list", "status": "STOPPED_PENDING_DECISION", "unblock_requires": "ChatGPT decision (see Harness_Denials.json)"}],
 "unchanged_formal_states": {"M1-TOOLS": "HOLD", "CI-INT-01": "HOLD", "INT-00": "HOLD", "OD-HO-06": "NOT AUTHORIZED", "Version Adoption": "NOT AUTHORIZED", "120 Technical Witnesses": "OPEN"}})

w("Harness_Denials.json", {"denials": [{
 "operation": "Read-only grep of .claude/hooks/pre_tool_guard.py to learn which file-name patterns trigger the guard (to avoid accidental denials)",
 "original_command": "grep -nE 'local value file|SENSITIVE|tfstate|\\\\.pem|keyring|gpg' /home/user/aws-terraform-portfolio/.claude/hooks/pre_tool_guard.py | head -20",
 "guard_message": "PreToolUse:Bash hook error: repository guard: state, plan, key, credential or local value file in a shell command",
 "action": "Stopped. Not re-run via Read tool, other expression or route.",
 "decision_needed": "Whether reading the guard's own pattern list is permitted (would only be used to pre-check command wording); no impact on trust verdicts."}]})

w("Reproduction_Manifest.json", {"inputs": {"evidence_commit": "62f129642e110ca433473046deb2f7bd2b547952",
   "zips": [{"path": r["path"], "sha256": r["sha256"], "size": r["size"]} for r in refs]},
 "scripts": ["tools/extract_fixed.py", "tools/verifier_discovery.py", "tools/build_trust_docs.py", "tools/finalize_trust_pkg.py", "tools/rec.py"],
 "commands": [{"test_id": r["test_id"], "label": r["label"], "argv": r["argv"], "exit_code": r["exit_code"]} for r in raw],
 "network_operations": "none for trust material (TRUST-03 not qualified); git fetch/push to repository only for baseline and publication"})
print("ok")
