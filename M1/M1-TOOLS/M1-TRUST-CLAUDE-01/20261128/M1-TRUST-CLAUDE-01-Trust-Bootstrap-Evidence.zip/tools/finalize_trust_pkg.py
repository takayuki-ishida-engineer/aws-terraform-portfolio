#!/usr/bin/env python3
"""Finalize M1-TRUST-CLAUDE-01 package: copy tools, confidentiality scan, inner inventory/MANIFEST/SHA256SUMS,
deterministic ZIP, outer SHA256SUMS + inventory. Usage: finalize_trust_pkg.py <trust_dir> <out_dir>"""
import hashlib, json, os, re, shutil, sys, zipfile

T, OUT = sys.argv[1], sys.argv[2]
PKG = os.path.join(T, "pkg")
dst = os.path.join(PKG, "tools")
if os.path.exists(dst): shutil.rmtree(dst)
shutil.copytree(os.path.join(T, "tools"), dst, ignore=shutil.ignore_patterns("__pycache__"))
def files():
    return sorted(os.path.relpath(os.path.join(r, f), PKG) for r, _, fs in os.walk(PKG) for f in fs)
SCANNER_SELF = "tools/finalize_trust_pkg.py"
pat = re.compile(r"(AKIA[0-9A-Z]{16}|ASIA[0-9A-Z]{16}|-----BEGIN [A-Z ]*PRIVATE|ghp_[A-Za-z0-9]{20,}|gho_[A-Za-z0-9]{20,}|github_pat_|sk-ant-|xox[bpa]-|Bearer [A-Za-z0-9._-]{20,}|[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+\.[A-Za-z0-9.-]*[a-z]{2,})", re.I)
hits = [(f, m.group(0)[:12]) for f in files() if f != SCANNER_SELF
        for m in pat.finditer(open(os.path.join(PKG, f), encoding="utf-8", errors="replace").read())]
if hits: print("CONFIDENTIALITY HITS", hits); sys.exit(2)
def sha(p): return hashlib.sha256(open(p, "rb").read()).hexdigest()
for g in ("MANIFEST.json", "SHA256SUMS", "REDISTRIBUTION_INVENTORY.json"):
    p = os.path.join(PKG, g)
    if os.path.exists(p): os.remove(p)
content = files()
inv = {"files": [{"path": f, "size_bytes": os.path.getsize(os.path.join(PKG, f)), "sha256": sha(os.path.join(PKG, f)),
                  "classification": "Project-authored record, script, or captured output of existing tools (read-only discovery)",
                  "third_party_content": "none", "redistribution": "ELIGIBLE"} for f in content],
       "excluded_not_held": ["TUF metadata bodies, trusted_root.json, Sigstore bundles, certificates, public keys, candidate binaries: not present in this environment (receipts referenced only)"],
       "excluded_referenced": ["MASTER POLICY PDF (digest only)", "WP-06/WP-07/ENV ZIPs (fixed commit/digest only)"]}
open(os.path.join(PKG, "REDISTRIBUTION_INVENTORY.json"), "w").write(json.dumps(inv, indent=1) + "\n")
man = {"task_id": "M1-TRUST-CLAUDE-01", "decision_id": "OD-M1-TRUST-CLAUDE-01", "publication_decision_id": "OD-M1-TRUST-EV-01",
       "authority": "OD-DELEGATION-01", "baseline": {"main_head": "6226b5cd8cb14df685803bd1fbd9a71712744803", "main_tree": "ec4a1a7b6dfb2cbded2d9614ab6b9f0769a6d6c5",
       "evidence_head": "62f129642e110ca433473046deb2f7bd2b547952", "evidence_tree": "fe5bf81bcbf230828966e727c5624ffd35e87436"},
       "files": [{"path": f, "size_bytes": os.path.getsize(os.path.join(PKG, f)), "sha256": sha(os.path.join(PKG, f))} for f in content + ["REDISTRIBUTION_INVENTORY.json"]]}
open(os.path.join(PKG, "MANIFEST.json"), "w").write(json.dumps(man, indent=1) + "\n")
open(os.path.join(PKG, "SHA256SUMS"), "w").write("".join(f"{sha(os.path.join(PKG, f))}  {f}\n" for f in content + ["REDISTRIBUTION_INVENTORY.json", "MANIFEST.json"]))
os.makedirs(OUT, exist_ok=True)
Z = "M1-TRUST-CLAUDE-01-Trust-Bootstrap-Evidence.zip"; zp = os.path.join(OUT, Z)
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for f in files():
        zi = zipfile.ZipInfo(f, date_time=(2026, 11, 28, 0, 0, 0)); zi.external_attr = 0o644 << 16; zi.compress_type = zipfile.ZIP_DEFLATED
        z.writestr(zi, open(os.path.join(PKG, f), "rb").read())
with zipfile.ZipFile(zp) as z: n = len(z.infolist()); assert z.testzip() is None
zs, zsz = sha(zp), os.path.getsize(zp)
open(os.path.join(OUT, "REDISTRIBUTION_INVENTORY.json"), "w").write(json.dumps({"files": [{"path": Z, "size_bytes": zsz, "sha256": zs, "zip_entry_count": n,
    "classification": "Project-authored trust bootstrap evidence package", "third_party_content": "none", "redistribution": "ELIGIBLE"}],
    "inner_inventory": "REDISTRIBUTION_INVENTORY.json inside ZIP"}, indent=1) + "\n")
open(os.path.join(OUT, "SHA256SUMS"), "w").write(f"{zs}  {Z}\n")
print(json.dumps({"zip": zp, "size": zsz, "sha256": zs, "entries": n, "outer_inventory_sha256": sha(os.path.join(OUT, "REDISTRIBUTION_INVENTORY.json"))}, indent=1))
