#!/usr/bin/env python3
"""TRUST-02 read-only verifier discovery. Executes no candidate binary.
Only `openssl version` (existing distro tool, not a candidate) is executed.
Output: JSON with tool presence, package identity, sha256, python module presence (find_spec, no import),
and presence counts of apt provenance files (no signature verification performed)."""
import datetime, glob, hashlib, importlib.util, json, shutil, subprocess

def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""): h.update(b)
    return h.hexdigest()
def dpkg_owner(p):
    r = subprocess.run(["dpkg", "-S", p], capture_output=True, text=True)
    return r.stdout.strip().split(":")[0] if r.returncode == 0 else None
def dpkg_ver(pkg):
    r = subprocess.run(["dpkg-query", "-W", "-f=${Version}", pkg], capture_output=True, text=True)
    return r.stdout.strip() if r.returncode == 0 else None

out = {"utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "tools": {}, "python_modules": {}}
for t in ("cosign", "sigstore", "rekor-cli", "tuf", "python-tuf", "step", "slsa-verifier", "gpgv", "gpg",
          "openssl", "grype", "trivy", "notation", "gitsign"):
    p = shutil.which(t)
    rec = {"path": p}
    if p:
        rp = __import__("os").path.realpath(p)
        pkg = dpkg_owner(rp)
        rec.update({"realpath": rp, "sha256": sha(rp), "dpkg_package": pkg, "dpkg_version": dpkg_ver(pkg) if pkg else None})
    out["tools"][t] = rec
r = subprocess.run(["openssl", "version", "-a"], capture_output=True, text=True)
out["openssl_version"] = r.stdout.strip().splitlines()[:2]
for m in ("sigstore", "tuf", "securesystemslib", "cryptography", "OpenSSL", "rfc3161ng", "in_toto"):
    s = importlib.util.find_spec(m)
    out["python_modules"][m] = (s.origin if s else None)
out["apt_provenance_presence"] = {
    "lists_InRelease_count": len(glob.glob("/var/lib/apt/lists/*InRelease")),
    "lists_Packages_count": len(glob.glob("/var/lib/apt/lists/*Packages*")),
    "cached_deb_count": len(glob.glob("/var/cache/apt/archives/*.deb")),
    "note": "Presence only. No signature verification performed: archive signing anchor and verifier tool both originate from the same image (circular)."}
print(json.dumps(out, indent=1))
