#!/usr/bin/env python3
"""Read-only extraction of fixed evidence ZIPs at a fixed evidence commit.
Usage: extract_fixed.py <evidence_commit> <out_dir> <path=sha256> ..."""
import hashlib, io, json, os, subprocess, sys, zipfile

REPO = "/home/user/aws-terraform-portfolio"
C, OUT = sys.argv[1], sys.argv[2]
refs = []
for spec in sys.argv[3:]:
    p, want = spec.split("=")
    b = subprocess.check_output(["git", "-C", REPO, "show", f"{C}:{p}"])
    h = hashlib.sha256(b).hexdigest()
    if h != want:
        raise SystemExit(f"DIGEST MISMATCH {p}: {h}")
    z = zipfile.ZipFile(io.BytesIO(b))
    for n in z.namelist():
        if n.startswith("/") or ".." in n.split("/"):
            raise SystemExit("unsafe path " + n)
    d = os.path.join(OUT, os.path.basename(p)[:-4])
    z.extractall(d)
    refs.append({"path": p, "evidence_commit": C, "size": len(b), "sha256": h, "crc_ok": z.testzip() is None,
                 "entries": [(i.filename, i.file_size) for i in z.infolist()]})
print(json.dumps(refs, indent=1))
