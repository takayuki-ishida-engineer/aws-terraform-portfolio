#!/usr/bin/env python3
"""Generate the M1-ENV-CLAUDE-01 evidence documents from recorded probes. Usage: build_docs.py <pkg_dir>"""
import json, os, sys

PKG = sys.argv[1]
SCR = os.path.dirname(PKG.rstrip("/"))
raw = [json.loads(l) for l in open(os.path.join(PKG, "raw_probes.jsonl"), encoding="utf-8")]
existing = json.load(open(os.path.join(SCR, "existing_refs.json")))
def w(name, obj):
    with open(os.path.join(PKG, name), "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=1); f.write("\n")
start, end = raw[0]["start_utc"], raw[-1]["end_utc"]

w("Exact_Baseline.json", {
    "task_id": "M1-ENV-CLAUDE-01", "decision_id": "OD-M1-ENV-CLAUDE-01",
    "publication_decision_id": "OD-M1-ENV-EV-01", "authority": "OD-DELEGATION-01",
    "authority_text_sha256": "6bb61bcdd7ea92b4ced261bcf73a7ff91d2f55ec97ab4c02f746228df099f26c",
    "authority_digest_source": "MASTER POLICY v15.3 §02 (Owner original text, UTF-8 75 bytes, no trailing LF)",
    "policy": {"name": "AWS_Terraform_Portfolio_MASTER_POLICY_20261127_v15_3.pdf", "version": "v15.3", "pages": 40,
               "authorized_size_bytes": 4497868,
               "authorized_sha256": "95b69c3065ca40692ec95aae254298bd98a808f773f7f5cdc0dc4e7ae160df19",
               "received_upload_size_bytes": 4522827,
               "received_upload_sha256": "4409a1f9d798389fe389a50a8f84dc873600bda84b85a501cd56a7fe3f223855",
               "finding": "Received upload = authorized original bytes (exact prefix, 4497868 bytes, SHA-256 match) + 24959-byte PDF incremental update appended in transit adding a C2PA 'Content Credentials' attachment (trailer /Prev 4491273, xref entry at offset 4497868). Policy text was read only from the verified prefix.",
               "sections_applied": ["02", "03", "04", "05", "06", "09", "10", "18", "26", "27", "27-A"]},
    "repository": "takayuki-ishida-engineer/aws-terraform-portfolio",
    "main_head": "6226b5cd8cb14df685803bd1fbd9a71712744803", "main_tree": "ec4a1a7b6dfb2cbded2d9614ab6b9f0769a6d6c5",
    "evidence_head": "522069f62e58e8bb03fd0d27c83a3fc32b9e8c20", "evidence_tree": "9560266c963700d794f3eceef3b393b95c233e66",
    "evidence_tracked_files": 76, "evidence_index_records": 26,
    "open_pull_requests": 0, "worktree_tracked_changes": 0,
    "session_branch": "claude/great-bell-8t4hyf (at main HEAD, no commits)",
    "writer_state": "No open PR, evidence HEAD equals baseline at start; single writer = this session",
    "probe_window_utc": [start, end]})

w("Existing_Failure_Evidence_References.json", {
    "evidence_branch_head": existing["evidence_head"],
    "artifacts": existing["refs"],
    "failure_conditions_reused": {
        "landlock": {"codex_result": "ENOSYS during ABI probe",
                     "source": "M1-SA-01A-R2/M1_SA_01A_R2_Isolation_and_Negative_Regression.json capabilities.landlock; M1-WP-03/track-b/M1_SA_01A_R3_Environment_Capability.json r2_invariants_reused.landlock"},
        "bubblewrap_userns": {"codex_result": "ordinary unprivileged user+net and user+net+IPC+PID fail at uid_map Read-only filesystem",
                              "source": "M1-SA-01A-R2 ... capabilities.bwrap"},
        "independent_observer": {"codex_result": "strace available (syscall level); gdb/dlv/perf/bpftrace unavailable; NO_ELIGIBLE_GO_RUNTIME_OBSERVER",
                                 "source": "M1-SA-01A-R2 capabilities.runtime_debugger; M1-WP-05/Environment_Eligibility_Record.json observer"},
        "runtime_isolation": {"codex_result": "read_isolation unproved, full_IPC unproved; WP-05 container controls NOT_TESTED (NO_RETAINED_LOCAL_IMAGE)",
                              "source": "M1-WP-03 Environment_Capability r2_invariants_reused; M1-WP-05/Inert_Isolation_Witness.json"},
        "docker": {"codex_result": "client+daemon 29.9.2 present (rootless, seccomp builtin, cgroupns self-reported), 0 images",
                   "source": "M1-WP-05/Environment_Eligibility_Record.json"}},
    "not_reused_or_repeated": ["518 license identities (not re-investigated)", "Scanner/Verifier re-acquisition (not performed)", "Final Plan originals (not searched)"]})

def find(tid, label):
    for r in raw:
        if r["test_id"] == tid and r["label"] == label: return r
ll = json.loads(find("ENV-02", "landlock-probe")["stdout"])
sc = json.loads(find("ENV-02", "seccomp-nnp-probe")["stdout"])
nsr = json.loads(find("ENV-03", "ns-root-user-mnt-pid-net-ipc-uts")["stdout"])
nsu = json.loads(find("ENV-03", "ns-unprivileged-nobody")["stdout"])
parent_ns = {"user": "user:[4026531837]", "mnt": "mnt:[4026531832]", "pid": "pid:[4026531836]",
             "net": "net:[4026531833]", "ipc": "ipc:[4026531839]", "uts": "uts:[4026531838]"}

actual = {
 "ENV-01": {"verdict": "PASS", "classification": "SELF_REPORT (platform-provided identity)",
   "os": "Ubuntu 24.04.5 LTS", "arch": "x86_64", "kernel": "Linux 6.18.44-fc-v880 (Firecracker-style microVM kernel; BUILD_SALT 6.1.102-1.182.amzn2023.x86_64)",
   "claude_code_version": "2.1.332 (Claude Code)", "session_identity": "Claude Code on the web, session_0194dzttqawYxD4BrcRhGj5y",
   "cpus": 4, "process_uid_gid": "0/0 (root inside the VM, CapEff 000001fffeffffff)", "pid1_comm": "process_api",
   "utc_identity_timestamp": find("ENV-01", "utc")["stdout"].strip(),
   "not_collected": "full environment, credentials, tokens, personal data"},
 "ENV-02": {"verdict": "PASS",
   "declared": {"session_seccomp": "0 (no filter on session process)", "session_no_new_privs": "0",
                "kconfig": "SECURITY_LANDLOCK=y, SECCOMP_FILTER=y, USER/PID/NET/IPC/UTS_NS=y, SELINUX=y, YAMA not set, APPARMOR not set, BPF_LSM=y",
                "lsm_list_file": "/sys/kernel/security/lsm absent (securityfs not mounted); CONFIG_LSM order string includes landlock",
                "max_user_namespaces": 64271, "unprivileged_bpf_disabled": 2,
                "filesystem": "root / rw on /dev/vda; tool mounts /opt/claude-code, /opt/env-runner ro; no session-level filesystem confinement observed (session is root)"},
   "enforced_measured": {
     "landlock": {"abi": ll["abi_query_return"], "allowed_read": ll["allowed_read"], "denied_read": ll["denied_read"],
                  "independent_observation": "strace: landlock_restrict_self(3,0)=0 then openat(denied/d.txt)=-1 EACCES; openat(allowed/a.txt)=5"},
     "seccomp_filter": {"socket_denied_eperm": sc["socket_denied_eperm"], "child_mode": 2,
                        "independent_observation": "strace: prctl(PR_SET_SECCOMP, SECCOMP_MODE_FILTER)=0; socket(AF_INET)=-1 EPERM"},
     "no_new_privs": {"child_readback": sc["child_nnp_readback"], "parent_unchanged": sc["parent_nnp_unchanged"],
                      "independent_observation": "strace: prctl(PR_SET_NO_NEW_PRIVS,1)=0 in child only"}},
   "note": "Existing session-level seccomp/no_new_privs are NOT in effect (0/0); the controls are available to apply to a launched child. Applied only to forked children; session shell unchanged."},
 "ENV-03": {"verdict": "PASS",
   "bubblewrap": "ABSENT (not installed; not installed by this task)",
   "equivalent_tool": "util-linux unshare 2.39.3-9ubuntu6.6 (/usr/bin/unshare, md5 matches dpkg database; LOCAL consistency only)",
   "root_case": {"ns_distinct_from_parent": {k: nsr["ns"][k] != parent_ns[k] for k in parent_ns}, "pid_inside": nsr["pid"],
                 "uid_map": nsr["uid_map"], "net_ifaces": nsr["net_ifaces"], "private_mount_ro_bind": nsr["ro_bind_rc"] == 0},
   "unprivileged_case": {"launcher": "setpriv --reuid=65534 --regid=65534 --clear-groups --no-new-privs (privilege drop)",
                 "ns_distinct_from_parent": {k: nsu["ns"][k] != parent_ns[k] for k in parent_ns}, "pid_inside": nsu["pid"],
                 "uid_map": nsu["uid_map"], "gid_map": nsu["gid_map"], "setgroups": nsu["setgroups"], "net_ifaces": nsu["net_ifaces"]},
   "observation_note": "Namespace inodes read inside child and compared to parent's recorded inodes; network denial additionally strace-observed (ENV-05)."},
 "ENV-04": {"verdict": "PASS (syscall-level) / NOT_VERIFIED (Go-runtime level)",
   "ptrace": "permitted (YAMA not configured; strace and gdb attach to own descendants succeeded)",
   "strace": "6.8-0ubuntu2, md5 matches dpkg database (LOCAL consistency only)",
   "hidden_action_detected": True,
   "self_report_entries": 3, "observer_detected": ["openat allowed/a.txt", "openat denied/d.txt (omitted from self-report)", "connect 127.0.0.1:9", "vfork+execve /usr/bin/true"],
   "gdb": "present (/usr/bin/gdb, package gdb); starti on synthetic /usr/bin/true succeeded. Not used on any candidate/Go binary.",
   "independence_limit": "Observer and observed share uid 0 in the same VM; independence is process/kernel-ptrace level, not a separate trust domain."},
 "ENV-05": {"verdict": "PARTIAL",
   "filesystem_positive": "Landlock allowed read OK; ro-bind read OK",
   "filesystem_negative": "Landlock denied read EACCES (strace-observed); ro-bind write EROFS (errno 30)",
   "network_negative_in_netns": "DNS getaddrinfo failed (EAI_AGAIN); TCP connect ENETUNREACH (strace-observed); only 'lo' interface (root and unprivileged cases)",
   "network_positive_outside": "curl HEAD https://tuf-repo-cdn.sigstore.dev/root.json via configured proxy with --cacert proxy bundle: HTTP 404, ssl_verify_result=0 (TLS handshake verified; path not present on CDN)",
   "tls_negative": "INCONCLUSIVE: --cacert ISRG_Root_X1 still returned HTTP 404 with ssl_verify_result=0; one verbose recheck was DENIED by the repository harness guard; no further attempt",
   "direct_egress_outside_netns": "INCONCLUSIVE: --noproxy '*' returned HTTP 404; path (direct vs transparent interception) not determined; recheck denied by harness"},
 "ENV-06": {"verdict": "CONTROL_NOT_AVAILABLE (observed)",
   "docker_client": "29.9.3 api 1.56 linux/amd64 (docker-ce-cli)", "docker_daemon": "no socket at /var/run/docker.sock or /run/docker.sock; no dockerd process",
   "operations": {"pull": 0, "build": 0, "run": 0, "daemon_start": 0}}}
w("Actual_Environment_Results.json", {"probe_window_utc": [start, end], "raw_record_file": "raw_probes.jsonl",
                                       "raw_record_count": len(raw), "results": actual})

w("Positive_Negative_Result_Matrix.json", {"rows": [
 {"id": "ENV-02-LL", "control": "Landlock path restriction", "positive": "PASS allowed read", "negative": "PASS denied read EACCES", "independent": "strace PASS"},
 {"id": "ENV-02-SC", "control": "seccomp filter", "positive": "PASS getpid allowed", "negative": "PASS socket EPERM", "independent": "strace PASS"},
 {"id": "ENV-02-NNP", "control": "no_new_privs", "positive": "PASS set+readback in child", "negative": "parent unchanged (0)", "independent": "strace PASS"},
 {"id": "ENV-03-NS-ROOT", "control": "user/mnt/pid/net/ipc/uts ns (root)", "positive": "PASS distinct ns, pid 1, lo only", "negative": "n/a", "independent": "parent ns compare"},
 {"id": "ENV-03-NS-UNPRIV", "control": "unprivileged userns (+mnt/pid/net/ipc/uts) as uid 65534", "positive": "PASS uid_map 0->65534 written", "negative": "n/a", "independent": "parent ns compare"},
 {"id": "ENV-04-OBS", "control": "syscall observer (strace)", "positive": "PASS all reported actions captured", "negative": "PASS hidden action captured", "independent": "is the observer"},
 {"id": "ENV-05-FS", "control": "ro bind mount", "positive": "PASS read", "negative": "PASS write EROFS", "independent": "child report only (NOT strace-observed)"},
 {"id": "ENV-05-NET-NS", "control": "network namespace", "positive": "n/a", "negative": "PASS DNS fail, ENETUNREACH", "independent": "strace PASS (connect)"},
 {"id": "ENV-05-NET-OUT", "control": "public trust endpoint HTTPS with TLS verification", "positive": "PARTIAL HTTP 404 ssl_verify=0", "negative": "INCONCLUSIVE (wrong-CA not rejected; recheck harness-denied)", "independent": "NOT_VERIFIED"},
 {"id": "ENV-06-DOCKER", "control": "existing Docker", "positive": "client only", "negative": "no daemon", "independent": "n/a"}]})

w("Isolation_Control_Matrix.json", {"verdict": "EQUIVALENT_CONTROL_CANDIDATE — individual isolation primitives measured; composed runtime isolation launcher NOT_VERIFIED", "rows": [
 {"control": "Landlock filesystem access control", "codex": "ENOSYS", "claude": "ABI 7, enforced", "status": "SAME_CONTROL_AVAILABLE"},
 {"control": "Bubblewrap", "codex": "present; unprivileged uid_map write failed (read-only filesystem)", "claude": "absent", "status": "CONTROL_NOT_AVAILABLE (same tool)"},
 {"control": "Unprivileged user namespace + uid_map", "codex": "failed", "claude": "util-linux unshare as uid 65534: uid_map 0->65534 written", "status": "EQUIVALENT_CONTROL_CANDIDATE (bwrap-equivalent primitive via unshare)"},
 {"control": "Mount namespace private + ro bind", "codex": "not established", "claude": "ro bind write EROFS", "status": "EQUIVALENT_CONTROL_CANDIDATE"},
 {"control": "PID namespace", "codex": "not established", "claude": "pid 1 inside", "status": "EQUIVALENT_CONTROL_CANDIDATE"},
 {"control": "Network namespace (no external route)", "codex": "not established (seccomp-denied network syscalls used instead)", "claude": "lo only, ENETUNREACH, DNS fail", "status": "EQUIVALENT_CONTROL_CANDIDATE"},
 {"control": "IPC/UTS namespace", "codex": "IPC partially by seccomp", "claude": "distinct ipc/uts ns created", "status": "EQUIVALENT_CONTROL_CANDIDATE; full IPC/FD isolation NOT_VERIFIED"},
 {"control": "seccomp filter + no_new_privs", "codex": "available and used", "claude": "available (child); not on session", "status": "SAME_CONTROL_AVAILABLE"},
 {"control": "Filesystem-wide read isolation", "codex": "unproved", "claude": "Landlock beneath-path read restriction measured on fixtures only", "status": "EQUIVALENT_CONTROL_CANDIDATE; whole-runtime read policy NOT_VERIFIED"},
 {"control": "Resource limits (CPU/mem/pid/time)", "codex": "rlimits read back, saturation not exercised", "claude": "not tested", "status": "NOT_VERIFIED"},
 {"control": "Container isolation (Docker)", "codex": "daemon present, no image", "claude": "no daemon", "status": "CONTROL_NOT_AVAILABLE"},
 {"control": "Composition (ns + Landlock + seccomp + nnp in one launcher on a real candidate)", "codex": "n/a", "claude": "not tested (out of scope: no candidate binary executed)", "status": "NOT_VERIFIED"}]})

w("Independent_Observer_Matrix.json", {"verdict": "Syscall-level Independent Observer: SAME_CONTROL_AVAILABLE and measured (hidden action detected). Go-runtime-level observer: EQUIVALENT_CONTROL_CANDIDATE (gdb present), NOT_VERIFIED.", "rows": [
 {"capability": "ptrace permission", "status": "AVAILABLE (YAMA absent)", "evidence": "strace/gdb on own descendants"},
 {"capability": "process observation (exec/fork)", "status": "PASS", "evidence": "observer/fixture.strace vfork/execve"},
 {"capability": "filesystem access observation", "status": "PASS incl. hidden action", "evidence": "observer/fixture.strace openat denied/d.txt absent from self-report"},
 {"capability": "network access observation", "status": "PASS", "evidence": "fixture connect 127.0.0.1:9; netns connect ENETUNREACH"},
 {"capability": "LSM/seccomp enforcement observation", "status": "PASS", "evidence": "observer/landlock.strace, observer/seccomp.strace"},
 {"capability": "Go-runtime values (provider/delegate/limit/provenance per WP-05)", "status": "NOT_VERIFIED", "evidence": "gdb present; no Go binary observed; no qualified Go observer identity"},
 {"capability": "eBPF/perf/bpftrace", "status": "CONTROL_NOT_AVAILABLE", "evidence": "perf/bpftrace absent; unprivileged_bpf_disabled=2"},
 {"capability": "observer tool trust", "status": "LOCAL_CONSISTENCY_ONLY", "evidence": "binary md5 = dpkg md5sums (same root could alter both)"}],
 "self_report_vs_independent": "Fixture self-report (3 entries) kept separately in observer/fixture.selfreport.json; observer output in observer/fixture.strace."})

w("Codex_vs_Claude_Compatibility_Delta.json", {"rows": [
 {"item": "Landlock", "codex": "ENOSYS", "claude": "ABI 7 enforced", "delta": "RESOLVED_IN_CLAUDE_ENV"},
 {"item": "Unprivileged userns/uid_map (bwrap failure point)", "codex": "uid_map read-only", "claude": "writable for uid 65534 via unshare", "delta": "EQUIVALENT_CONTROL_CANDIDATE (bwrap itself absent)"},
 {"item": "Network isolation", "codex": "seccomp syscall denial", "claude": "network namespace + seccomp both available", "delta": "IMPROVED"},
 {"item": "Syscall observer", "codex": "strace", "claude": "strace (hidden-action detection measured)", "delta": "SAME"},
 {"item": "Go-runtime observer", "codex": "none (gdb/dlv absent)", "claude": "gdb present, unqualified for Go", "delta": "CANDIDATE, NOT_VERIFIED"},
 {"item": "Docker", "codex": "daemon present, 0 images", "claude": "client only, no daemon", "delta": "REGRESSED / NOT_AVAILABLE"},
 {"item": "Session privilege", "codex": "unprivileged sandbox (per failures)", "claude": "uid 0 with full caps in microVM", "delta": "DIFFERENT; isolation must drop privilege explicitly (setpriv measured)"},
 {"item": "Outbound network", "codex": "managed environment", "claude": "agent proxy; direct-egress behaviour INCONCLUSIVE", "delta": "NOT_VERIFIED"}]})

w("Finding_Remaining_Blocker_Matrix.json", {"findings": [
 {"id": "F-01", "severity": "info", "finding": "Uploaded policy PDF carried a 24959-byte appended C2PA incremental update; authorized bytes verified as exact prefix."},
 {"id": "F-02", "severity": "info", "finding": "Session runs as uid 0 with full capabilities; any qualification launcher must drop privileges (setpriv to non-root, no_new_privs) before isolation; measured feasible."},
 {"id": "F-03", "severity": "medium", "finding": "TLS-negative and direct-egress observations INCONCLUSIVE: wrong-CA and --noproxy requests both returned HTTP 404; verbose recheck denied by harness guard (pattern on .pem/CA path)."},
 {"id": "F-04", "severity": "info", "finding": "Tool trust for unshare/strace/gdb is local dpkg consistency only, not independent provenance."}],
 "remaining_blockers": [
 {"id": "RB-01", "blocker": "Composed runtime isolation launcher (ns + Landlock + seccomp + nnp + rlimits + FD/IPC) on a real candidate not verified", "status": "OPEN", "next": "M1-TRUST-CLAUDE-01 / later qualification task scope"},
 {"id": "RB-02", "blocker": "Go-runtime-level Independent Observer (WP-05 requirement)", "status": "NOT_VERIFIED", "next": "evaluate gdb against a qualified Go binary in an authorized task"},
 {"id": "RB-03", "blocker": "TLS-negative / egress-path characterisation", "status": "INCONCLUSIVE", "next": "authorized recheck with observation method acceptable to the harness"},
 {"id": "RB-04", "blocker": "Docker container isolation", "status": "CONTROL_NOT_AVAILABLE", "next": "not required if namespace launcher qualifies"},
 {"id": "RB-05", "blocker": "Bubblewrap specifically", "status": "CONTROL_NOT_AVAILABLE", "next": "unshare-based equivalent candidate"},
 {"id": "RB-06", "blocker": "Resource-limit saturation and full IPC/FD isolation", "status": "NOT_VERIFIED", "next": "later qualification"}],
 "unchanged_formal_states": {"M1-TOOLS": "HOLD", "CI-INT-01": "HOLD", "INT-00": "HOLD", "OD-HO-06": "NOT AUTHORIZED", "120 Technical Witnesses": "OPEN", "Version adoption": "unchanged"}})

w("Harness_Denials.json", {"denials": [
 {"when_utc_approx": "between ENV-05 first attempts and ENV-06", "intended_probe": "ENV-05 verbose recheck of wrong-CA and --noproxy curl requests (one limited recheck)",
  "guard_message": "PreToolUse:Bash hook error: repository guard: state, plan, key, credential or local value file in a shell command",
  "action": "stopped; no alternate route; results recorded INCONCLUSIVE"},
 {"when_utc_approx": "setup (pre-probe)", "intended_probe": "fixture creation and evidence extraction via shell variables",
  "guard_message": "repository guard: ambiguous shell redirection target / ambiguous shell working directory for file operation",
  "action": "re-expressed with literal paths / file-writing tool (same operation, literal target); not a guard bypass of a denied operation class"}]})

w("Reproduction_Manifest.json", {"environment": actual["ENV-01"], "inputs": {
   "fixtures": ["fixtures/allowed/a.txt (SYNTHETIC-ALLOWED-FIXTURE)", "fixtures/denied/d.txt (SYNTHETIC-DENIED-FIXTURE)", "fixtures/robind/r.txt (SYNTHETIC-RO-FIXTURE)"],
   "tools": {"python3": "3.13.18 /usr/local/bin/python3", "unshare": "util-linux 2.39.3-9ubuntu6.6", "setpriv": "util-linux 2.39.3-9ubuntu6.6", "strace": "6.8-0ubuntu2", "gdb": "Ubuntu package gdb", "curl": "/usr/bin/curl", "docker": "docker-ce-cli 29.9.3"},
   "endpoint": "https://tuf-repo-cdn.sigstore.dev (present in M1-WP evidence)"},
  "scripts": ["tools/rec.py", "tools/landlock_probe.py", "tools/seccomp_probe.py", "tools/ns_inner.py", "tools/observed_fixture.py", "tools/extract_existing.py", "tools/build_docs.py"],
  "commands": [{"test_id": r["test_id"], "label": r["label"], "argv": r["argv"], "exit_code": r["exit_code"]} for r in raw],
  "note": "Paths in argv refer to the session scratchpad; fixtures and scripts are included in this package under fixtures/ and tools/."})
print("ok", len(raw))
