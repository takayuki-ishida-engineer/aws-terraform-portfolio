#!/usr/bin/env python3
"""Read-only extraction of selected fixed evidence ZIPs from origin/evidence into scratch."""
import hashlib, io, json, subprocess, sys, zipfile, os

REPO = "/home/user/aws-terraform-portfolio"
OUT = sys.argv[1]
idx = json.loads(subprocess.check_output(["git", "-C", REPO, "show", "origin/evidence:EVIDENCE_INDEX.json"]))
want = {"M1-SA-01A","M1-SA-01A-R1","M1-SA-01A-R2","M1-WP-03","M1-WP-05","M1-WP-06","M1-WP-07","M1-WP-08","M1-WP-09"}
refs = []
for r in idx["artifacts"]:
    if r["task_id"] not in want:
        continue
    p = r["repository_relative_path"]
    b = subprocess.check_output(["git", "-C", REPO, "show", "origin/evidence:" + p])
    h = hashlib.sha256(b).hexdigest()
    ok = (h == r["sha256"] and len(b) == r["size_bytes"])
    z = zipfile.ZipFile(io.BytesIO(b))
    bad = z.testzip()
    d = os.path.join(OUT, r["task_id"])
    for info in z.infolist():
        n = info.filename
        if n.startswith("/") or ".." in n.split("/"):
            raise SystemExit("unsafe path " + n)
    z.extractall(d)
    refs.append({"task_id": r["task_id"], "path": p, "size": len(b), "sha256": h,
                 "index_match": ok, "crc_ok": bad is None, "entries": len(z.infolist())})
json.dump({"evidence_head": subprocess.check_output(["git","-C",REPO,"rev-parse","origin/evidence"]).decode().strip(),
           "refs": refs}, sys.stdout, indent=1)
