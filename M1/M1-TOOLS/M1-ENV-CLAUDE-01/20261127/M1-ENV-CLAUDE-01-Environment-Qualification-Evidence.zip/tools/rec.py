#!/usr/bin/env python3
"""Record one probe: rec.py <out.jsonl> <test_id> <label> -- argv...
Runs argv with a sanitized environment (PATH, HOME, LANG, proxy/CA vars only),
captures exit code, stdout, stderr (truncated to 16 KiB each) and UTC timestamps."""
import datetime, json, os, subprocess, sys

out, tid, label = sys.argv[1], sys.argv[2], sys.argv[3]
assert sys.argv[4] == "--"
argv = sys.argv[5:]
KEEP = ("PATH", "HOME", "LANG", "HTTPS_PROXY", "https_proxy", "NO_PROXY", "no_proxy",
        "SSL_CERT_FILE", "CURL_CA_BUNDLE", "REQUESTS_CA_BUNDLE", "NODE_EXTRA_CA_CERTS")
env = {k: os.environ[k] for k in KEEP if k in os.environ}
t0 = datetime.datetime.now(datetime.timezone.utc).isoformat()
try:
    p = subprocess.run(argv, env=env, capture_output=True, timeout=60, stdin=subprocess.DEVNULL)
    rc, so, se = p.returncode, p.stdout, p.stderr
except FileNotFoundError as e:
    rc, so, se = 127, b"", str(e).encode()
except subprocess.TimeoutExpired as e:
    rc, so, se = 124, e.stdout or b"", (e.stderr or b"") + b"\n[rec] timeout 60s"
t1 = datetime.datetime.now(datetime.timezone.utc).isoformat()
def cut(b):
    s = b.decode("utf-8", "replace")
    return s if len(s) <= 16384 else s[:16384] + "\n[rec] truncated"
rec = {"test_id": tid, "label": label, "argv": argv, "exit_code": rc,
       "stdout": cut(so), "stderr": cut(se), "start_utc": t0, "end_utc": t1,
       "env_keys_passed": sorted(env.keys())}
with open(out, "a", encoding="utf-8") as f:
    f.write(json.dumps(rec, ensure_ascii=False) + "\n")
print(f"[{tid}:{label}] exit={rc}")
print(rec["stdout"][:3000])
if rec["stderr"]:
    print("--stderr--"); print(rec["stderr"][:2000])
