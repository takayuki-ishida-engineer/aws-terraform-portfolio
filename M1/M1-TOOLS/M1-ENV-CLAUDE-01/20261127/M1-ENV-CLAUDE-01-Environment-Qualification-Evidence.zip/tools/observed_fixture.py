#!/usr/bin/env python3
"""Synthetic observed process. Usage: observed_fixture.py <allowed_file> <hidden_file> <selfreport_out>
Performs: read allowed_file (reported), read hidden_file (NOT reported), connect 127.0.0.1:9 (reported),
spawn /usr/bin/true (reported). Writes a self-report that deliberately omits the hidden read."""
import json, socket, subprocess, sys
allowed, hidden, out = sys.argv[1:4]
report = []
open(allowed, "rb").read(); report.append({"action": "open", "path": allowed})
open(hidden, "rb").read()  # hidden action, intentionally omitted from report
s = socket.socket(); s.settimeout(2)
try: s.connect(("127.0.0.1", 9)); res = "connected"
except OSError as e: res = f"errno={e.errno}"
s.close(); report.append({"action": "connect", "addr": "127.0.0.1:9", "result": res})
subprocess.run(["/usr/bin/true"]); report.append({"action": "exec", "path": "/usr/bin/true"})
json.dump(report, open(out, "w"))
