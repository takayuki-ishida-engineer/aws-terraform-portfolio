#!/usr/bin/env python3
"""Seccomp/no_new_privs probe in a forked child only.
Child: prctl(NO_NEW_PRIVS), read back NoNewPrivs, install filter returning EPERM for socket(2)
(x86_64 only; other arch -> KILL), then: getpid (must work) and socket (must fail EPERM).
Parent reads child exit status."""
import ctypes, errno, json, os, socket, struct

libc = ctypes.CDLL(None, use_errno=True)
PR_SET_NO_NEW_PRIVS, PR_SET_SECCOMP, SECCOMP_MODE_FILTER = 38, 22, 2
AUDIT_ARCH_X86_64 = 0xC000003E
RET_ALLOW, RET_KILL = 0x7FFF0000, 0x00000000
RET_ERRNO = 0x00050000 | errno.EPERM
BPF_LD_W_ABS, BPF_JEQ_K, BPF_RET_K = 0x20, 0x15, 0x06
def ins(code, jt, jf, k): return struct.pack("HBBI", code, jt, jf, k)
prog = b"".join([
    ins(BPF_LD_W_ABS, 0, 0, 4),                 # arch
    ins(BPF_JEQ_K, 1, 0, AUDIT_ARCH_X86_64),
    ins(BPF_RET_K, 0, 0, RET_KILL),
    ins(BPF_LD_W_ABS, 0, 0, 0),                 # nr
    ins(BPF_JEQ_K, 0, 1, 41),                   # __NR_socket
    ins(BPF_RET_K, 0, 0, RET_ERRNO),
    ins(BPF_RET_K, 0, 0, RET_ALLOW),
])
class SockFprog(ctypes.Structure):
    _fields_ = [("len", ctypes.c_ushort), ("filter", ctypes.c_void_p)]
pid = os.fork()
if pid == 0:
    try:
        if libc.prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) != 0: os._exit(10)
        nnp = [l for l in open("/proc/self/status") if l.startswith("NoNewPrivs")][0].split()[1]
        if nnp != "1": os._exit(11)
        buf = ctypes.create_string_buffer(prog)
        fp = SockFprog(len(prog) // 8, ctypes.cast(buf, ctypes.c_void_p))
        if libc.prctl(PR_SET_SECCOMP, SECCOMP_MODE_FILTER, ctypes.byref(fp), 0, 0) != 0: os._exit(12)
        sc = [l for l in open("/proc/self/status") if l.startswith("Seccomp:")][0].split()[1]
        if sc != "2": os._exit(13)
        os.getpid()
        try:
            socket.socket(socket.AF_INET, socket.SOCK_STREAM); os._exit(20)
        except PermissionError:
            os._exit(0)
        except OSError:
            os._exit(21)
    except Exception:
        os._exit(99)
_, st = os.waitpid(pid, 0)
rc = os.waitstatus_to_exitcode(st)
parent_nnp = [l for l in open("/proc/self/status") if l.startswith("NoNewPrivs")][0].split()[1]
print(json.dumps({"child_exit": rc, "child_nnp_readback": rc not in (10, 11),
                  "child_seccomp_mode2": rc in (0, 20, 21),
                  "socket_denied_eperm": rc == 0, "parent_nnp_unchanged": parent_nnp}))
