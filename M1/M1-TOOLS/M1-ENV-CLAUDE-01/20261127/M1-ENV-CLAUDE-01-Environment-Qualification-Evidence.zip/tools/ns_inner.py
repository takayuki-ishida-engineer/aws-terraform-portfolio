#!/usr/bin/env python3
"""Runs INSIDE the namespaced child. Usage: ns_inner.py <robind_dir> <mode>
mode=full: also performs read-only bind mount + write negative.
Reports only; the parent independently compares ns inodes."""
import json, os, socket, subprocess, sys

robind, mode = sys.argv[1], sys.argv[2]
r = {"pid": os.getpid(), "uid": os.getuid(), "euid": os.geteuid()}
r["ns"] = {n: os.readlink(f"/proc/self/ns/{n}") for n in ("user", "mnt", "pid", "net", "ipc", "uts")}
for f in ("uid_map", "gid_map", "setgroups"):
    try: r[f] = open(f"/proc/self/{f}").read().strip()
    except OSError as e: r[f] = f"ERR {e.errno}"
try:
    r["net_ifaces"] = [l.split(":")[0].strip() for l in open("/proc/net/dev").read().splitlines()[2:]]
except OSError as e:
    r["net_ifaces"] = f"ERR {e}"
# DNS negative
try:
    socket.getaddrinfo("tuf-repo-cdn.sigstore.dev", 443); r["dns"] = "RESOLVED"
except OSError as e:
    r["dns"] = f"FAILED {type(e).__name__}: {e}"
# TCP negative to the proxy-less public endpoint (literal unreachable since no route) and to loopback
for label, addr in (("public_tcp_1.1.1.1:443", ("1.1.1.1", 443)),):
    s = socket.socket(); s.settimeout(3)
    try: s.connect(addr); r[label] = "CONNECTED"
    except OSError as e: r[label] = f"FAILED errno={e.errno} {e.strerror}"
    finally: s.close()
if mode == "full":
    p = subprocess.run(["mount", "--bind", "-o", "ro", robind, robind], capture_output=True, text=True)
    r["ro_bind_rc"] = p.returncode; r["ro_bind_err"] = p.stderr.strip()
    if p.returncode == 0:
        p2 = subprocess.run(["mount", "-o", "remount,bind,ro", robind], capture_output=True, text=True)
        r["ro_remount_rc"] = p2.returncode; r["ro_remount_err"] = p2.stderr.strip()
    try:
        open(os.path.join(robind, "r.txt"), "rb").read(); r["ro_read"] = "OK"
    except OSError as e: r["ro_read"] = f"FAILED {e.errno}"
    try:
        with open(os.path.join(robind, "write_attempt.txt"), "wb") as f: f.write(b"x")
        r["ro_write"] = "SUCCEEDED"
    except OSError as e:
        r["ro_write"] = f"DENIED errno={e.errno} {e.strerror}"
print(json.dumps(r))
