#!/usr/bin/env python3
"""Landlock probe. Usage: landlock_probe.py <allow_dir> <allowed_file> <denied_file>
Parent queries ABI; if ABI>=1, a forked child sets no_new_privs, restricts itself to
read-only access beneath allow_dir, then tries to read allowed_file and denied_file.
Only the child is restricted. Parent reports child's exit status (independent of child stdout)."""
import ctypes, errno, json, os, struct, sys

libc = ctypes.CDLL(None, use_errno=True)
libc.syscall.restype = ctypes.c_long
SYS_create, SYS_add, SYS_restrict = 444, 445, 446
PR_SET_NO_NEW_PRIVS = 38
LANDLOCK_CREATE_RULESET_VERSION = 1
LANDLOCK_RULE_PATH_BENEATH = 1
# ABI v1 filesystem access rights (bits 0..12)
ALL_V1 = (1 << 13) - 1
READ_FILE, READ_DIR = 1 << 2, 1 << 3

allow_dir, allowed, denied = sys.argv[1:4]
res = {}
abi = libc.syscall(SYS_create, None, ctypes.c_size_t(0), ctypes.c_uint32(LANDLOCK_CREATE_RULESET_VERSION))
e = ctypes.get_errno()
res["abi_query_return"] = abi
res["abi_query_errno"] = errno.errorcode.get(e, e) if abi < 0 else None
if abi < 1:
    res["enforcement"] = "NOT_AVAILABLE"
    print(json.dumps(res)); sys.exit(0)

pid = os.fork()
if pid == 0:
    try:
        attr = struct.pack("Q", ALL_V1)  # handled_access_fs
        buf = ctypes.create_string_buffer(attr)
        rs = libc.syscall(SYS_create, buf, ctypes.c_size_t(len(attr)), ctypes.c_uint32(0))
        if rs < 0: os._exit(10)
        fd = os.open(allow_dir, os.O_PATH | os.O_CLOEXEC)
        pb = struct.pack("=QiI", READ_FILE | READ_DIR, fd, 0)[:12]  # packed u64 + s32
        pbuf = ctypes.create_string_buffer(pb)
        if libc.syscall(SYS_add, ctypes.c_int(rs), ctypes.c_int(LANDLOCK_RULE_PATH_BENEATH), pbuf, ctypes.c_uint32(0)) < 0: os._exit(11)
        if libc.prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) != 0: os._exit(12)
        if libc.syscall(SYS_restrict, ctypes.c_int(rs), ctypes.c_uint32(0)) < 0: os._exit(13)
        code = 0
        try:
            open(allowed, "rb").read();
        except OSError: code |= 1   # allowed read failed (unexpected)
        try:
            open(denied, "rb").read(); code |= 2   # denied read succeeded (unexpected)
        except PermissionError: pass
        except OSError: code |= 4
        os._exit(code)
    except Exception:
        os._exit(99)
_, st = os.waitpid(pid, 0)
rc = os.waitstatus_to_exitcode(st)
res["child_exit"] = rc
res["allowed_read"] = "OK" if rc == 0 or (rc in range(0, 8) and not rc & 1) else "FAILED"
res["denied_read"] = "DENIED" if rc in range(0, 8) and not rc & 6 else "NOT_DENIED_OR_ERROR"
res["enforcement"] = "ENFORCED" if rc == 0 else "NOT_CONFIRMED"
print(json.dumps(res))
