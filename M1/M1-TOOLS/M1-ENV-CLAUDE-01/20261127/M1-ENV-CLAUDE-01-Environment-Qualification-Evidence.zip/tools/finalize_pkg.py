#!/usr/bin/env python3
"""Copy tools/fixtures into pkg, confidentiality scan, write MANIFEST.json, inner SHA256SUMS,
inner REDISTRIBUTION_INVENTORY.json, deterministic ZIP, outer SHA256SUMS and outer inventory.
Usage: finalize_pkg.py <scratch_dir> <out_dir>"""
import hashlib, json, os, re, shutil, sys, zipfile

SCR, OUT = sys.argv[1], sys.argv[2]
PKG = os.path.join(SCR, "pkg")
for sub in ("tools", "fixtures"):
    dst = os.path.join(PKG, sub)
    if os.path.exists(dst): shutil.rmtree(dst)
    shutil.copytree(os.path.join(SCR, sub), dst, ignore=shutil.ignore_patterns("__pycache__"))
# remove fixture write side effects if any (none expected)
assert not os.path.exists(os.path.join(PKG, "fixtures/robind/write_attempt.txt"))

def files():
    out = []
    for root, _, fs in os.walk(PKG):
        for f in fs:
            out.append(os.path.relpath(os.path.join(root, f), PKG))
    return sorted(out)

# confidentiality scan
pat = re.compile(r"(AKIA[0-9A-Z]{16}|ASIA[0-9A-Z]{16}|-----BEGIN [A-Z ]*PRIVATE KEY|ghp_[A-Za-z0-9]{20,}|gho_[A-Za-z0-9]{20,}|github_pat_|sk-ant-|xox[bpa]-|aws_secret_access_key|Bearer [A-Za-z0-9._-]{20,}|[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+\.[A-Za-z0-9.-]*[a-z]{2,})", re.I)
hits = []
for f in files():
    if f == "tools/finalize_pkg.py":  # scanner source: contains only the detection regex literals
        continue
    t = open(os.path.join(PKG, f), encoding="utf-8", errors="replace").read()
    for m in pat.finditer(t): hits.append((f, m.group(0)[:12]))
if hits:
    print("CONFIDENTIALITY HITS", hits); sys.exit(2)

def sha(p): return hashlib.sha256(open(p, "rb").read()).hexdigest()
for gen in ("MANIFEST.json", "SHA256SUMS", "REDISTRIBUTION_INVENTORY.json"):
    p = os.path.join(PKG, gen)
    if os.path.exists(p): os.remove(p)
content = files()
inv = {"files": [{"path": f, "size_bytes": os.path.getsize(os.path.join(PKG, f)), "sha256": sha(os.path.join(PKG, f)),
                  "classification": "Project-authored record, probe source, synthetic fixture or captured output of existing OS tools on synthetic fixtures",
                  "third_party_content": "none (no third-party source, license text, binary or advisory redistributed)",
                  "redistribution": "ELIGIBLE"} for f in content],
       "excluded": ["MASTER POLICY PDF (provided to session; referenced by digest only)", "existing evidence ZIPs (referenced by fixed commit/digest)", "kernel/package binaries (referenced by hash only)"]}
open(os.path.join(PKG, "REDISTRIBUTION_INVENTORY.json"), "w").write(json.dumps(inv, indent=1) + "\n")
manifest = {"task_id": "M1-ENV-CLAUDE-01", "decision_id": "OD-M1-ENV-CLAUDE-01", "publication_decision_id": "OD-M1-ENV-EV-01",
            "authority": "OD-DELEGATION-01", "baseline": {"main_head": "6226b5cd8cb14df685803bd1fbd9a71712744803", "main_tree": "ec4a1a7b6dfb2cbded2d9614ab6b9f0769a6d6c5",
            "evidence_head": "522069f62e58e8bb03fd0d27c83a3fc32b9e8c20", "evidence_tree": "9560266c963700d794f3eceef3b393b95c233e66"},
            "files": [{"path": f, "size_bytes": os.path.getsize(os.path.join(PKG, f)), "sha256": sha(os.path.join(PKG, f))} for f in content + ["REDISTRIBUTION_INVENTORY.json"]]}
open(os.path.join(PKG, "MANIFEST.json"), "w").write(json.dumps(manifest, indent=1) + "\n")
sums = "".join(f"{sha(os.path.join(PKG, f))}  {f}\n" for f in content + ["REDISTRIBUTION_INVENTORY.json", "MANIFEST.json"])
open(os.path.join(PKG, "SHA256SUMS"), "w").write(sums)

os.makedirs(OUT, exist_ok=True)
zname = "M1-ENV-CLAUDE-01-Environment-Qualification-Evidence.zip"
zp = os.path.join(OUT, zname)
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for f in files():
        zi = zipfile.ZipInfo(f, date_time=(2026, 11, 28, 0, 0, 0)); zi.external_attr = 0o644 << 16; zi.compress_type = zipfile.ZIP_DEFLATED
        z.writestr(zi, open(os.path.join(PKG, f), "rb").read())
zs, zsz = sha(zp), os.path.getsize(zp)
with zipfile.ZipFile(zp) as z: n = len(z.infolist()); assert z.testzip() is None
outer_inv = {"files": [{"path": zname, "size_bytes": zsz, "sha256": zs, "zip_entry_count": n,
             "classification": "Project-authored environment qualification evidence package", "third_party_content": "none", "redistribution": "ELIGIBLE"}],
             "inner_inventory": "REDISTRIBUTION_INVENTORY.json inside ZIP"}
open(os.path.join(OUT, "REDISTRIBUTION_INVENTORY.json"), "w").write(json.dumps(outer_inv, indent=1) + "\n")
open(os.path.join(OUT, "SHA256SUMS"), "w").write(f"{zs}  {zname}\n")
print(json.dumps({"zip": zp, "size": zsz, "sha256": zs, "entries": n,
                  "outer_inventory_sha256": sha(os.path.join(OUT, "REDISTRIBUTION_INVENTORY.json"))}, indent=1))
