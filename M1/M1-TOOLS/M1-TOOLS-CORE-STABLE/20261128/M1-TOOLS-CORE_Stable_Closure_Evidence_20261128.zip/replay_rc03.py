#!/usr/bin/env python3
"""Independent, offline replay of recovered RC03 data. Not the Claude executor script.
Usage: python replay_rc03.py RECOVERED.zip EXECUTION.zip CONTINUATION.zip OUTPUT_DIR
Uses only Python stdlib, opens ZIPs read-only, never extracts or accesses network.
"""
import collections, csv, hashlib, io, json, pathlib, re, sys, zipfile
from datetime import datetime, timezone

def sha(b): return hashlib.sha256(b).hexdigest()
def gitblob(b): return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def dump(p,x): p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def verify(z):
    assert z.testzip() is None
    names=z.namelist(); assert len(names)==len(set(names))
    checks={n:h for h,n in (s.split('  ',1) for s in z.read('SHA256SUMS').decode().splitlines() if s)}
    assert set(checks)==set(names)-{'SHA256SUMS'},(set(names)-{'SHA256SUMS'}-set(checks),set(checks)-set(names))
    for n,h in checks.items(): assert sha(z.read(n))==h,n
    manifest=json.loads(z.read("MANIFEST.json"))
    if "files" in manifest: entries=manifest["files"]
    elif "entries" in manifest: entries=manifest["entries"]
    else: entries=[{"path":name,"size_bytes":v["size"],"sha256":v["sha256"]} for name,v in manifest.items()]
    assert {r["path"] for r in entries}==set(names)-{"SHA256SUMS","MANIFEST.json"}
    assert len(entries)==len({r["path"] for r in entries})
    for row in entries:
        payload=z.read(row["path"]); assert len(payload)==row["size_bytes"] and sha(payload)==row["sha256"],row["path"]
    return len(checks)
def ver(v):return v.removeprefix('v')
def rowkey(r):return (r['artifact'],r['source'],r['module'],r['version'],r.get('lock_key'),r.get('replacement_of'),tuple(r['query']) if r['query'] else None)
def go_mod(text):
    req=[]; rep={}; block=None
    for l in text.splitlines():
        l=l.split('//',1)[0].strip()
        if not l:continue
        if l==')':block=None;continue
        if l in ('require (','replace ('):block=l.split()[0];continue
        p=l.split()
        if p[0] in ('require','replace'): kind=p.pop(0)
        else:kind=block
        if kind=='require':
            assert len(p)==2,p;req.append(tuple(p))
        elif kind=='replace':
            j=p.index('=>');assert j==1,p;rep[p[0]]=p[j+1:]
    return req,rep

def main():
    a,b,c,out=sys.argv[1:];out=pathlib.Path(out);out.mkdir(parents=True,exist_ok=True)
    z,e,k=map(zipfile.ZipFile,(a,b,c)); sums=[verify(x) for x in (z,e,k)]
    base='originals/rc03/work/'; read=lambda n:z.read(base+n); j=lambda n:json.loads(read(n))
    result=j('result.json'); inv=j('inventory_rows.json'); findings=j('findings.json')
    for s in result['sources']:
        v=read(s['file']);assert len(v)==s['bytes'] and sha(v)==s['sha256'] and gitblob(v)==s['expected_blob']==s['actual_blob']
    # Reconstruct finite rows independently from the 5 original lock/source files.
    exp=[]; counts={};go_versions={'terraform':('github.com/hashicorp/terraform','v1.17.0','1.26.10'),'provider':('github.com/hashicorp/terraform-provider-aws','v6.72.0','1.27.3'),'helm':('helm.sh/helm/v3','v3.22.1','1.26.9')}
    def add(a,source,module,version,ecosystem,query=True,**kwargs):
        exp.append(dict(artifact=a,source=source,module=module,version=version,query=[ecosystem,module,version] if query else None,**kwargs))
    for a0,(module,v,stdlib) in go_versions.items():
        source=a0+'_go.mod'; req,rep=go_mod(read(source).decode());counts[a0]={'require':len(req),'replace':len(rep)}
        for m,v0 in req:
            r=rep.get(m);add(a0,source,m,v0,'Go',query=not(r and r[0].startswith('.')))
            if r and not r[0].startswith('.'):
                assert len(r)==2;add(a0,source,r[0],r[1],'Go',replacement_of=m)
        add(a0,'main module',module,v,'Go');add(a0,'historical compiled stdlib (WR5)','stdlib',stdlib,'Go')
    for a0 in ('checkout','setup'):
        source=a0+'_package-lock.json'; lock=j(source);n=0
        assert lock['lockfileVersion']==3
        for key,val in lock['packages'].items():
            if not key or val.get('dev',False):continue
            assert 'node_modules/' in key and val.get('version');name=val.get('name') or key.rsplit('node_modules/',1)[-1];add(a0,source,name,val['version'],'npm',lock_key=key);n+=1
        counts[a0]={'nondev':n}
    for m,v in [('PyYAML','6.0.3'),('fastjsonschema','2.21.2')]:add('vendor','kubernetes/dependencies.lock.json',m,v,'PyPI')
    assert collections.Counter(map(rowkey,exp))==collections.Counter(map(rowkey,inv)), 'source-derived inventory mismatch'
    ledger=[json.loads(x) for x in read('http_ledger.jsonl').splitlines()];queries=[]; rawrows=set();details={};reqchecks=0;respchecks=0;httpfiles=set()
    for row in ledger:
        seq=row['seq'];res=row['response_file']; rb=read('http/'+res);assert len(rb)==row['response_bytes'] and sha(rb)==row['response_sha256'];respchecks+=1;httpfiles.add(res)
        header=res.removesuffix('.response')+'.headers';read('http/'+header);httpfiles.add(header)
        if row['request_file']:
            rq=row['request_file'];qb=read('http/'+rq);assert sha(qb)==row['request_sha256'];reqchecks+=1;httpfiles.add(rq)
        if row['label'].startswith('osv_querybatch'):
            assert row['http']=='200' and row['curl_exit']==0
            qs=json.loads(qb)['queries']; rs=json.loads(rb)['results'];assert len(qs)==len(rs)
            for q,r in zip(qs,rs):
                pair=(q['package']['ecosystem'],q['package']['name'],q['version']);queries.append(pair);assert not r.get('next_page_token');
                for vuln in r.get('vulns',[]):rawrows.add((*pair,vuln['id']))
        if row['label'].startswith('osv_vuln_'):
            assert row['http']=='200' and row['curl_exit']==0; d=json.loads(rb);assert d['id']==row['label'].removeprefix('osv_vuln_');details[d['id']]=d
        if row['label']=='kev_catalog':kev=json.loads(rb);kev_sha=sha(rb)
    assert set(queries)=={tuple(r['query']) for r in exp if r['query']} and len(queries)==len(set(queries))
    assert rawrows=={(r['ecosystem'],r['package'],r['version'],r['osv_id']) for r in findings}
    assert set(details)=={r[3] for r in rawrows}
    assert httpfiles=={n.removeprefix(base+'http/') for n in z.namelist() if n.startswith(base+'http/')}
    # Rebuild component incidence from source inventory, not executor's historical_match flag.
    bypair=collections.defaultdict(set)
    for r in exp:
        if r['query']:bypair[tuple(r['query'])].add(r['artifact'])
    # Union alias-connected records within the same package/version/component.
    byscope=collections.defaultdict(list)
    for eco,p,v,id0 in sorted(rawrows):
        for a0 in sorted(bypair[(eco,p,v)]):
            aliases={id0,*details[id0].get('aliases',[])};byscope[(a0,eco,p,ver(v))].append((id0,aliases))
    rows=[]
    for (a0,eco,p,v),parts in sorted(byscope.items()):
        groups=[]
        for id0,aliases in parts:
            hits=[g for g in groups if g['aliases']&aliases];merged={'aliases':set(aliases),'osv_ids':{id0}}
            for g in hits:merged['aliases']|=g['aliases'];merged['osv_ids']|=g['osv_ids'];groups.remove(g)
            groups.append(merged)
        for g in groups:
            cv=sorted(x for x in g['aliases'] if x.startswith('CVE-'));assert len(cv)<=1,(a0,p,v,cv)
            key=cv[0] if cv else sorted(g['osv_ids'])[0]
            rows.append({'component':a0,'ecosystem':eco,'package':p,'version':v,'advisory':key,'osv_ids':sorted(g['osv_ids']),'aliases':sorted(g['aliases'])})
    old=list(csv.DictReader(io.StringIO(e.read('R-C04_Historical_Row_Dispositions.csv').decode('utf-8-sig')))); oldseen=set()
    for x in old:
        matches=[r for r in rows if r['component']==x['finding_id'].split('/')[0] and r['package']==x['package'] and r['version']==ver(x['version']) and x['advisory'] in r['aliases']];assert len(matches)==1,x['finding_id'];r=matches[0];assert 'historical_id' not in r;r['historical_id']=x['finding_id'];r['status']=x['scoped_disposition'];oldseen.add(x['finding_id'])
    assert len(oldseen)==66
    new=[r for r in rows if 'historical_id' not in r]
    kev_ids={x['cveID'] for x in kev['vulnerabilities']}
    for r in rows:r['kev_match']=r['advisory'] in kev_ids
    prior=json.loads(k.read('R-C04_New_Finding_Dispositions.json')); vendor=[r for r in prior['new_rows'] if r['id'].startswith('VENDOR-')]
    for x in vendor:
        rows.append({'component':'terraform','ecosystem':'Go','package':x['dependency'],'version':x['version'],'advisory':x['cve'],'osv_ids':[],'aliases':[x['cve']],'kev_match':x['cve'] in kev_ids,'vendor_id':x['id']})
    raw_component=sum(map(len,byscope.values())); counts_summary={'source_inventory_rows':len(exp),'queryable_source_rows':sum(bool(r['query']) for r in exp),'unique_osv_pairs':len(queries),'query_pairs_hit':len({x[:3] for x in rawrows}),'osv_unique_ids':len(details),'osv_rows':len(rawrows),'component_osv_rows_before_alias_dedup':raw_component,'component_osv_rows_after_alias_dedup':len(rows)-len(vendor),'historical_component_rows_matched':len(oldseen),'new_component_rows_osv':len(new),'vendor_additional_rows':len(vendor),'component_union_minimum':len(rows)}
    report={'classification':'INDEPENDENT_OFFLINE_REPLAY_NOT_ORIGINAL_EXECUTOR','recorded_utc':datetime.now(timezone.utc).isoformat(),'input_zip_sha256':{pathlib.Path(x).name:sha(pathlib.Path(x).read_bytes()) for x in (a,b,c)},'input_zip_sums_verified':sums,'source_fixed_blob_sha256_verified':len(result['sources']),'source_counts':counts,'http_headers':respchecks,'http_response_sha256_verified':respchecks,'http_request_sha256_verified':reqchecks,'http_originals':len(httpfiles),'counts':counts_summary,'kev':{'catalog':kev['catalogVersion'],'sha256':kev_sha,'new_rows_matching':sum(r['kev_match'] for r in rows if 'historical_id' not in r)},'status':'PASS_OFFLINE_REPLAY_ONLY','limitations':['No live source or advisory retrieval; no binary symbol or exploit test.','The original executor scripts were not recovered; this is new independently authored replay code.','Go compiler versions and PyPI inputs use fixed existing records, not new binary build-info verification.','Vendor coverage is not complete; 78 is minimum observed component union, not final population.']}
    dump(out/'R-C03_Independent_Replay.json',report);dump(out/'R-C04_Component_Incidence.json',rows);print(json.dumps(report['counts'],indent=2));print('new rows',[(r['component'],r['package'],r['version'],r['advisory']) for r in rows if 'historical_id' not in r]);print('PASS')
if __name__=='__main__':
    if sys.flags.optimize: raise SystemExit('Python optimization must be disabled for assertions.')
    main()
