#!/usr/bin/env python3
"""Test positive and negative offline replay using temporary derivative copies only."""
import hashlib,json,pathlib,subprocess,sys,tempfile,zipfile
from datetime import datetime,timezone
sha=lambda b:hashlib.sha256(b).hexdigest()
recovered,execution,continuation,output=sys.argv[1:];script=pathlib.Path(__file__).with_name('replay_rc03.py');out=pathlib.Path(output)
with tempfile.TemporaryDirectory() as td:
 p=pathlib.Path(td);results=[]
 def run(name,rec,expected):
  proc=subprocess.run([sys.executable,str(script),str(rec),execution,continuation,str(p/'result')],capture_output=True,text=True)
  assert (proc.returncode==0)==expected,(name,proc.stderr)
  results.append({'test':name,'expected_success':expected,'exit_code':proc.returncode,'actual_success':proc.returncode==0,'diagnostic':proc.stderr.splitlines()[-1] if proc.stderr else 'PASS'})
 def derivative(name,change,refresh=False):
  with zipfile.ZipFile(recovered) as z: data={n:z.read(n) for n in z.namelist()}
  change(data)
  if refresh:
   manifest=json.loads(data['MANIFEST.json']);manifest['files']=[{'path':n,'size_bytes':len(b),'sha256':sha(b)} for n,b in sorted(data.items()) if n not in ('MANIFEST.json','SHA256SUMS')];data['MANIFEST.json']=json.dumps(manifest).encode();data['SHA256SUMS']=''.join(f'{sha(b)}  {n}\n' for n,b in sorted(data.items()) if n!='SHA256SUMS').encode()
  path=p/(name+'.zip')
  with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
   for n,b in data.items():z.writestr(n,b)
  return path
 run('positive_originals',recovered,True)
 prefix='originals/rc03/work/'
 run('negative_missing_http_response',derivative('missing',lambda d:d.pop(prefix+'http/0001_src_terraform.response')),False)
 run('negative_modified_source_even_with_outer_hashes_regenerated',derivative('source',lambda d:d.__setitem__(prefix+'terraform_go.mod',d[prefix+'terraform_go.mod']+b'\n'),True),False)
 def query_mutation(d):
  n=prefix+'http/0006_osv_querybatch_r1_0.request.json';q=json.loads(d[n]);q['queries'][0]['version']='v0.0.0';d[n]=json.dumps(q).encode();ln=prefix+'http_ledger.jsonl';rows=[json.loads(x) for x in d[ln].splitlines()];next(x for x in rows if x['seq']=='0006')['request_sha256']=sha(d[n]);d[ln]=''.join(json.dumps(x)+'\n' for x in rows).encode()
 run('negative_query_pair_changed_with_hashes_regenerated',derivative('query',query_mutation,True),False)
 def missing_row(d):
  n=prefix+'inventory_rows.json';j=json.loads(d[n]);j.pop();d[n]=json.dumps(j).encode()
 run('negative_inventory_row_removed_with_hashes_regenerated',derivative('inventory',missing_row,True),False)
(out/'R-C03_Independent_Replay_Tests.json').write_text(json.dumps({'recorded_utc':datetime.now(timezone.utc).isoformat(),'scope':'Derived temporary copies; originals immutable; no network or exploit test.','tests':results,'pass':len(results)},indent=2)+'\n')
print(json.dumps(results,indent=2))
