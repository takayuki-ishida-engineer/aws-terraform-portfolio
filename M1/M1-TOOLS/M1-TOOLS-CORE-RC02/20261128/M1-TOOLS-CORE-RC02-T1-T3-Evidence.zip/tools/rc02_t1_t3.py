#!/usr/bin/env python3
"""M1-TOOLS-CORE R-C02 T1-T3 (Decision OD-M1-TOOLS-CORE-RC02-T1-T3-20261128).
Usage: rc02_t1_t3.py <work_dir>
Uses only existing tools (curl, gpg, gpgv, dpkg-query, sha256 via hashlib). TLS verification kept.
Every external command is recorded with argv, exit code, stdout, stderr and UTC time in commands.jsonl.
Originals are stored unchanged under <work_dir>/originals/. Stops at first failed mandatory step."""
import datetime, hashlib, json, os, subprocess, sys, tempfile

W = sys.argv[1]
ORIG = os.path.join(W, "originals"); os.makedirs(ORIG, exist_ok=True)
LOG = os.path.join(W, "commands.jsonl")
EXP_FPR = "C874011F0AB405110D02105534365D9472D7468F"
EXP_ZIP = "c168cab7c637a8769fdb90089ddd19de701bc6ff8aca64dc2e2185fe46f59f67"
BASE = "https://releases.hashicorp.com/terraform/1.17.0/"
KEY_URL = "https://www.hashicorp.com/.well-known/pgp-key.txt"
CA = os.environ.get("CURL_CA_BUNDLE") or os.environ.get("SSL_CERT_FILE") or "/root/.ccr/ca-bundle.crt"
res = {"decision": "OD-M1-TOOLS-CORE-RC02-T1-T3-20261128", "started_utc": None, "steps": {}}

def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def run(step, argv, env=None):
    t0 = now()
    p = subprocess.run(argv, capture_output=True, env=env, stdin=subprocess.DEVNULL, timeout=120)
    rec = {"step": step, "argv": argv, "exit_code": p.returncode, "start_utc": t0, "end_utc": now(),
           "stdout": p.stdout.decode("utf-8", "replace")[:20000], "stderr": p.stderr.decode("utf-8", "replace")[:20000]}
    with open(LOG, "a") as f: f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    return p, rec
def sha(path): return hashlib.sha256(open(path, "rb").read()).hexdigest()
def stop(reason):
    res["status"] = "STOPPED"; res["stop_reason"] = reason; res["ended_utc"] = now()
    json.dump(res, open(os.path.join(W, "result.json"), "w"), indent=1); print(json.dumps(res, indent=1)); sys.exit(1)

res["started_utc"] = now()
# ---- T1a environment / TCB
osr = {k: v.strip('"') for k, v in (l.rstrip("\n").split("=", 1) for l in open("/etc/os-release") if "=" in l)}
p, _ = run("T1-env", ["dpkg-query", "-W", "-f=${Package}|${Version}|${Maintainer}|${Status}\n", "gpgv", "gpg", "curl", "ca-certificates"])
p2, _ = run("T1-env", ["dpkg", "-S", "/usr/bin/gpgv", "/usr/bin/gpg", "/usr/bin/curl"])
p3, _ = run("T1-env", ["gpgv", "--version"])
p4, _ = run("T1-env", ["apt-cache", "policy", "gpgv"])
res["steps"]["T1_env"] = {"os": {k: osr.get(k) for k in ("PRETTY_NAME", "ID", "VERSION_ID")},
    "packages": p.stdout.decode().strip().splitlines(), "owners": p2.stdout.decode().strip().splitlines(),
    "gpgv_version_line": p3.stdout.decode().splitlines()[0] if p3.returncode == 0 else None,
    "apt_policy": p4.stdout.decode().strip().splitlines(),
    "md5_vs_dpkg": {}}
for b, pkg in (("/usr/bin/gpgv", "gpgv"), ("/usr/bin/gpg", "gpg")):
    m = hashlib.md5(open(b, "rb").read()).hexdigest()
    lst = open(f"/var/lib/dpkg/info/{pkg}.md5sums").read()
    res["steps"]["T1_env"]["md5_vs_dpkg"][b] = {"sha256": sha(b), "md5": m, "dpkg_md5_match": f"{m}  {b.lstrip('/')}" in lst}
if osr.get("ID") != "ubuntu" or p.returncode != 0:
    stop("Environment is not Ubuntu with dpkg-registered gpgv")

# ---- T2 acquisition (TLS verification kept; proxy allowed per C03a)
files = {"pubkey": ("hashicorp_pgp_public.asc", KEY_URL),
         "sums": ("terraform_1.17.0_SHA256SUMS", BASE + "terraform_1.17.0_SHA256SUMS"),
         "sig": ("terraform_1.17.0_SHA256SUMS.72D7468F.sig", BASE + "terraform_1.17.0_SHA256SUMS.72D7468F.sig")}
acq = {}
for k, (name, url) in files.items():
    out = os.path.join(ORIG, name)
    p, rec = run("T2-get", ["curl", "--fail", "--silent", "--show-error", "--location", "--proto", "=https", "--tlsv1.2",
                            "--max-time", "60", "--cacert", CA, "-o", out,
                            "-w", "http=%{http_code} ssl_verify=%{ssl_verify_result} url_effective=%{url_effective}", url])
    acq[k] = {"file": name, "url": url, "exit_code": p.returncode, "curl_report": p.stdout.decode().strip(),
              "bytes": os.path.getsize(out) if os.path.exists(out) else None,
              "sha256": sha(out) if os.path.exists(out) else None}
    if p.returncode != 0: res["steps"]["T2_acquisition"] = acq; stop(f"Acquisition failed for {name}")
res["steps"]["T2_acquisition"] = acq
res["steps"]["T2_acquisition"]["tls"] = f"curl default verification with CA bundle {CA}; no -k/--insecure"

# ---- T1b fingerprint match (anchor)
home = tempfile.mkdtemp(prefix="gnupg-rc02-", dir=W); os.chmod(home, 0o700)
env = {"PATH": "/usr/bin:/bin", "GNUPGHOME": home, "LANG": "C"}
p, _ = run("T1-fpr", ["gpg", "--batch", "--no-tty", "--with-colons", "--fingerprint", "--show-keys", os.path.join(ORIG, files["pubkey"][0])], env)
keys, cur = [], None
for line in p.stdout.decode().splitlines():
    f = line.split(":")
    if f[0] in ("pub", "sub"): cur = {"type": f[0], "keyid": f[4], "algo": f[3], "created": f[5], "expires": f[6], "caps": f[11]}; keys.append(cur)
    elif f[0] == "fpr" and cur and "fpr" not in cur: cur["fpr"] = f[9]
    elif f[0] == "uid": keys[-1].setdefault("uids", []).append(f[9])
prim = [k for k in keys if k["type"] == "pub"]
res["steps"]["T1_anchor"] = {"keys": keys, "expected_primary_fpr": EXP_FPR,
    "primary_fpr_actual": prim[0]["fpr"] if len(prim) == 1 else None,
    "primary_count": len(prim),
    "match": len(prim) == 1 and prim[0].get("fpr") == EXP_FPR,
    "anchor_basis": "Fingerprint fixed in WP-08 evidence; key bytes accepted only because full primary fingerprint matches"}
if not res["steps"]["T1_anchor"]["match"]: stop("Primary fingerprint mismatch or ambiguous key file")

# ---- T3 gpgv verification with dedicated temporary keyring
kr = os.path.join(home, "hashicorp-keyring.gpg")
p, _ = run("T3-keyring", ["gpg", "--batch", "--no-tty", "--yes", "--output", kr, "--dearmor", os.path.join(ORIG, files["pubkey"][0])], env)
if p.returncode != 0: stop("Keyring creation failed")
p, rec = run("T3-gpgv", ["gpgv", "--status-fd", "1", "--keyring", kr,
                          os.path.join(ORIG, files["sig"][0]), os.path.join(ORIG, files["sums"][0])], env)
status = [l for l in p.stdout.decode().splitlines() if l.startswith("[GNUPG:]")]
valid = [l.split() for l in status if l.startswith("[GNUPG:] VALIDSIG")]
signer_fpr = valid[0][2] if valid else None
primary_from_sig = valid[0][-1] if valid else None
goodsig = any(l.startswith("[GNUPG:] GOODSIG") for l in status)
bad = [l for l in status if any(t in l for t in ("BADSIG", "ERRSIG", "EXPKEYSIG", "REVKEYSIG", "NO_PUBKEY", "EXPSIG"))]
lines = open(os.path.join(ORIG, files["sums"][0])).read().splitlines()
zl = [l for l in lines if l.endswith("  terraform_1.17.0_linux_amd64.zip")]
res["steps"]["T3_verification"] = {"gpgv_exit_code": p.returncode, "status_lines": status, "goodsig": goodsig,
    "signing_subkey_fpr": signer_fpr, "primary_fpr_from_VALIDSIG": primary_from_sig,
    "primary_matches_anchor": primary_from_sig == EXP_FPR,
    "signing_key_belongs_to_anchor_key": signer_fpr in [k.get("fpr") for k in keys],
    "negative_status_lines": bad,
    "manifest_line_count": len(lines), "linux_amd64_line": zl,
    "expected_linux_amd64_sha256": EXP_ZIP,
    "linux_amd64_match": len(zl) == 1 and zl[0].split()[0] == EXP_ZIP}
ok = (p.returncode == 0 and goodsig and primary_from_sig == EXP_FPR and not bad and res["steps"]["T3_verification"]["linux_amd64_match"])
res["status"] = "PASS" if ok else "FAIL"
res["ended_utc"] = now()
json.dump(res, open(os.path.join(W, "result.json"), "w"), indent=1)
print(json.dumps(res, indent=1, ensure_ascii=False))
sys.exit(0 if ok else 2)
