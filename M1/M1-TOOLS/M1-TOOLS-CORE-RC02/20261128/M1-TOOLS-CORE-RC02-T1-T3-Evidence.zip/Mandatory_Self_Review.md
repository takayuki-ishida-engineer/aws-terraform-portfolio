# M1-TOOLS-CORE R-C02 (T1–T3) — Mandatory Self Review

Decision OD-M1-TOOLS-CORE-RC02-T1-T3-20261128 / Authority OD-DELEGATION-01.
Classification: SELF REVIEW ONLY. Not Independent Review and not CORE Technical Acceptance.

## Result: T1–T3 PASS (measured)

| Step | Result |
|---|---|
| T1 Environment | Ubuntu 24.04.5 LTS. gpgv/gpg 2.4.4-2ubuntu17.6 and curl 8.5.0-2ubuntu10.16 are dpkg packages maintained by Ubuntu Developers. The gpgv and gpg binaries match the dpkg md5sums. |
| T1 Anchor | The key from https://www.hashicorp.com/.well-known/pgp-key.txt (7717 bytes, sha256 c2f5bc11…d065) has one primary key. Its full fingerprint C874011F0AB405110D02105534365D9472D7468F exactly matches the WP-08 anchor. |
| T2 Acquisition | SHA256SUMS: HTTP 200, 1592 bytes, sha256 8a324f66…2abd. Signature `.72D7468F.sig`: HTTP 200, 566 bytes, sha256 a60e7fe7…43e3. |
| T3 Verification | gpgv with a dedicated temporary keyring returned exit 0. GOODSIG and VALIDSIG were issued by signing subkey 374EC75B485913604A831CC7C820C6D5CD27AB87 under primary C874011F…72D7468F, signature dated 2026-10-21. No BADSIG/ERRSIG/EXPSIG/REVKEYSIG/NO_PUBKEY. The authenticated manifest has exactly one `terraform_1.17.0_linux_amd64.zip` line: `c168cab7c637a8769fdb90089ddd19de701bc6ff8aca64dc2e2185fe46f59f67`, as expected. |

The status line `KEYEXPIRED 1650413312` refers to subkey B0B441097685B676, which expired on 2022-04-20 and is not the signer. It does not affect the result.

## Limitations and residual risk (C00)
- Tool provenance is local consistency only: Ubuntu maintainer metadata plus the dpkg md5 match. The image has no apt lists, so archive signatures cannot be chained. Under §28 C00 this is accepted with residual risk.
- Transport went through the agent proxy with TLS verification kept (curl `--cacert` set to the proxy bundle, no `--insecure`). Under C03a, authenticity rests on the signature and the anchor fingerprint, not on the transport. RB-03 remains INCONCLUSIVE and was not re-probed.
- Anchor independence rests on the WP-08 fingerprint record. This task did not establish the fingerprint through a second channel.
- Authentication covers only the manifest entry. The archive bytes were not acquired (T4), and member and executable identity (T5/T6) are out of scope and belong to CI-INT-01 method (b). Nothing here proves which archive the historical CI run actually installed.
- The steps ran from a single Python script, `tools/rc02_t1_t3.py`, which records every command's argv, exit code and output in `commands.jsonl`. There were no harness denials and no retries.

## Boundaries kept
No new tool, CI, repository write, publication, AWS/EKS access, credentials, cost, or T4–T6. The temporary GNUPGHOME holds only the public key. Originals are unchanged in `originals/`.
