import collections,hashlib,json,mmap,re,struct,subprocess
from pathlib import Path
w=Path(__file__).parent;n=Path('/workspace/scratch/m1-network-resume.e2wZJg')
expected={'cosign':'424e2c97d0b45fd7a6b608a87f090f35633f4c23ece5f092d48bba11aaf4bbfa','trivy':'6a972c69606c7b3ea4c6bdcc6fc9332ea9ad38381624310c1e85cc77345909f3'}
patterns={'html':r'^golang\.org/x/net/html(?:[./]|$)','openpgp':r'^golang\.org/x/crypto/openpgp(?:[./]|$)','otel_trace':r'^go\.opentelemetry\.io/otel/trace[./]','otel_sdk':r'^go\.opentelemetry\.io/otel/sdk/','provider_registration':r'SetTracerProvider|SetLoggerProvider|SetMeterProvider','trivy_telemetry':r'(?i)aquasecurity/(?:trivy|[^/]+).*(telemetry|trac(?:er|ing))','sigstore_verify':r'sigstore-go/pkg/verify\..*(Verify|verify)|VerifyNewBundle|SetTrustedMaterial|checkNewBundle','alternate_pgp':r'(?i)(?:protonmail/go-crypto|gopenpgp|openpgp)'}
def cstr(b,p,end):
 q=b.find(b'\0',p,end);assert q>=p;return b[p:q].decode(errors='strict')
out={}
for tool,hashval in expected.items():
 p=n/tool
 with p.open('rb') as f, mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as b:
  assert hashlib.sha256(b).hexdigest()==hashval
  proc=subprocess.run(['/usr/bin/readelf','-SW',str(p)],capture_output=True,text=True,check=True)
  def sec(s):
   m=re.search(r'\]\s+'+re.escape(s)+r'\s+\S+\s+\w+\s+(\w+)\s+(\w+)',proc.stdout);return tuple(int(x,16) for x in m.groups())
  off,size=sec('.gopclntab'); assert b[off:off+8]==b'\xf1\xff\xff\xff\0\0\x01\x08'
  count,nfiles,_,names,_,files,pct,pcln=struct.unpack_from('<8Q',b,off+8)
  assert 0<names<files<pct<pcln<size
  pool=off+names; ft=off+pcln; nameset=[]; offsets=[]
  for j in range(count):
   pc,ptr=struct.unpack_from('<II',b,ft+j*8); assert 0<ptr<size-pcln
   pc2,name=struct.unpack_from('<Ii',b,ft+ptr);assert pc==pc2
   nameset.append(cstr(b,pool+name,off+files));offsets.append(pc)
  assert len(nameset)==count and offsets==sorted(offsets)
  file_names=[x.decode(errors='replace') for x in b[off+files:off+pct].split(b'\0') if x]
  a,s=sec('.go.buildinfo'); raw=b[a:a+s]
  # Section read only: identify retained runtime and exact dependency lines, without network/toolchain.
  dep=[x.decode() for x in re.findall(rb'(?:go1\.27\.3|(?:dep|build)\t[^\x00\n]{1,250})',raw) if any(y in x for y in (b'go1.27.3',b'otel',b'/x/net',b'/x/crypto',b'sigstore-go',b'vcs.revision',b'GOARCH',b'GOOS'))]
  matches={k:[x for x in nameset if re.search(pat,x)] for k,pat in patterns.items()}
  fileshits={k:[x for x in file_names if re.search(pat,x)] for k,pat in {'html':r'golang\.org/x/net@[^/]+/html/','openpgp':r'golang\.org/x/crypto@[^/]+/openpgp/','otel':r'go\.opentelemetry\.io/otel[^/]*/'}.items()}
  out[tool]=dict(sha256=hashval,tool='Existing Python stdlib parser and /usr/bin/readelf -SW',command='python3 pcln.py; readelf -SW retained ELF',exit_code=0,format='ELF x86-64 Go pclntab 0xfffffff1',function_count=count,source_file_count=len(file_names),native_symtab=bool(re.search(r'\s\.symtab\s',proc.stdout)),build_info=dep,matches=matches,file_matches=fileshits,limits='Go runtime function table and file table only; no inline-frame scan, indirect dispatch execution proof, or whole-program absence. File matches may refer to inline/source metadata.')
(w/'binary-witness.json').write_text(json.dumps(out,indent=2)+'\n')
for k,v in out.items():
 print(k,v['function_count'],v['source_file_count'],{i:len(j) for i,j in v['matches'].items()},{i:len(j) for i,j in v['file_matches'].items()},v['build_info'])
