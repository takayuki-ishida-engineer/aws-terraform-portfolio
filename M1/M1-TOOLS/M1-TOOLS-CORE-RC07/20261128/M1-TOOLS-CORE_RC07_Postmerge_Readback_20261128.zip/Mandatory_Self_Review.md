Fixed refs and main CI read back. Evidence is derived project record, not raw CI logs or full local CLI measurement. No new scan. No CORE release. Original CLI pending.
