"""R2 process driver. Raw file/process trace remains in the private scratch directory."""
import datetime as dt
import hashlib as h
import json
import os
import re
import socket
import subprocess as s
import sys
import time
import zipfile
from pathlib import Path
import launcher as L

w=L.root
def digest(p):
    with p.open('rb') as f:return h.file_digest(f,'sha256').hexdigest()
def clean(s):
    return s.replace(str(L.stage),'$STAGE').replace(str(w),'$R2')
def scan_trace(t,p):
    seq=t.splitlines()
    ix=next((j for j,l in enumerate(seq) if re.search(r'execveat\(240, ""',l) and '= 0' in l),None)
    if ix is None:
        return dict(exec_observed=False,launch_socket_probes=0)
    scopes=[l for l in seq[ix+1:] if re.search(r'\b(?:socket|socketpair|connect|sendto|sendmsg|bind|listen)\(',l)]
    unsafe_network=[l for l in scopes if not 'EPERM' in l]
    accesses=[]
    for l in seq[ix+1:]:
        m=re.search(r'\b(?:open\(|openat\([^,]+, )"([^"]+)"[^\n]*\)\s+=\s+(\d+)(?:\D|$)',l)
        if not m:continue
        access=Path(m[1]); path=str(access) if access.is_absolute() else str(L.stage/access)
        writes=any(flag in l for flag in ('O_WRONLY','O_RDWR','O_CREAT','O_TRUNC','O_APPEND','O_TMPFILE'))
        accesses.append((path,writes))
    outside=sorted({x for x,y in accesses if not (x==str(L.stage) or x.startswith(str(L.stage)+'/') or x in ('/dev/null','/etc/localtime','/proc/self/cgroup','/proc/self/mountinfo','/proc/sys/vm/overcommit_memory','/sys/fs/cgroup/cpu.max','/sys/kernel/mm/transparent_hugepage/hpage_pmd_size','/sys/kernel/mm/hugepages'))})
    return dict(exec_observed=True,launch_socket_probes=sum('socket(' in l and 'EPERM' in l for l in seq[:ix]),post_exec_network_calls=len(scopes),post_exec_unsafe_network=len(unsafe_network),successful_write_open_count=sum(y for x,y in accesses),opened_paths=sorted({clean(x) for x,y in accesses}),unexpected_successful_reads=[clean(o) for o in outside],raw_trace=dict(size=p.stat().st_size,sha256=digest(p)))

if __name__=='__main__':
    e=Path('/workspace/scratch/m1-et-public.BTXW0G/remote-retry-1.zip')
    with zipfile.ZipFile(e) as a:
        for fn in ('trusted_root.json','trivy-linux-amd64.bundle.json'):
            assert (L.stage/'inputs'/fn).read_bytes()==a.read('evidence/'+fn)
        expected_qualification=json.loads(a.read('M1_TOOLS_Scanner_Qualification.json'))
        assert expected_qualification['tools']['trivy']['observed_artifact']['sha256']==L.hashes[L.archive]
        assert expected_qualification['tools']['trivy']['certificate_identity']==L.identity
    start=dt.datetime.now(dt.UTC).isoformat()
    cases=['reject-unknown','reject-env','probe-with-extra-fd','reject-digest','reject-stale-db','reject-db-update','timeout-fixture','cosign-positive','cosign-wrong-digest','cosign-wrong-identity','cosign-wrong-root','cosign-missing','trivy-cosign','trivy-trivy']
    if len(sys.argv)>1:
        cases=sys.argv[1:]
        assert all(c in ['cosign-positive','cosign-wrong-digest','cosign-wrong-identity','cosign-wrong-root','cosign-missing','trivy-cosign','trivy-trivy'] for c in cases)
    rows=[]
    for c in cases:
        stdout=w/'results'/f'{c}.stdout';stderr=w/'results'/f'{c}.stderr';trace=w/'results'/f'{c}.trace'
        fds=();pair=None
        env=dict(L.env_names)
        kind=c
        base=['/usr/bin/python3',str(w/'launcher.py'),c]
        if c=='reject-env':
            env['TEST_SENTINEL']='synthetic-not-a-secret';base[-1]='probe'
        if c=='probe-with-extra-fd':
            pair=socket.socketpair();fds=(pair[0].fileno(),);base[-1]='probe'
        scanner=c.startswith(('trivy-','cosign-'))
        if scanner:
            base=['/usr/bin/strace','-f','-qq','-s','384','-e','trace=%file,%network,%ipc,execveat,process_vm_readv','-o',str(trace),*base]
        if c=='timeout-fixture': base=['/usr/bin/timeout','0.05','/bin/sleep','1']
        t=time.monotonic()
        with stdout.open('xb') as a, stderr.open('xb') as b:
            cp=s.run(base,env=env,stdin=s.DEVNULL,stdout=a,stderr=b,pass_fds=fds,cwd=L.stage,timeout=115)
        if pair:
            pair[0].close();pair[1].close()
        rc=cp.returncode
        log=stderr.read_text(errors='replace')
        init=[l for l in log.splitlines() if l.startswith('init ') and ('opentelemetry' in l or 'telemetry' in l)]
        rest=[clean(l) for l in log.splitlines() if not l.startswith(('init ','R2_RECEIPT '))]
        receipt=next((json.loads(l[len('R2_RECEIPT '):]) for l in log.splitlines() if l.startswith('R2_RECEIPT ')),None)
        row=dict(case=c,process_exit=rc,elapsed_s=round(time.monotonic()-t,3),actual_command=[clean(p) for p in base],stdout=dict(size=stdout.stat().st_size,sha256=digest(stdout)),stderr=dict(size=stderr.stat().st_size,sha256=digest(stderr)),go_init_packages=[l.split(' @')[0] for l in init],stderr_selected=rest[-10:])
        if receipt:row['runtime_receipt']=json.loads(clean(json.dumps(receipt)))
        if scanner:
            row['trace']=scan_trace(trace.read_text(errors='replace'),trace)
            assert row['trace'].get('exec_observed'), (c,'scanner exec unavailable',rest[-5:])
            assert not any(row['trace'][k] for k in ('post_exec_unsafe_network','successful_write_open_count','unexpected_successful_reads')), (c,row['trace'])
            assert row['trace']['launch_socket_probes']==3
        negatives={'reject-unknown':'INVOCATION_REJECTED','reject-env':'ENV_REJECTED','reject-digest':'INPUT_DIGEST_MISMATCH','reject-stale-db':'DB_FRESHNESS_REJECTED','reject-db-update':'DB_UPDATE_NOT_IN_CONTRACT','cosign-wrong-digest':'signature','cosign-wrong-identity':'identit','cosign-wrong-root':'trusted root','cosign-missing':'arg'}
        if c in negatives:
            row['result']='PASS_REJECTED' if rc!=0 and negatives[c].lower() in log.lower() else 'FAIL_UNEXPECTED_NEGATIVE'
        elif c=='probe-with-extra-fd':row['result']='PASS_CONTROL_PROBE' if rc==0 and 'CONTROL_PROBE_PASS' in stdout.read_text() else 'FAIL'
        elif c=='timeout-fixture':row['result']='PASS_TIMEOUT' if rc==124 else 'FAIL'
        elif c=='cosign-positive':row['result']='PASS_VERIFIED' if rc==0 and 'Verified OK' in (log+stdout.read_text()) else 'FAIL'
        else:
            try:
                data=json.loads(stdout.read_bytes())
                results=data.get('Results') or []
                row['scan_summary']=[dict(Type=x['Type'],packages=len(x.get('Packages') or []),findings=len(x.get('Vulnerabilities') or [])) for x in results]
                row['result']='PASS_OFFLINE_WITNESS' if rc==0 and any(x['Type']=='gobinary' and x['packages']>0 for x in row['scan_summary']) else 'FAIL'
            except Exception:row['result']='FAIL_NO_JSON'
        rows.append(row)
        print(c,rc,row['result'],row['elapsed_s'],row.get('scan_summary'),row.get('trace',{}).get('post_exec_network_calls'),flush=True)
        (w/'execution.json').write_text(json.dumps(dict(started_utc=start,runs=rows),indent=2)+'\n')
        if c in ('probe-with-extra-fd','reject-env','reject-unknown','reject-digest','reject-stale-db','reject-db-update','timeout-fixture') and not row['result'].startswith('PASS'):
            raise RuntimeError('preflight gate')
