import json
from pathlib import Path
from run import scan_trace
w=Path(__file__).parent
f=w/'execution.json'
results=json.loads(f.read_text())
for row in results['runs']:
    c=row['case']
    if 'trace' not in row:continue
    trace=w/'results'/f'{c}.trace'; result=scan_trace(trace.read_text(errors='replace'),trace)
    assert result['exec_observed'] and result['opened_paths'] and result['launch_socket_probes']==3
    assert result['post_exec_unsafe_network']==0 and result['successful_write_open_count']==0 and not result['unexpected_successful_reads']
    if c=='cosign-positive':
        assert result['opened_paths'].count('$STAGE/inputs/trusted_root.json')==1
        assert '$STAGE/inputs/trivy-linux-amd64.bundle.json' in result['opened_paths'] and '$STAGE/inputs/trivy-linux-amd64.tar.gz' in result['opened_paths']
    if c.startswith('trivy-'):
        assert '$STAGE/cache/db/trivy.db' in result['opened_paths']
        assert any('mkdir $R2/tmp/' in l and 'operation not permitted' in l for l in row['stderr_selected'])
    row['trace']=result
    for p in ('runtime_receipt','actual_command'):
        if p in row:row[p]=json.loads(json.dumps(row[p]).replace('$R2/stage','$STAGE'))
results['posthoc_trace_verification']='Reparsed saved traces using exact open/openat argument forms; no scanner rerun. Successful path reads listed per run.'
f.write_text(json.dumps(results,indent=2)+'\n')
print(len(results['runs']),sum('trace' in r for r in results['runs']))
