"""Bound the approved R2 invocations to fixed files, inert local inputs and stdout."""
import ctypes as C
import datetime as dt
import errno
import hashlib
import json
import os
import resource
import socket
import stat
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
stage = root / 'stage'
binary_hashes = {
    'cosign': '424e2c97d0b45fd7a6b608a87f090f35633f4c23ece5f092d48bba11aaf4bbfa',
    'trivy': '6a972c69606c7b3ea4c6bdcc6fc9332ea9ad38381624310c1e85cc77345909f3',
}
archive = 'inputs/trivy-linux-amd64.tar.gz'
bundle = 'inputs/trivy-linux-amd64.bundle.json'
trust = 'inputs/trusted_root.json'
db = 'cache/db/trivy.db'
meta = 'cache/db/metadata.json'
hashes = {
    **binary_hashes,
    archive: 'bc0fc726e017b8927a62b2d3531d7a84ee01769daf5c99ed866dced54089fdbf',
    bundle: 'cb12a2b2801d871e1ee08720c3f22546fd40df818314769d9ea80707a31decb3',
    trust: '6494e21ea73fa7ee769f85f57d5a3e6a08725eae1e38c755fc3517c9e6bc0b66',
    db: '80b72081e35c6d7fb3df5897576145d15ffaa6c9843d02df2e68c25b99eb7d7f',
    meta: '4b99ca228500e7c6a678a6e5731e6861c15b2227180ec593a382a4b601a86fc3',
    'fixtures/cosign-elf': binary_hashes['cosign'],
    'fixtures/trivy-elf': binary_hashes['trivy'],
    'fixtures/wrong-artifact.txt': hashlib.sha256(b'Harmless fixture for digest-mismatch witness.\n').hexdigest(),
    'fixtures/wrong-root.json': hashlib.sha256(b'{"invalid":true}\n').hexdigest(),
}
identity = 'https://github.com/aquasecurity/trivy/.github/workflows/reusable-release.yaml@refs/tags/v0.76.2'
issuer = 'https://token.actions.githubusercontent.com'
env_names = {
    'HOME': str(root/'home'), 'TMPDIR': str(root/'tmp'), 'LANG': 'C.UTF-8',
    'AWS_CONFIG_FILE': '/dev/null', 'AWS_SHARED_CREDENTIALS_FILE': '/dev/null',
    'AWS_EC2_METADATA_DISABLED': 'true', 'GODEBUG': 'inittrace=1',
}
limits = {resource.RLIMIT_CPU: 75, resource.RLIMIT_AS: 8*1024**3,
          resource.RLIMIT_FSIZE: 8*1024**2, resource.RLIMIT_CORE: 0, resource.RLIMIT_NOFILE: 128}
planned = {
    'probe','reject-digest','reject-stale-db','reject-db-update',
    'cosign-positive','cosign-wrong-digest','cosign-wrong-identity','cosign-wrong-root','cosign-missing',
    'trivy-cosign','trivy-trivy',
}
execution_fd=240
libc=C.CDLL(None,use_errno=True)
libc.syscall.restype=C.c_long

def verify(name, expected=None):
    p=stage/name
    assert p.resolve()==p and p.is_file() and not (p.stat().st_mode & 0o222), 'unsafe input'
    with p.open('rb') as f:
        digest=hashlib.file_digest(f,'sha256').hexdigest()
    if digest != (expected or hashes[name]): raise ValueError('INPUT_DIGEST_MISMATCH')
    return str(p)

def fresh(metadata, now):
    v=json.loads(metadata)
    updated=dt.datetime.fromisoformat(v['UpdatedAt'])
    next_update=dt.datetime.fromisoformat(v['NextUpdate'])
    if v['Version']!=2 or not 0<=(now-updated).total_seconds()<=86400 or not now<next_update:
        raise ValueError('DB_FRESHNESS_REJECTED')
    return dict(metadata=v, age_seconds=(now-updated).total_seconds(), checked_utc=now.isoformat())

class ArgCompare(C.Structure):
    _fields_=[('arg',C.c_uint),('op',C.c_int),('a',C.c_uint64),('b',C.c_uint64)]

def isolate():
    assert libc.prctl(38,1,0,0,0)==0, 'no_new_privs'
    lib=C.CDLL('libseccomp.so.2')
    lib.seccomp_init.argtypes=[C.c_uint32];lib.seccomp_init.restype=C.c_void_p
    lib.seccomp_syscall_resolve_name.argtypes=[C.c_char_p]
    lib.seccomp_rule_add_array.argtypes=[C.c_void_p,C.c_uint32,C.c_int,C.c_uint,C.POINTER(ArgCompare)]
    lib.seccomp_load.argtypes=[C.c_void_p]
    ctx=lib.seccomp_init(0x7fff0000)
    assert ctx
    def deny(name,arg=None,err=errno.EPERM):
        nr=lib.seccomp_syscall_resolve_name(name.encode())
        assert nr>=0, name
        assert lib.seccomp_rule_add_array(ctx,0x00050000|err,nr,int(arg is not None),C.byref(arg) if arg is not None else None)==0,name
    for name in (
        'socket','socketpair','connect','bind','listen','accept','accept4','sendmsg','sendmmsg',
        'recvmsg','recvmmsg','io_uring_setup','io_uring_enter','io_uring_register',
        'shmget','shmat','shmctl','semget','semop','semtimedop','semctl','msgget','msgsnd','msgrcv','msgctl',
        'mq_open','mq_unlink','mq_timedsend','mq_timedreceive',
        'ptrace','process_vm_readv','process_vm_writev','pidfd_getfd','pidfd_open','pidfd_send_signal',
        'fork','vfork','execve','unshare','setns','mount','umount2','pivot_root','chroot',
        'open_by_handle_at','name_to_handle_at','openat2','creat','truncate','ftruncate','fallocate',
        'unlink','unlinkat','rename','renameat','renameat2','mkdir','mkdirat','rmdir',
        'link','linkat','symlink','symlinkat','mknod','mknodat','chmod','fchmod','fchmodat','chown','fchown',
        'lchown','fchownat','utime','utimes','utimensat','futimesat','setxattr','lsetxattr','fsetxattr',
        'removexattr','lremovexattr','fremovexattr','bpf','userfaultfd','fanotify_init','keyctl','add_key','request_key',
    ): deny(name)
    deny('clone3',err=errno.ENOSYS)
    # Allow Go thread creation only. Deny clone into any kernel namespace.
    deny('clone',ArgCompare(0,7,0x10000,0))
    for flag in (0x00020000,0x02000000,0x04000000,0x08000000,0x10000000,0x20000000,0x40000000):
        deny('clone',ArgCompare(0,7,flag,flag))
    # A single O_CLOEXEC descriptor above RLIMIT_NOFILE is made available before filtering.
    deny('execveat',ArgCompare(0,1,execution_fd,0))
    deny('execveat',ArgCompare(4,1,0x1000,0))
    for syscall,index in (('open',1),('openat',2)):
        for flag in (os.O_WRONLY,os.O_RDWR,os.O_CREAT,os.O_TRUNC,os.O_APPEND,os.O_TMPFILE & ~os.O_DIRECTORY):
            deny(syscall,ArgCompare(index,7,flag,flag))
    assert lib.seccomp_load(ctx)==0, 'seccomp load'
    assert libc.prctl(39,0,0,0,0)==1, 'no_new_privs readback'

def denied(f):
    try:f()
    except PermissionError as e:
        assert e.errno==errno.EPERM
    else:raise RuntimeError('expected EPERM')

def main():
    assert os.uname().machine=='x86_64'
    assert len(sys.argv)==2 and sys.argv[1] in planned, 'INVOCATION_REJECTED'
    assert dict(os.environ)==env_names, 'ENV_REJECTED'
    assert Path.cwd()==stage, 'WORKING_DIRECTORY_REJECTED'
    for fd in range(3):
        mode=os.fstat(fd).st_mode
        assert (stat.S_ISCHR(mode) and os.fstat(fd).st_rdev==os.stat('/dev/null').st_rdev) if fd==0 else stat.S_ISREG(mode), 'FD_REJECTED'
    old_fds=[int(fd) for fd in os.listdir('/proc/self/fd') if int(fd)>2]
    for fd in old_fds:
        try:os.close(fd)
        except OSError as e:
            if e.errno!=errno.EBADF:raise
    case=sys.argv[1]
    if case=='reject-digest':
        verify('fixtures/wrong-artifact.txt',hashes[archive])
    if case=='reject-stale-db':
        verify(meta)
        fresh((stage/meta).read_bytes(),dt.datetime.now(dt.UTC)+dt.timedelta(days=2))
    if case=='reject-db-update':
        raise ValueError('DB_UPDATE_NOT_IN_CONTRACT')
    argv=None
    receipt={'case':case,'isolated_controls':'seccomp, no_new_privs, bounded stdout/stderr, read-only filesystem syscalls; unrestricted read namespace','removed_nonstdio_fds':len(old_fds),'env':env_names,'rlimits':{str(k):v for k,v in limits.items()},'cwd':str(stage)}
    if case.startswith('cosign-'):
        exe=verify('cosign')
        root_file=verify('fixtures/wrong-root.json' if case=='cosign-wrong-root' else trust)
        identity_arg=identity if case!='cosign-wrong-identity' else identity+'-fixture-mismatch'
        artifact=verify('fixtures/wrong-artifact.txt' if case=='cosign-wrong-digest' else archive)
        argv=[exe,'verify-blob','--offline','--new-bundle-format=true','--bundle',verify(bundle),
              '--trusted-root',root_file,'--certificate-identity',identity_arg,'--certificate-oidc-issuer',issuer,'--use-signed-timestamps']
        if case!='cosign-missing':argv.append(artifact)
    elif case.startswith('trivy-'):
        exe=verify('trivy')
        verify(db); verify(meta)
        receipt['db_freshness']=fresh((stage/meta).read_bytes(),dt.datetime.now(dt.UTC))
        target=verify('fixtures/'+case.split('-')[1]+'-elf')
        argv=[exe,'rootfs','--config','/dev/null','--cache-dir',str(stage/'cache'),'--cache-backend','memory',
              '--scanners','vuln','--format','json','--offline-scan','--skip-db-update','--skip-java-db-update',
              '--skip-check-update','--skip-vex-repo-update','--disable-telemetry','--skip-version-check',
              '--list-all-pkgs','--no-progress','--parallel','2','--timeout','90s','--ignorefile=','--exit-code','0',target]
    if argv:
        fd=os.open(argv[0],os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW)
        os.dup2(fd,execution_fd,inheritable=False)
        if fd!=execution_fd:os.close(fd)
        receipt['argv']=argv
    for r,maxvalue in limits.items(): resource.setrlimit(r,(maxvalue,maxvalue))
    isolate()
    for family in (socket.AF_INET,socket.AF_INET6,socket.AF_UNIX):
        denied(lambda:socket.socket(family,socket.SOCK_STREAM))
    if case=='probe':
        denied(lambda:os.open('must-not-exist',os.O_WRONLY|os.O_CREAT,0o600))
        denied(lambda:os.open(str(stage/trust),os.O_RDWR))
        denied(lambda:os.unlink(str(stage/trust)))
        denied(lambda:os.execve('/bin/true',['true'],env_names))
        for fd in old_fds:
            try:os.fstat(fd)
            except OSError as e: assert e.errno==errno.EBADF
            else:raise RuntimeError('FD inherited')
        assert all(resource.getrlimit(r)==(v,v) for r,v in limits.items())
        print('CONTROL_PROBE_PASS')
        return
    assert argv
    print('R2_RECEIPT '+json.dumps(receipt,sort_keys=True),file=sys.stderr,flush=True)
    os.execve(execution_fd,argv,env_names)

if __name__=='__main__':
    main()
