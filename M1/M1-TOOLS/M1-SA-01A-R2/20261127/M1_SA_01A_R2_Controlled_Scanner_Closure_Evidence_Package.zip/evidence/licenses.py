from pathlib import Path
from collections import Counter
import hashlib,struct,json,re,subprocess,mmap,datetime,urllib.request,urllib.error,concurrent.futures,zipfile,tarfile
w=Path(__file__).parent;n=Path('/workspace/scratch/m1-network-resume.e2wZJg')
sa=Path('/workspace/scratch/m1-e06.ON87XG/remote-wrapper.zip')
r1=Path('/workspace/scratch/m1-sa-r1.DINITe/binary-witness.json')
def digest(b):return hashlib.sha256(b).hexdigest()
def parse_module(b):
    def vstr(p):
        v=0;offset=0
        while True:
            q=b[p];p+=1;v|=(q&127)<<offset
            if q<128:break
            offset+=7;assert offset<64
        return b[p:p+v],p+v
    assert b[:14]==b'\xff Go buildinf:' and b[14:16]==b'\x08\x02'
    ver,p=vstr(32);mod,p=vstr(p)
    assert ver==b'go1.27.3' and mod[-17]==10
    mods=[];build={};target=None
    for line in mod[16:-16].decode().splitlines():
        cols=line.split('\t')
        if cols[0] in ('mod','dep'):
            obj=dict(module=cols[1],version=cols[2],checksum=cols[3] if len(cols)>3 else None)
            if cols[0]=='dep':mods.append(obj)
            else:target=obj
        elif cols[0]=='build':
            k,_,v=cols[1].partition('=');build[k]=v
        elif cols[0]=='=>':
            mods[-1]['replacement']=cols[1:]
    assert target and mods
    return dict(runtime=ver.decode(),main=target,modules=mods,build=build)
tools={}
for name in ('cosign','trivy'):
    p=w/'stage'/name
    sec=subprocess.check_output(['/usr/bin/readelf','-SW',str(p)],text=True)
    match=re.search(r'\]\s+\.go\.buildinfo\s+\S+\s+\w+\s+(\w+)\s+(\w+)',sec)
    off,size=map(lambda x:int(x,16),match.groups())
    with p.open('rb') as f:f.seek(off); tools[name]=parse_module(f.read(size))
    tools[name]['archive_elf_scope']='Go link-time module metadata; package reachability, embedded non-Go and vendor notices require separate mapping'
    print(name,len(tools[name]['modules']),tools[name]['main']['module'])
with zipfile.ZipFile(sa) as a:
    dst=w/'license-private';dst.mkdir(exist_ok=True)
    notes=[]
    for file in ('licenses/cosign/LICENSE','licenses/trivy/LICENSE','licenses/trivy/NOTICE'):
        b=a.read(file);(dst/file.replace('/','-')).write_bytes(b)
        notes.append(dict(name=file,source='SA-A-DIST exact fixed upstream license',sha256=digest(b),size=len(b)))
with tarfile.open(n/'trivy-linux-amd64.tar.gz','r:gz') as a:
    archive=[m.name for m in a.getmembers() if m.isfile()]
    assert a.extractfile(next(m for m in a.getmembers() if m.name.split('/')[-1]=='LICENSE')).read()==(n/'trivy-binary-LICENSE').read_bytes()
# The full retained build identities drive exact module-version matching, independent of go.mod.
u=[('otel-trace','https://raw.githubusercontent.com/open-telemetry/opentelemetry-go/trace/v1.46.0/LICENSE',['go.opentelemetry.io/otel/trace@v1.46.0']),
   ('otel-sdk','https://raw.githubusercontent.com/open-telemetry/opentelemetry-go/sdk/v1.46.0/LICENSE',['go.opentelemetry.io/otel/sdk@v1.46.0']),
   ('golang-xcrypto','https://raw.githubusercontent.com/golang/crypto/v0.58.0/LICENSE',['golang.org/x/crypto@v0.58.0']),
   ('golang-xnet61','https://raw.githubusercontent.com/golang/net/v0.61.0/LICENSE',['golang.org/x/net@v0.61.0']),
   ('golang-xnet62','https://raw.githubusercontent.com/golang/net/v0.62.0/LICENSE',['golang.org/x/net@v0.62.0']),
   ('golang-stdlib','https://raw.githubusercontent.com/golang/go/go1.27.3/LICENSE',['stdlib@go1.27.3'])]
def fetch(item):
    name,url,scope=item; t=datetime.datetime.now(datetime.UTC).isoformat()
    row=dict(name=name,url=url,scope=scope,retrieved_utc=t)
    try:
        with urllib.request.urlopen(url,timeout=8) as f:
            b=f.read(100000);(dst/name).write_bytes(b);row.update(status=f.status,sha256=digest(b),size=len(b),license='Apache-2.0 and included Go derivative notices' if b'Apache License' in b else 'Go Authors BSD-style text')
    except urllib.error.HTTPError as e:row.update(status=e.code,meaning='Unverified')
    except Exception as e:row.update(status=None,meaning=type(e).__name__)
    return row
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool: notes2=list(pool.map(fetch,u))
for n2 in notes2: print(n2['name'],n2['status'])
covered={x for row in notes2 if row['status']==200 for x in row['scope']}
for name,obj in tools.items():
    obj['targeted_license_matches']=[v for v in obj['modules'] if v['module']+'@'+v['version'] in covered]
    obj['unreviewed_module_license_count']=sum(v['module']+'@'+v['version'] not in covered for v in obj['modules'])
    obj['module_inventory_count']=len(obj['modules'])
m=json.loads((n/'cosign-public-metadata.json').read_bytes())
assets=[a.get('name','') for a in m['assets'] if isinstance(a,dict)]
out=dict(status='PARTIAL_BLOCKING_FOR_SCANNER_QUALIFICATION',runtime_tools=tools,existing_project_documents=notes,fixed_targeted_license_sources=notes2,trivy_packaged_files=archive,cosign_qualified_release_assets=assets,limitation='No complete independently matched binary SBOM/license/notice mapping. The full unreviewed module set is enumerated by exclusion from targeted_license_matches; embedded non-Go assets, transitive notices and redistribution conditions remain unqualified.',scope='Current operation used local binary under fixed scope. This is not permission to redistribute either scanner.')
(w/'licenses.json').write_text(json.dumps(out,indent=2)+'\n')
