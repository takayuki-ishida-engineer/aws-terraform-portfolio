from pathlib import Path
import collections,concurrent.futures,datetime,hashlib,html,json,re,socket,threading,time,urllib.request,urllib.error
w=Path(__file__).parent
base=json.loads(Path('/workspace/scratch/m1-sa-r2.k3Ywls/licenses.json').read_text())
inv={}
for tool,items in base['runtime_tools'].items():
 for row in items['modules']:
  key=json.dumps([row['module'],row['version'],row.get('replacement')],separators=(',',':'))
  x=inv.setdefault(key,dict(key=key,**row,binary_association=[],association_basis='Retained ELF Go link-time module metadata; not package-level or non-Go inventory'))
  x['binary_association'].append(tool)
resolved={(scope.split('@')[0],scope.split('@')[1]):r for r in base['fixed_targeted_license_sources'] if r['status']==200 for scope in r['scope'] if not scope.startswith('stdlib@')}
throttle=threading.Lock();slot=0
archive=w/'license-private';archive.mkdir(exist_ok=True)
halt=threading.Event()
def fetch(url):
 global slot
 with throttle:
  cur=time.monotonic();wait=max(0,slot-cur);slot=max(cur,slot)+0.14
 time.sleep(wait)
 try:
  with urllib.request.urlopen(url,timeout=7) as f:
   return f.status,f.read(800000),f.url
 except urllib.error.HTTPError as e:
  if e.code==429:halt.set()
  return e.code,b'',url
 except (OSError,TimeoutError):return None,b'',url
def classify(x):
 y=dict(x,license_id=[],notice='UNRESOLVED_COMPONENT_NOTICE',use_conditions='Review before distribution; no infringement conclusion',redistribution='Not qualified for redistribution',blocking='Closure required before formal M1 Scanner acceptance')
 m,v=x['module'],x['version']
 if x.get('replacement'):
  y.update(status='UNRESOLVED_REPLACEMENT');return y
 old=resolved.get((m,v))
 if old:
  y.update(status='FIXED_UPSTREAM_TEXT_REUSED',license_id=[old['license']],fixed_source_url=old['url'],evidence_sha256=old['sha256']);return y
 if halt.is_set():y.update(status='UNRESOLVED_RATE_LIMIT'); return y
 # This is a read-only page on the Go team's reference site. No module/ZIP download.
 url='https://pkg.go.dev/'+m+'@'+v+'?tab=licenses'
 status,b,final=fetch(url); y.update(fixed_source_url=url,reported_url=final,http_status=status,checked_utc=datetime.datetime.now(datetime.UTC).isoformat())
 if status!=200:
  y.update(status='UNRESOLVED_NO_INDEX_EVIDENCE');return y
 s=b.decode('utf-8',errors='replace')
 matches=re.findall(r'<div class="License-source[^"]*">\s*Source:\s*([^<]+)</div>',s)
 exact=[html.unescape(p).strip() for p in matches if html.unescape(p).strip().startswith(m+'@'+v+'/')]
 if not exact:
  y.update(status='UNRESOLVED_NO_EXACT_INDEX_MATCH');return y
 ids=[html.unescape(t).strip() for t in re.findall(r'<div id="#lic-\d+">([^<]+)</div>',s)]
 bodies=[html.unescape(z).encode() for z in re.findall(r'<pre class="License-contents">(.*?)</pre>',s,re.S)]
 y.update(status='EXACT_INDEX_LICENSE_ONLY' if ids and bodies else 'UNRESOLVED_NO_CLASSIFICATION',license_id=ids,index_source_paths=exact,index_page_sha256=hashlib.sha256(b).hexdigest(),notice='Separate NOTICE and per-package attribution not established by index')
 hashes=[]
 for raw in bodies:
  h=hashlib.sha256(raw).hexdigest(); (archive/h).write_bytes(raw);hashes.append(h)
 y['license_text_sha256']=hashes
 return y
p='M1_SA_01A_R3_'
with (w/(p+'Unique_Dependency_Inventory.jsonl')).open('w') as f:
 for x in inv.values():f.write(json.dumps(x)+'\n')
with (w/(p+'License_Closure_Ledger.jsonl')).open('w') as f,concurrent.futures.ThreadPoolExecutor(max_workers=10) as pool:
 results=[]
 for y in pool.map(classify,inv.values()):
  f.write(json.dumps(y)+'\n');f.flush();results.append(y)
c=collections.Counter(r['status'] for r in results)
summary=dict(cosign_total=len(base['runtime_tools']['cosign']['modules']),trivy_total=len(base['runtime_tools']['trivy']['modules']),unique=len(inv),shared=sum(len(r['binary_association'])==2 for r in inv.values()),fixed_upstream_text_reused=c['FIXED_UPSTREAM_TEXT_REUSED'],exact_index_identification_only=c['EXACT_INDEX_LICENSE_ONLY'],unknown_license=sum(not r['license_id'] for r in results),fully_closed=0,unresolved_components=len(inv),notice_closure_not_established=len(inv),required_notice_count='NOT_DETERMINABLE_FROM_INDEX',binary_association_module=len(inv),binary_association_package_level_unverified=len(inv),non_go_component_count='UNDETERMINED',blocking_gate='SA-01/SA-02; no complete binary-specific package/NOTICE/vendor/BOM mapping',actual_blocking_component_count='Not determinable: items with unconfirmed NOTICE are not necessarily restricted',indexed_status_counts=c,notes=['Retained source license documents for scanner projects and Go stdlib reused separately.','Exact pkg.go.dev module/version page is official index evidence, not a complete binary attribution or upstream NOTICE audit.','No module download, compilation, or license-body publication.'])
(w/(p+'License_Coverage_Summary.json')).write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
