from pathlib import Path
import urllib.request,urllib.error,json,collections,concurrent.futures,hashlib,itertools,re,threading,time,datetime
w=Path(__file__).parent
p='M1_SA_01A_R3_'
lp=w/(p+'License_Closure_Ledger.jsonl')
old=[json.loads(l) for l in lp.read_text().splitlines()]
assert len(old)==518
sb=w/'cosign.sbom.json';s=json.loads(sb.read_bytes())
expected_module='.sbom.json'
assert hashlib.sha256(sb.read_bytes()).hexdigest()=='7bf7fede0ef7d1b0c12efd1ffe8e7c1b50d894da8e21d4b838db6bcd9d66cb8b'
assert any(f['fileName']=='cosign-linux-amd64' and any(c['algorithm']=='SHA256' and c['checksumValue']=='424e2c97d0b45fd7a6b608a87f090f35633f4c23ece5f092d48bba11aaf4bbfa' for c in f['checksums']) for f in s['files'])
refs={(x['name'],x['versionInfo']):x['licenseConcluded'] for x in s['packages'] if 'versionInfo' in x and any(a.get('referenceLocator','').startswith('pkg:golang/') for a in x.get('externalRefs',[]))}
for row in old:
 if 'cosign' in row['binary_association']:
  ref=refs.get((row['module'],row['version']))
  if ref:
   row['cosign_exact_sbom']=dict(license_concluded=ref,subject_sha256='424e2c97d0b45fd7a6b608a87f090f35633f4c23ece5f092d48bba11aaf4bbfa')
   if not row['license_id'] and ref not in ('NOASSERTION','NONE'):
    row.update(license_id=[ref],status='ARTIFACT_BOUND_SBOM_CONCLUSION_ONLY',notice='SBOM license conclusion, separate notice/redistribution not established')
lock=threading.Lock();next_at=0
halt=threading.Event()
def fetch(url):
 global next_at
 with lock:
  now=time.monotonic(); sl=max(next_at-now,0);next_at=max(next_at,now)+0.20
 time.sleep(sl)
 try:
  with urllib.request.urlopen(url,timeout=6) as f:return f.status,f.read(262144)
 except urllib.error.HTTPError as e:
  if e.code==429:halt.set()
  return e.code,b''
 except (TimeoutError,OSError):return None,b''
def method(row):
 mod,v=row['module'],row['version']
 if row['license_id'] or row.get('replacement'):return row
 # Use only obvious owner/repo module roots and exact non-pseudo source tags.
 if not re.fullmatch(r'github\.com/[\w.-]+/[\w.-]+',mod) or not re.fullmatch(r'v\d+\.\d+\.\d+(?:-(?:rc|beta|alpha)[.\w-]+)?(?:\+incompatible)?',v):return row
 prefix=f'https://raw.githubusercontent.com/{mod.removeprefix("github.com/")}/{v.removesuffix("+incompatible")}'
 results=[]
 if halt.is_set():return row
 for name in ('LICENSE','LICENSE.md'):
  url=f'{prefix}/{name}';status,b=fetch(url)
  results.append(dict(url=url,http_status=status,utc=datetime.datetime.now(datetime.UTC).isoformat()))
  if status==200 and b:
   h=hashlib.sha256(b).hexdigest();(w/'license-private'/h).write_bytes(b)
   s=b.decode(errors='replace').lower()
   label=('Apache-2.0' if 'apache license' in s and 'version 2.0' in s else 'MIT' if 'permission is hereby granted, free of charge' in s else 'BSD-family' if 'redistribution and use in source and binary forms' in s else 'MPL-2.0' if 'mozilla public license' in s and '2.0' in s else None)
   row.update(status='FIXED_UPSTREAM_TEXT_IDENTIFIED' if label else 'FIXED_UPSTREAM_TEXT_REQUIRES_CLASSIFICATION',license_id=[label] if label else [],upstream_fixed_source=dict(url=url,sha256=h,size=len(b),identity='official GitHub root exact tag; term/notice and subcomponent mapping unclosed'))
   break
  if status!=404:break
 row['fixed_upstream_attempts']=results
 return row
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:final=list(pool.map(method,old))
lp.write_text(''.join(json.dumps(x)+'\n' for x in final))
sp=w/(p+'License_Coverage_Summary.json')
summary=json.loads(sp.read_bytes());summary.update(unknown_license=sum(not r['license_id'] for r in final),license_identity_available=sum(bool(r['license_id']) for r in final),exact_binary_bound_sbom_associations=sum('cosign_exact_sbom' in r for r in final),distinct_modules_with_fixed_official_evidence=sum(r['status'] in ('FIXED_UPSTREAM_TEXT_IDENTIFIED','FIXED_UPSTREAM_TEXT_REUSED') for r in final),final_status_counts=collections.Counter(r['status'] for r in final),cosign_sbom=dict(sha256=hashlib.sha256(sb.read_bytes()).hexdigest(),spdx=s['spdxVersion'],data_license=s['dataLicense'],packages=len(s['packages']),subject='matches retained ELF SHA-256',notice_gap='package-level attribution and all NOTICE obligations not established'),trivy_sbom='No SPDX/CycloneDX/SBOM assets listed on fixed Trivy release API; no binary-associated source BOM established')
sp.write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
