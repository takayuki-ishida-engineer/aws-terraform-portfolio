import json,hashlib,re,stat,zipfile,sys
from pathlib import Path
w=Path(__file__).parent
orig=next(Path('/workspace/scratch/m1-sa-r2.k3Ywls').glob('M1*.zip'))
p=Path(sys.argv[1]) if len(sys.argv)>1 else orig
sha=lambda b:hashlib.sha256(b).hexdigest()
expected='cdeb6f869ac21f7351955cf3ca733e336b84d32e3d7a92f7bf6040fac55dbcec'
assert p.stat().st_size==65228 and sha(p.read_bytes())==expected
pfx='M1_SA_01A_R2_'
classes={
 'Reachability_Ledger.jsonl':'Authored three-Finding analysis and factual identity pointers',
 'Restricted_Usage_Contract.json':'Authored fixed execution specification',
 'Isolation_and_Negative_Regression.json':'Authored control/results description',
 'OpenTelemetry_Witness.json':'Derived package initialization, fixed-source analysis without copied code',
 'Execution_Receipts.json':'Authored/sanitized records of scanner invocations and OS observations; selected diagnostic lines and public dependency names, not raw logs',
 'Binary_and_License_Closure.json':'Dependency names, versions, checksums, license identity metadata and release inventory; no upstream license body',
 'Historical_Evidence_Disposition.json':'Authored decisions and limitations',
 'Gate_Register.json':'Authored gate register','Self_Review.md':'Authored review','Evidence_Manifest.json':'Integrity metadata'
}
other={'evidence/launcher.py':'Locally authored defensive launcher; no upstream source fixture or credential','evidence/run.py':'Locally authored test driver; generic scratch path',
       'evidence/verify_results.py':'Locally authored trace summary script','evidence/licenses.py':'Locally authored dependency metadata script with official URL references; generic scratch paths',
       'evidence/owner-authorization.txt':'Owner-approved authorization with no identifiers beyond approved wording','evidence/main-final.jsonl':'Public GitHub metadata',
       'evidence/evidence-final.jsonl':'Public GitHub metadata','SHA256SUMS':'Checksum facts'}
classes={**{pfx+x:y for x,y in classes.items()},**other}
secret=rb'-----BEGIN (?:[A-Z0-9 ]+ )?PRIVATE KEY-----|\b(?:AKIA|ASIA)[A-Z0-9]{16}\b|\b(?:gh[pousr]_|github_pat_)[A-Za-z0-9_]{20,}|(?i:X-Amz-(?:Signature|Credential)=[A-Za-z0-9%]{12,}|\bAuthorization\s*:\s*(?:Bearer|Basic)\s+[A-Za-z0-9+/_.=-]{12,})|(?i:["\x27]?(?:password|aws_secret_access_key|aws_session_token|access_token)["\x27]?\s*[:=]\s*["\x27][^"\x27]{8,}["\x27])'
with zipfile.ZipFile(p) as z:
 names=z.namelist()
 assert len(names)==len(set(names))==18 and set(names)==set(classes) and z.testzip() is None
 for i in z.infolist():assert stat.S_ISREG(i.external_attr>>16) and not i.flag_bits&1 and not i.filename.startswith(('/','\\')) and '..' not in re.split(r'[/\\\\]',i.filename)
 m=pfx+'Evidence_Manifest.json'; rows=json.loads(z.read(m))['files']
 assert len(rows)==16 and {r['path'] for r in rows}==set(names)-{m,'SHA256SUMS'}
 for r in rows:
  b=z.read(r['path']);assert len(b)==r['size_bytes'] and sha(b)==r['sha256']
 sums=[l.split('  ',1) for l in z.read('SHA256SUMS').decode().splitlines()]
 assert len(sums)==17 and {f for h,f in sums}==set(names)-{'SHA256SUMS'} and all(sha(z.read(f))==h for h,f in sums)
 assert sha(z.read('evidence/owner-authorization.txt'))=='64a662cf934a8563871bf540729dac4cb1c57e13673297cacf4173595ef9cb70'
 inventory=[]
 for f in names:
  b=z.read(f);s=b.decode('utf-8')
  assert not re.search(secret,b) and not re.search(rb'[\w.%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}',b),f
  assert not re.search(rb'"(?:terraform_version|lineage)"\s*:',b),f
  private=re.findall(r'/(?:workspace|home|root)/[^"\s]+',s)
  assert all(f in ('evidence/run.py','evidence/licenses.py') and x.startswith('/workspace/scratch/m1-') for x in private),f
  inventory.append(dict(path=f,size_bytes=len(b),sha256=sha(b),review=classes[f],generic_path_count=len(private),rights='Owner-authorized authored material or factual/short technical record; no third-party source/license body or separately redistributable material found',eligibility='ELIGIBLE'))
 a=dict(artifact='SA-A-R2',decision='OD-M1E-08',original_sha256=expected,original_size=65228,original_internal_authorization='OD-M1SA-03 digest verified',publication_case='A1',public_disclosure='ELIGIBLE_FOR_PUBLICATION',license_compliance='PASS',LC={f'LC-0{i}':'PASS' for i in range(1,7)},review='Full 18-entry content and archive check; raw traces and acquired full upstream licenses remain outside the archive',inventory=inventory,independent_review='PENDING_INDEPENDENT_VERIFICATION')
 if p==orig:(w/'REDISTRIBUTION_INVENTORY.json').write_text(json.dumps(a,indent=2)+'\n')
print(expected,18,16,17)
