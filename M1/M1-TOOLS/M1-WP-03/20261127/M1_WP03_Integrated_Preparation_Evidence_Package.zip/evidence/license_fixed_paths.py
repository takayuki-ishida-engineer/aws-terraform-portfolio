from pathlib import Path
import concurrent.futures,urllib.request,urllib.error,sys,json,hashlib,re,collections,datetime,threading,time
w=Path(__file__).parent;p='M1_SA_01A_R3_'
ledger=w/(p+'License_Closure_Ledger.jsonl')
rows=[json.loads(l) for l in ledger.read_text().splitlines()]
lock=threading.Lock(); now_slot=0;halt=threading.Event()
def fetch(url):
 global now_slot
 with lock:
  now=time.monotonic(); wait=max(0,now_slot-now); now_slot=max(now_slot,now)+0.22
 time.sleep(wait)
 try:
  with urllib.request.urlopen(url,timeout=6) as f:return f.status,f.read(262144)
 except urllib.error.HTTPError as e:
  if e.code==429:halt.set()
  return e.code,b''
 except (TimeoutError,OSError):return None,b''
def lookup(row):
 if row['license_id'] or row.get('fixed_upstream_attempts') or row.get('replacement') or halt.is_set():return row
 m,v=row['module'],row['version']
 if not m.startswith('github.com/'):return row
 _,owner,repo,*dirs=m.split('/')
 major=dirs[-1] if dirs and re.fullmatch(r'v[2-9][0-9]*|v1[0-9]+',dirs[-1]) else None
 if major:dirs=dirs[:-1]
 pseudo=re.search(r'(?:^|[.-])\d{14}-([0-9a-f]{12})(?:\+incompatible)?$',v)
 rev=pseudo[1] if pseudo else '/'.join([*dirs,v.removesuffix('+incompatible')])
 expected='/'.join([*dirs,'LICENSE'])
 paths=list(dict.fromkeys([expected,'LICENSE']))[:2]
 attempts=[]
 for suffix in paths:
  url=f'https://raw.githubusercontent.com/{owner}/{repo}/{rev}/{suffix}'
  status,b=fetch(url)
  attempts.append(dict(url=url,http_status=status,utc=datetime.datetime.now(datetime.UTC).isoformat()))
  if status==200 and b:
   sha=hashlib.sha256(b).hexdigest();(w/'license-private'/sha).write_bytes(b);s=b.decode(errors='replace').lower()
   lab='Apache-2.0' if 'apache license' in s and 'version 2.0' in s else 'MIT' if 'permission is hereby granted, free of charge' in s else 'BSD-family' if 'redistribution and use in source and binary forms' in s else None
   row.update(status='FIXED_SUBMODULE_OR_COMMIT_TEXT_IDENTIFIED' if lab else 'FIXED_SUBMODULE_OR_COMMIT_TEXT_REQUIRES_CLASSIFICATION',license_id=[lab] if lab else [],upstream_fixed_source=dict(url=url,sha256=sha,size=len(b),basis='Exact Go pseudo-version embedded commit or exact Go submodule tag. Root license fallback is repository baseline only; separate notice/subtree terms remain unresolved.'))
   break
  if status!=404:break
 row['fixed_submodule_attempts']=attempts
 return row
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:out=list(pool.map(lookup,rows))
ledger.write_text(''.join(json.dumps(x)+'\n' for x in out))
sp=w/(p+'License_Coverage_Summary.json');s=json.loads(sp.read_text())
s.update(unknown_license=sum(not x['license_id'] for x in out),license_identity_available=sum(bool(x['license_id']) for x in out),distinct_modules_with_fixed_official_evidence=sum(x['status'] in ('FIXED_UPSTREAM_TEXT_IDENTIFIED','FIXED_UPSTREAM_TEXT_REUSED','FIXED_SUBMODULE_OR_COMMIT_TEXT_IDENTIFIED') for x in out),final_status_counts=collections.Counter(x['status'] for x in out))
sp.write_text(json.dumps(s,indent=2)+'\n');print(s['license_identity_available'],s['unknown_license'],s['distinct_modules_with_fixed_official_evidence'],dict(s['final_status_counts']))
