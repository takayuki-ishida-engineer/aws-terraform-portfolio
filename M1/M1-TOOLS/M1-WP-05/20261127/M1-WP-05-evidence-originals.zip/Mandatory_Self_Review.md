# M1-WP-05 Mandatory Self Review

**Overall verdict: PARTIAL.** Environment and runtime observation are blocked.
Track D produced additional static evidence. Independent review and formal acceptance remain pending.

## Authority and boundary

- OD-M1WP05-01 matched 194 UTF-8 bytes and SHA-256
  `013060510d20900a1d2a191056f5caba2d4368b50b4fef3c36867ab3f9b9dd8a`.
- MASTER_POLICY v15.0 and Revision 6 v1.30 archived hashes match the controlling inputs.
- GitHub branch API read at start and end confirmed main
  `9987ca5346b08906e3e1ece49ef33873284d8f64`, tree
  `c57429cad1ccc15384116318944c9e6342859350`, and evidence
  `873825e2e8620238bb63fb2598fcae94670b41ba`, tree
  `7b356b8cdedf4a4c9fcffbd19548bcd6f489be73`. All three known local worktrees
  are clean on their original HEADs. PR #107 merge verification was not repeated.
- All new files are in this isolated scratch directory. No repository or CI write,
  external artifact retrieval, AWS/EKS operation, publication, paid resource,
  tool adoption, security relaxation, container start, image pull/build or DB
  refresh was performed.

## Command receipts and results

| Commands | Result |
| --- | --- |
| `gh api repos/.../branches/{main,evidence}`, `GIT_OPTIONAL_LOCKS=0 git status --porcelain=v1`, `git rev-parse HEAD` | Remote baseline matched at both boundaries; local worktree readback clean. |
| `uname -sm`, `command -v`, `file`, `sha256sum` | Linux x86_64, existing Docker and ELF identity checked. Observer discovery found no eligible Go-level tool. |
| `docker --host unix:///var/run/docker.sock version`, `image ls -a --no-trunc --digests`, `info` | Read-only. Client/server 29.9.2; zero local images including untagged. Daemon self-report does not attest container isolation. |
| `go version -m <retained ELF>` | Existing command reported “Unknown option: version.” It was not retried. A local read-only build-metadata parser provided the static association instead. |
| `python3 -O reconcile.py` | Verified 2 exact ELF identities and the 518 ledger rows, reconciled DB bytes and metadata, produced static and disposition deltas. |
| `python3 -O refine_bsd.py` | Refined 26 previously imprecise license descriptions from their retained fixed texts. |
| `python3 -O verify_records.py` | Five synthetic negative fixtures rejected, one positive fixture passed. Cross-record checks passed. These are static evidence regressions. |
| `zipfile.ZipFile.testzip()`, manifest and digest comparison | WP-04 original SHA-256 and size, CRC 33/33, manifest 31/31, SHA256SUMS 32/32. Selected extracted WP-04 and R2 reference members and WP-03 archive ledger matched their local copies. Original archives were preserved. |

No Landlock, bwrap or seccomp reprobe was performed. Track B inert positive/negative
tests remain NOT_TESTED. No historical isolation result was promoted to WP-05 proof.

## Observation, findings and license results

- Cosign 3.1.4 and Trivy 0.76.2 match the authorized ELF SHAs and carry Go 1.27.3
  build metadata. Their staged DB was digest-identical to the R2 record and
  within the 24-hour limit at the recorded readback. Neither scanner was started.
- cosign/002, trivy/001 and trivy/002 remain UNDER_INVESTIGATION.
  Effective provider, No-op/Auto delegation, effective limits, attribute origin
  and trigger reachability were not tested. Prior Cosign verification retains its
  SS-01 scope; prior Trivy startup/DB evidence remains partial.
- Module/version/checksum and binary association matched for 518/518 unique
  link-time modules. Go link-time metadata leaves file/package-level and
  non-Go coverage open.
- Six formerly unidentified fixed LICENSE texts are now classified. Another
  26 shorthand entries were refined. Rows with identifier evidence increased
  from 443 to 449, and classified fixed texts from 194 to 200. Residual identifiers
  total 69 (one Cosign, 68 Trivy). Exact module/version locators and missing
  materials are recorded. Some locators are derived from fixed ELF coordinates
  and remain unverified as available sources.
- Complete NOTICE, applicable file-level attribution and redistribution closure:
  0 formal closures. Conditional distribution obligations do not grant publication
  rights. No new vulnerability or license-source retrieval was attempted.

## Stop decision and preserved milestones

There was no trusted retained image or qualified Go runtime observer to use within the
current restriction set. A repeat of the old tracing or sandbox probes could not supply
the missing witness. Runtime work remains stopped and no additional tool, registry pull,
build or privilege changes were used. Static association and retained-text classification
were completed independently of that blocker.

M1-SA-01A, M1-TOOLS, M1-01a, M1-01b, B-07 and CI-INT-01 retain their existing
governance states. OD-HO-06, Installer Implementation, Version Adoption and public
Evidence release are outside this result. See the gate record and SHA256SUMS.
This review verifies WP-05 outputs and scope. Formal acceptance remains with
Independent Review and the applicable policy gates.
