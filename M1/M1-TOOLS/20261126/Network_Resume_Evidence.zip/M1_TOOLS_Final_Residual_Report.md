# M1-TOOLS Final Residual Security Closure — network-change evidence

**HOLD**. Official metadata, release asset transfers and the public GHCR endpoint were reachable. Cosign AMD64 and its KMS bundle match pinned release identities. Independent KMS signature, anchored TUF rotations and metadata, Rekor SET/Merkle/signed checkpoint, and RFC3161 are verified without invoking Cosign for its own bootstrap. Authenticated Cosign verified Trivy with exact Fulcio identity and issuer under no-network execution. Trivy archive and binary hashes plus fixed DB identities are recorded.

The DB Manifest and layer verify; extracted trivy.db and metadata are unchanged after scanning. All final scans met the 24h/fresh deadline and disabled updates. Current-network isolation uses additional per-process seccomp, clean credentials and scratch inputs with reviewed traces. Network namespace unavailable, Landlock unsupported, no filesystem-wide isolation claim. Prior Claude isolation was not used as current evidence.

13 final actual reports including version identity checks, 377 version-match rows across 207 advisory IDs (HIGH 56, MEDIUM 161, LOW 136, UNKNOWN 24), with per-row pending independent disposition. Python vendored file coverage, Action bundle↔lock/license binding and actual Hosted Runner package identities remain gaps. Local Debian status scan is limited to 20 selected installed packages. Scanner own findings retain qualification/security review scope. Report success exit code is a collection result, not a Security acceptance.

FC-D1–D8 and original JSON reports saved as additive scratch package. No Artifact Export available at task execution. No repository/CI/production tool changes; final M1 and CI-INT-01 gates stay HOLD.
