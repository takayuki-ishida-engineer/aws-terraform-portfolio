"""Scratch-only child restrictions for offline evidence collection."""
import ctypes, errno, os, resource, socket, stat, sys
from pathlib import Path

if os.uname().machine!='x86_64':
 raise SystemExit('Unsupported syscall ABI')
root=Path(__file__).resolve().parent
args=sys.argv[1:]
if not args or (Path(args[0]).resolve()!=root/'trivy' and args!=['preflight']):
 raise SystemExit('unapproved executable')
if Path.cwd().resolve()!=root or Path(os.environ['HOME']).resolve()!=root/'scan-home':
 raise SystemExit('working area mismatch')
allowed_env={'HOME','PATH','LANG','AWS_CONFIG_FILE','AWS_SHARED_CREDENTIALS_FILE','AWS_EC2_METADATA_DISABLED','TMPDIR'}
if set(os.environ)-allowed_env:
 raise SystemExit('unexpected environment names')
if any(os.environ.get(v)!='/dev/null' for v in ('AWS_CONFIG_FILE','AWS_SHARED_CREDENTIALS_FILE')):
 raise SystemExit('AWS config guard')
for fd in range(3):
 st=os.fstat(fd).st_mode
 if stat.S_ISSOCK(st):
  raise SystemExit('inherited network fd')
os.closerange(3,min(resource.getrlimit(resource.RLIMIT_NOFILE)[0],1048576))
libc=ctypes.CDLL(None,use_errno=True)
libc.syscall.restype=ctypes.c_long
if libc.prctl(38,1,0,0,0)!=0:raise OSError(ctypes.get_errno(),'PR_SET_NO_NEW_PRIVS')
lib=ctypes.CDLL('libseccomp.so.2')
lib.seccomp_init.argtypes=[ctypes.c_uint32]
lib.seccomp_init.restype=ctypes.c_void_p
lib.seccomp_syscall_resolve_name.argtypes=[ctypes.c_char_p]
lib.seccomp_rule_add_array.argtypes=[ctypes.c_void_p,ctypes.c_uint32,ctypes.c_int,ctypes.c_uint,ctypes.c_void_p]
lib.seccomp_load.argtypes=[ctypes.c_void_p]
ctx=lib.seccomp_init(0x7fff0000)
if not ctx:raise RuntimeError('failed seccomp')
calls=(b'socket',b'socketpair',b'connect',b'io_uring_setup',b'io_uring_enter',b'io_uring_register')
for call in calls:
 n=lib.seccomp_syscall_resolve_name(call)
 if n<0 or lib.seccomp_rule_add_array(ctx,0x00050000|errno.EPERM,n,0,None)!=0:
  raise RuntimeError('failed to install deny '+call.decode())
if lib.seccomp_load(ctx)!=0:raise RuntimeError('failed to apply seccomp')
for family in (socket.AF_INET,socket.AF_INET6,socket.AF_UNIX):
 try:socket.socket(family,socket.SOCK_STREAM)
 except PermissionError as e:
  if e.errno!=errno.EPERM:raise
 else:raise RuntimeError('socket permission unexpectedly allowed')
if args==['preflight']:
 print('PATH: staged scratch targets and explicit null AWS config; filesystem-wide Landlock unavailable; traced access record required')
 print('PASS AF_INET AF_INET6 AF_UNIX denied (EPERM); no inherited socket FDs; io_uring and connect denied')
 print('PASS empty inherited environment with explicit noncredential markers; no AWS or proxy variables carrying credentials')
 print('PASS scratch HOME and approved executable boundaries; loopback unused and also blocked')
 sys.exit(0)
os.execv(args[0],args)
