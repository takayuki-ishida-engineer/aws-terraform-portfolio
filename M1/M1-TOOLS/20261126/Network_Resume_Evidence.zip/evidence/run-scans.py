import datetime as dt,hashlib,json,re,subprocess,sys
from pathlib import Path
here=Path.cwd()
out=here/'scan-results'
out.mkdir(exist_ok=True)
db=here/'run-cache/db/metadata.json'
meta=json.loads(db.read_text())
def now_fresh():
 now=dt.datetime.now(dt.UTC)
 updated=dt.datetime.fromisoformat(meta['UpdatedAt'])
 nextupdate=dt.datetime.fromisoformat(meta['NextUpdate'])
 secs=(now-updated).total_seconds()
 if not (meta['Version']==2 and 0<=secs<=86400 and now<nextupdate):
  raise RuntimeError('DB freshness invalid')
 return dict(checked_utc=now.isoformat(),age_seconds=secs,max_age_seconds=86400,metadata=meta)
targets=sys.argv[1:]
scan_targets=set(x.name for x in (here/'stage').iterdir())
if not targets or any(x not in scan_targets for x in targets):raise SystemExit('unapproved target')
env=dict(PATH='/usr/bin:/bin',HOME=str(here/'scan-home'),TMPDIR=str(here/'scan-tmp'),LANG='C.UTF-8', AWS_EC2_METADATA_DISABLED='true',AWS_CONFIG_FILE='/dev/null',AWS_SHARED_CREDENTIALS_FILE='/dev/null')
for name in targets:
 now_fresh()
 if (out/(name+'.json')).exists():raise SystemExit('existing scan result')
 mode='rootfs' if name in {'codex-runtime','terraform','aws-provider','helm','cosign','trivy'} else 'fs'
 command=[str(here/'trivy'),mode,'--config','/dev/null','--cache-dir',str(here/'run-cache'),
 '--cache-backend','memory','--scanners','vuln','--format','json','--output',str(out/(name+'.json')),
 '--offline-scan','--skip-db-update','--skip-java-db-update','--skip-check-update','--skip-vex-repo-update',
 '--disable-telemetry','--skip-version-check','--list-all-pkgs','--no-progress','--parallel','2','--timeout','2m',
 '--ignorefile=','--exit-code','0',str(here/'stage'/name)]
 trace=out/(name+'.trace')
 exec_line=['/usr/bin/strace','-f','-qq','-s','1024','-e','trace=%file,%network','-o',str(trace),
            '/usr/bin/python3',str(here/'scanner-isolation.py'),*command]
 with (out/(name+'.log')).open('wb') as log:
  r=subprocess.run(exec_line,env=env,cwd=here,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,timeout=135)
 log=(out/(name+'.log')).read_text(errors='replace')
 evidence=trace.read_text(errors='replace')
 secret_path=re.compile(r'/workspace/(?:[^"\s]*/)?(?:\.aws|\.kube)(/|")|/(?:root|home/[^/]+)/\.(?:aws|kube)(/|")|\.tfstate(?:\.backup)?["/]|/workspace/aws-terraform-portfolio/',re.I)
 successful_network=re.compile(r'\b(?:connect|socket|socketpair)\([^\n]+\)\s+=\s+\d+\s*$',re.M)
 scan_ok=not secret_path.search(evidence) and not successful_network.search(evidence)
 result=dict(target=name,command=command,process_exit=r.returncode,forbidden_path_mentions=bool(secret_path.search(evidence)),
             successful_socket_or_connect=bool(successful_network.search(evidence)),freshness_at_end=now_fresh(),scanner_log=log)
 j=out/(name+'.json')
 if r.returncode==0 and j.exists() and scan_ok:
  code=json.loads(j.read_text())
  rows=[dict(target=x.get('Target'),type=x.get('Type'),packages=len(x.get('Packages') or []),vulnerabilities=len(x.get('Vulnerabilities') or [])) for x in code.get('Results',[])]
  result.update(report_sha256=hashlib.sha256(j.read_bytes()).hexdigest(),matches=rows)
 else:
  result['status']='FAIL_OR_BLOCKED'
 (out/(name+'.receipt.json')).write_text(json.dumps(result,indent=2)+'\n')
 print(name,'exit',r.returncode,'success_isolation',scan_ok, 'rows', result.get('matches'),flush=True)
 if r.returncode or not j.exists() or not scan_ok:
  print(log)
  raise SystemExit('stop after target failure')
