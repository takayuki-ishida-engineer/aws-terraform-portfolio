import base64, datetime as dt, hashlib, json, mmap, re
from pathlib import Path
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.exceptions import InvalidSignature

here=Path('.')
def read(p):
 return json.loads(Path(p).read_bytes(),object_pairs_hook=unique)
def unique(items):
 d={}
 for k,v in items:
  if k in d: raise ValueError('duplicate JSON key '+k)
  d[k]=v
 return d
def sha(b): return hashlib.sha256(b).digest()
def check(ok,msg):
 if not ok: raise ValueError(msg)
 print('PASS',msg,flush=True)
def b64(s): return base64.b64decode(s,validate=True)
def canon(o):
 # Metadata examined here uses integers, ASCII strings, and literal booleans.
 s=json.dumps(o,sort_keys=True,ensure_ascii=False,separators=(',',':'))
 if not s.isascii() or re.search(r'(?<!\\)\\[^"\\]',s):
  # PEM strings in TUF role metadata encode literal newlines; OLPC canonical encoding
  # preserves them, while standard JSON represents them as escape sequences.
  def olpc(v):
   if isinstance(v,dict):
    return '{'+','.join(olpc(k)+':'+olpc(v[k]) for k in sorted(v))+'}'
   if isinstance(v,list):return '['+','.join(map(olpc,v))+']'
   if isinstance(v,str):
    if not v.isascii():raise ValueError('metadata text outside checked ASCII domain')
    return '"'+v.replace('\\','\\\\').replace('"','\\"')+'"'
   if isinstance(v,float):raise ValueError('unsupported float')
   return json.dumps(v)
  return olpc(o).encode()
 return s.encode()
def signed(meta, trusted, role, threshold_override=None):
 role_cfg=trusted['signed']['roles'][role]
 if meta['signed']['_type']!=role: raise ValueError('unexpected metadata role')
 threshold=role_cfg['threshold']
 approved=set(role_cfg['keyids'])
 data=canon(meta['signed'])
 valid=set()
 for signer in meta['signatures']:
  kid=signer['keyid']
  if kid not in approved or kid in valid or not signer['sig']:continue
  key=trusted['signed']['keys'][kid]
  if key['scheme']!='ecdsa-sha2-nistp256':raise ValueError('unsupported TUF method')
  pub=serialization.load_pem_public_key(key['keyval']['public'].encode())
  if not isinstance(pub,ec.EllipticCurvePublicKey) or pub.curve.name!='secp256r1':raise ValueError('unexpected TUF key')
  try: pub.verify(bytes.fromhex(signer['sig']),data,ec.ECDSA(hashes.SHA256()))
  except InvalidSignature:continue
  valid.add(kid)
 return len(valid),threshold
def assess(meta,trusted,role,label):
 count,threshold=signed(meta,trusted,role)
 check(count>=threshold,f'{label} {role} signatures {count}/{threshold}')
def matches_meta(description,path,role,expected_version):
 meta=read(path)
 check(meta['signed']['_type']==role and meta['signed']['version']==expected_version,role+' exact version')
 b=Path(path).read_bytes()
 if 'length' in description:check(len(b)==description['length'],role+' length')
 for a,h in description.get('hashes',{}).items():check(hashlib.new(a,b).hexdigest()==h,role+' SHA')
 return meta
now=dt.datetime.now(dt.timezone.utc)
root_path=Path('sigstore-go-root.json')
with open('cosign-linux-amd64.download','rb') as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as m:
 check(m.find(root_path.read_bytes())>=0,'bootstrap root 14 byte-identical inside KMS-verified Cosign binary')
root=read(root_path)
check(root['signed']['version']==14,'anchored root version 14')
for version in (15,16):
 n=read(f'tuf-{version}.root.json')
 check(n['signed']['version']==root['signed']['version']+1,'root rotation consecutive '+str(version))
 assess(n,root,'root',f'root {version} old threshold')
 assess(n,n,'root',f'root {version} new threshold')
 root=n
check(dt.datetime.fromisoformat(root['signed']['expires'])>now,'root 16 fresh')
ts=read('tuf-timestamp.json')
assess(ts,root,'timestamp','TUF')
check(dt.datetime.fromisoformat(ts['signed']['expires'])>now,'timestamp fresh')
sm=ts['signed']['meta']['snapshot.json']
sn=matches_meta(sm,'tuf-166.snapshot.json','snapshot',sm['version'])
assess(sn,root,'snapshot','TUF')
check(dt.datetime.fromisoformat(sn['signed']['expires'])>now,'snapshot fresh')
td=sn['signed']['meta']['targets.json']
tg=matches_meta(td,'tuf-14.targets.json','targets',td['version'])
assess(tg,root,'targets','TUF')
check(dt.datetime.fromisoformat(tg['signed']['expires'])>now,'targets fresh')
tb=Path('trusted_root.json').read_bytes()
d=tg['signed']['targets']['trusted_root.json']
check(len(tb)==d['length'] and sha(tb).hex()==d['hashes']['sha256'],'exact signed trusted_root.json length and sha256')
r=read('trusted_root.json')
b=read('cosign-kms.bundle.json')
entry,=b['verificationMaterial']['tlogEntries']
logid=entry['logId']['keyId']
rk,=[x for x in r['tlogs'] if x['logId']['keyId']==logid]
key_der=b64(rk['publicKey']['rawBytes'])
pub=serialization.load_der_public_key(key_der)
when=dt.datetime.fromtimestamp(int(entry['integratedTime']),dt.timezone.utc)
p=rk['publicKey']['validFor']
check(dt.datetime.fromisoformat(p['start'])<=when and ('end' not in p or when<=dt.datetime.fromisoformat(p['end'])),'Rekor trusted key valid at integrated time')
p=dict(body=entry['canonicalizedBody'],integratedTime=int(entry['integratedTime']),logIndex=int(entry['logIndex']),logID=b64(logid).hex())
payload=json.dumps(p,sort_keys=True,separators=(',',':')).encode()
pub.verify(b64(entry['inclusionPromise']['signedEntryTimestamp']),payload,ec.ECDSA(hashes.SHA256()))
check(True,'Rekor Signed Entry Timestamp authentic')
proof=entry['inclusionProof']
root_hash=sha(b'\x00'+b64(entry['canonicalizedBody']))
fn,sn=int(proof['logIndex']),int(proof['treeSize'])-1
for neighbor in proof['hashes']:
 check_neighbor=b64(neighbor)
 if len(check_neighbor)!=32:raise ValueError('bad audit path')
 if fn&1 or fn==sn:
  root_hash=sha(b'\x01'+check_neighbor+root_hash)
  while fn and not fn&1:
   fn>>=1;sn>>=1
 else:root_hash=sha(b'\x01'+root_hash+check_neighbor)
 fn>>=1;sn>>=1
check(root_hash==b64(proof['rootHash']) and sn==0,'Rekor merkle audit path')
env=proof['checkpoint']['envelope']
note, signatures=env.split('\n\n',1)
lines=note.splitlines()
check(len(lines)==3 and lines[0].startswith('rekor.sigstore.dev - ') and int(lines[1])==int(proof['treeSize']) and b64(lines[2])==root_hash,'checkpoint matches Merkle root and tree size')
sigs=[line.split() for line in signatures.splitlines() if line.strip()]
sig,=[b64(line[2]) for line in sigs if line[0]=='—' and line[1]=='rekor.sigstore.dev']
pub.verify(sig[4:],(note+'\n').encode(),ec.ECDSA(hashes.SHA256()))
check(True,'Rekor checkpoint signature authentic')
for n,ts_entry in enumerate(b['verificationMaterial']['timestampVerificationData']['rfc3161Timestamps']):
 Path(f'tsa-{n}.tsr').write_bytes(b64(ts_entry['signedTimestamp']))
ta,=r['timestampAuthorities']
certs=ta['certChain']['certificates']
from cryptography import x509
for i,v in enumerate(certs):
 cert=x509.load_der_x509_certificate(b64(v['rawBytes']))
 Path(f'tsa-trusted-{i}.pem').write_bytes(cert.public_bytes(serialization.Encoding.PEM))
 print('TSA certificate subject',i,cert.subject.rfc4514_string())
