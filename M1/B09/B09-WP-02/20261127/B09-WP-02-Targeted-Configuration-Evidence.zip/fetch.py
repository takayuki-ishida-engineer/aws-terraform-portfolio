from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
from hashlib import sha1, sha256
from datetime import datetime, timezone
import json

AGENT = 'https://raw.githubusercontent.com/DataDog/datadog-agent/7.84.1/'
OPERATOR = 'https://raw.githubusercontent.com/DataDog/datadog-operator/v1.31.2/'
DOCS = 'https://docs.datadoghq.com/'
SCHEMAS = dict(zip(
    ["core_schema","apm_config","internal_profiling","multi_region_failover","system-probe_schema","network_devices","agent_telemetry"],
    ["26cd6b2a368dc08d815d867f65a8bb00514141f1","55b1efcf9587265bedfe970767e71c7e02d0d21a","964ccebb8359957a5f1c1cf699c29d8fce803c79","2230a7c7f2363cdffffaba349a914d0acd39b464","1a6a6b7617f68be4afebe3d8ff69cb6f641ad7e8","47a72482d3b7683ddf5a649fe6b2474f5a48dca7","5555994111bd54c0d2646ae594233a491ee7e2ce"]
))
base = [(name+'.yaml', AGENT+'pkg/config/schema/yaml/'+name+'.yaml', blob) for name,blob in SCHEMAS.items()]
base += [('op-'+path.replace('/','_'), OPERATOR+path, blob) for path,blob in (
    ('docs/configuration.v2alpha1.md','b2fc80eba96d34d7549e398634a9ed686d397447'),
    ('internal/controller/datadogagent/component/clusteragent/default.go','be670c74130485be98332f2254f01f408489a5d9'),
    ('internal/controller/datadogagent/component/agent/default.go',None),
    ('internal/controller/datadogagentinternal/reconcile.go',None),
    ('internal/controller/datadogagentinternal/reconcile_agent.go',None),
    ('cmd/main.go',None),
)]
base += [(name+'.html', DOCS+path, None) for name,path in (
    ('collector','opentelemetry/setup/collector_exporter/'),
    ('dual-shipping','agent/configuration/dual-shipping/'),
    ('network-path','network_monitoring/network_path/setup/'),
)]
def fetch(item):
    name, url, expected = item
    row = {"path":"originals/"+name,"url":url,"expected_git_blob":expected}
    try:
        with urlopen(Request(url, headers={"User-Agent":"Portfolio-Static-Qualification"}), timeout=18) as res:
            row.update(http=res.status, final_url=res.url)
            data = res.read(9_000_001)
        blob = sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
        row.update(size=len(data), sha256=sha256(data).hexdigest(), git_blob=blob if url.startswith((AGENT, OPERATOR)) else None)
        if len(data)>9_000_000 or (expected and expected!=blob):
            row.update(result="IDENTITY_BLOCKED")
        else:
            Path(row['path']).write_bytes(data)
            row.update(result="RETAINED_PRIVATE")
    except (HTTPError, URLError, TimeoutError) as exc:
        row.update(http=getattr(exc,'code',None),result=type(exc).__name__)
    row["retrieved_at_utc"]=datetime.now(timezone.utc).isoformat()
    return row
if __name__ == '__main__':
    import sys
    if len(sys.argv)>1:
        base = [(x.replace('/','_'), AGENT+x, None) for x in sys.argv[1:]]
    with ThreadPoolExecutor(max_workers=8) as executor:
        rows = list(executor.map(fetch,base))
    file = 'fetch-initial.json' if len(sys.argv)==1 else 'fetch-followup.json'
    Path(file).write_text(json.dumps(rows,indent=2)+'\n')
    for row in rows:
        print(row['path'], row.get('http'),row['result'])
