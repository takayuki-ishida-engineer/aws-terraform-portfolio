"""WP-02 synthetic rules. No input from the live environment or network."""
import json
from pathlib import Path
import sys


def endpoint(rows, request):
    row = rows.get(request)
    if row is None:
        return 'ENDPOINT_UNKNOWN'
    if row['evidence'] == 'CANDIDATE_ONLY':
        return 'ENDPOINT_CANDIDATE_ONLY'
    if row['activation'] != 'AUTHORIZED_SYNTHETIC' or row['scope'] != 'SYNTHETIC':
        return 'ENDPOINT_NOT_AUTHORIZED'
    return 'ALLOW_SYNTHETIC'


def route(source, destination, expected_receiver):
    if not source['node'] or source['node'] != destination['node']:
        return 'NODE_MISMATCH'
    if not all(item['ns'] and item['attested'] is True for item in (source, destination)):
        return 'NAMESPACE_UNVERIFIED'
    if source['ns'] != destination['ns']:
        return 'NAMESPACE_MISMATCH'
    if destination['receiver'] != expected_receiver:
        return 'RECEIVER_MISMATCH'
    return 'ALLOW_SYNTHETIC'


def settings(fixture, denies, replicas):
    config = fixture['settings']
    env = fixture['environment']
    if set(config) - denies.keys() - replicas.keys():
        return 'SETTING_UNSUPPORTED'
    if set(env) - config.keys() or fixture['layers_complete'] is not True:
        return 'EFFECTIVE_CONFIG_UNKNOWN'
    if any(type(config[key]) is not bool for key in denies if key in config):
        return 'EFFECTIVE_CONFIG_UNKNOWN'
    if any(type(config[key]) is not type(empty) for key, empty in replicas.items() if key in config):
        return 'EFFECTIVE_CONFIG_UNKNOWN'
    if any(type(config[key]) is not type(value) or config[key] != value for key, value in env.items()):
        return 'ENV_OVERRIDE_CONFLICT'
    if config.keys() != denies.keys() | replicas.keys():
        return 'EFFECTIVE_CONFIG_UNKNOWN'
    if fixture['metadata'] not in ('identity', 'metric_context'):
        return 'METADATA_UNCLASSIFIED'
    if any(item not in fixture['reviewed_integrations'] for item in fixture['integrations']):
        return 'INTEGRATION_DENIED'
    if fixture['cluster_agent_required'] is True and fixture['cluster_agent_disabled'] is True:
        return 'BLOCKED_DESIGN_CONFLICT'
    if any(config[key] != empty for key, empty in replicas.items()):
        return 'ADDITIONAL_ENDPOINT_DENIED'
    for key, status in denies.items():
        if config[key] is not False:
            return status
    return 'ALLOW_SYNTHETIC'


def main():
    fixture = json.loads(Path('SYNTHETIC_FIXTURES.json').read_bytes())
    expected = json.loads(Path('EXPECTED_FIXTURE_MANIFEST.json').read_bytes())['expected']
    results = {}
    for name, args in fixture['endpoint_cases'].items():
        results[name] = endpoint(fixture['endpoints'], *args)
    for name, (source, destination) in fixture['route_cases'].items():
        results[name] = route(source, destination, 'receiver-alpha')
    for name, changes in fixture['config_cases'].items():
        test = {**fixture['base'], **changes}
        test['settings'] = {**fixture['base']['settings'], **changes.get('settings', {})}
        results[name] = settings(test, fixture['denies'], fixture['replicas'])
    rows = [{'id': name, 'expected': expected[name], 'actual': results.get(name),
             'pass': results.get(name) == expected[name]} for name in expected]
    passed = results == expected
    report = {'passed': sum(row['pass'] for row in rows), 'total': len(rows),
              'scope': 'SYNTHETIC_NOT_PRODUCTION_GUARD', 'cases': rows}
    Path(sys.argv[1]).write_text(json.dumps(report, indent=2) + '\n')
    if not passed:
        raise SystemExit('Unexpected fixture result or coverage')


if __name__ == '__main__':
    main()
