"""Reproduce source-only qualification against the recorded fixed inputs."""
from hashlib import sha256, sha1
from html import unescape
from pathlib import Path
import gzip
import json
import re
import zipfile

import yaml

OLD = Path('wp01')
RAW = Path('originals')
CONTRACT = '29a396daf7cadb9eee1f089b7ac427fcb7b7c9100f6e170ac97a3bcbd633a783'
ARCHIVE = 'e56e1ba1384bd854db3a106c4d90cb10c0c077a74c36fb5a86494e79cf80733d'
ARCHIVE_NAME = 'B09-WP-01-Datadog-Static-Configuration-Evidence.zip'
SITES = dict(US1='datadoghq.com', US3='us3.datadoghq.com', US5='us5.datadoghq.com',
             EU1='datadoghq.eu', AP1='ap1.datadoghq.com', AP2='ap2.datadoghq.com', UK1='uk1.datadoghq.com')


def need(ok, message):
    if not ok:
        raise SystemExit(message)


def digest(data):
    return sha256(data).hexdigest()


def blob(data):
    return sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def ref(file, literal, old=False):
    root = OLD if old else Path('.')
    path = Path(file) if old else RAW / file
    data = (root / path).read_bytes()
    matches = [n for n, line in enumerate(data.decode().splitlines(), 1) if literal in line]
    need(matches, f'Anchor missing: {file}: {literal}')
    return dict(path=str(root/path), sha256=digest(data), lines=matches, anchor=literal)


def source_summary():
    rows = read('ACQUISITION_RECEIPTS.json')
    tree = read(RAW / 'agent-tree.json')
    op = read(OLD / 'originals/operator-tree-v1.31.2.json')
    need(not tree['truncated'] and not op['truncated'], 'source tree metadata is incomplete')
    trees = {
        'datadog-agent/7.84.1/': {x['path']: x['sha'] for x in tree['tree']},
        'datadog-operator/v1.31.2/': {x['path']: x['sha'] for x in op['tree']},
    }
    for row in rows:
        if row['result'] != 'RETAINED_PRIVATE':
            continue
        b = Path(row['path']).read_bytes()
        need(len(b) == row['size'] and digest(b) == row['sha256'], row['path'])
        for marker, fixed in trees.items():
            if marker in row['url']:
                need(blob(b) == row['git_blob'] == fixed[row['url'].split(marker)[1]], row['url'])
                row['official_tree_blob_match'] = True
    return rows, tree['sha'], op['sha']


def fields():
    files = {p.name.removeprefix('pkg_config_schema_yaml_'): p for p in RAW.glob('*.yaml')}
    out = {}

    def walk(node, tokens, filename, stack=()):
        if '$ref' in node:
            child = node['$ref']
            if child in files:
                need(child not in stack, 'schema cycle')
                walk(yaml.safe_load(files[child].read_bytes()), tokens, child, (*stack, child))
            return
        if node.get('node_type') == 'setting':
            key = '.'.join(tokens)
            env = node.get('env_vars')
            if env == []:
                mode = 'NO_ENV_NAMES_DECLARED'
            elif env:
                mode = 'EXPLICIT_SCHEMA'
            else:
                env = ['DD_' + key.upper().replace('.', '_')]
                mode = 'DERIVED_SCHEMA_ENV_NAME'
            out[key] = dict(type=node['type'], default=node.get('default'), has_default='default' in node,
                            env=env, env_binding=mode, schema=str(files[filename]),
                            schema_sha256=digest(files[filename].read_bytes()))
        for child, properties in node.get('properties', {}).items():
            walk(properties, (*tokens, child), filename, stack)

    for root in ('core_schema.yaml', 'system-probe_schema.yaml'):
        walk(yaml.safe_load(files[root].read_bytes()), (), root)
    return out


def official_html(path):
    b = path.read_bytes()
    if b.startswith(b'\x1f\x8b'):
        b = gzip.decompress(b)
    return b.decode()


def endpoint_delta(z):
    old = json.loads(z.read('ENDPOINT_42_ROWS.json'))
    flows = json.loads(z.read('FLOW_15_ROWS.json'))
    need(len(old) == 42 and len({(x['site'], x['feature']) for x in old}) == 42, 'old endpoint identities')
    need(len({f['flow_id'] for f in flows}) == len(flows) == 15, 'old flow identities')
    need(all(x['activation'] == 'BLOCKED' for x in old + flows), 'prior activation changed')
    collector = official_html(RAW / 'collector.html')
    traces = official_html(OLD / 'originals/otlp.html')
    sites = official_html(OLD / 'originals/sites.html')
    need('https://otlp.${env:DD_SITE}' in collector and
         'for traces, logs, and metrics' in collector and 'otlp_http' in collector, 'collector rule')
    need('WithURLPath("/v1/traces")' in unescape(re.sub(r'<[^>]+>', '', traces)) and 'dd-api-key' in traces and
         'data-region-param=otlp' in traces, 'traces path, header and region slot')
    fixed_adot = ref('originals/adot-vendor_go.opentelemetry.io_collector_exporter_otlphttpexporter_config.go',
                     'TracesEndpoint', True)
    improved = []
    site_rows = dict(re.findall(r'<tr><td>([^<]+)</td><td><code>[^<]+</code></td><td><code>([^<]+)</code></td>', sites))
    for x in old:
        if x['feature'] != 'otlp_http':
            continue
        site = x['site']
        parameter = SITES[site]
        host = 'otlp.' + parameter
        need(site_rows.get(site) == parameter and x['host'] == host and x['site_parameter'] == parameter
             and x['url_path'] == '/v1/traces', 'site cross-check ' + site)
        direct = any(re.search(r'(?<![A-Za-z0-9.-])' + re.escape(host) + r'(?![A-Za-z0-9.-])', d)
                     for d in (collector, traces))
        improved.append(dict(prior_row_identity=[site, x['feature']], site=site, site_parameter=parameter,
                             host=host, url='https://' + host + '/v1/traces', signal='OTLP_HTTP_TRACES',
                             evidence='DIRECT_LITERAL_PRESENT_REQUIRES_CONTEXT' if direct else 'DERIVED_HOST_FROM_OFFICIAL_RULE',
                             path_evidence='DIRECT_OFFICIAL_TRACES_EXAMPLE', auth_header_name='dd-api-key',
                             runtime='NOT_TESTED', activation='BLOCKED'))
    need(len(improved) == 7, 'traces row coverage')
    write('ENDPOINT_EVIDENCE_DELTA.json', dict(
        original_archive_sha256=ARCHIVE, original_endpoint_member='ENDPOINT_42_ROWS.json',
        original_endpoint_member_sha256=digest(z.read('ENDPOINT_42_ROWS.json')),
        original_flow_member='FLOW_15_ROWS.json', original_flow_member_sha256=digest(z.read('FLOW_15_ROWS.json')),
        endpoint_identity_contract='WP-01 used (site, feature) as natural key; no opaque endpoint ID was defined.',
        improved_rows=improved,
        unchanged_endpoint_rows=35,
        all_endpoint_identities=[[x['site'], x['feature']] for x in old],
        all_flow_ids=[x['flow_id'] for x in flows],
        flow_delta={'DD-F02': 'Host derivation and HTTP trace path documented. Activation still BLOCKED.',
                    'DD-F15': 'Same Node plus independently witnessed shared network namespace and exact receiver identity. Still BLOCKED.'},
        activation='BLOCKED', runtime=['Site availability and approved scope', 'DNS/CNAME/IP/TTL', 'TLS/SNI/CA',
                                       'HTTP behavior/retries/no unauthorized redirects', 'received span completeness and SLO statistics'],
        fixed_adot=fixed_adot,
        evidence_sources=['https://docs.datadoghq.com/getting_started/site/',
                          'https://docs.datadoghq.com/opentelemetry/setup/otlp_ingest/traces/',
                          'https://docs.datadoghq.com/opentelemetry/setup/collector_exporter/'],
    ))


def main():
    rows, agent_tree, operator_tree = source_summary()
    contract_path = OLD / 'final-contracts.json'
    need(digest(contract_path.read_bytes()) == CONTRACT, 'Final Contracts SHA-256')
    archive = OLD / 'remote' / ARCHIVE_NAME
    need(archive.stat().st_size == 57904 and digest(archive.read_bytes()) == ARCHIVE, 'WP-01 original identity')
    with zipfile.ZipFile(archive) as z:
        need(len(z.namelist()) == 26 and z.testzip() is None, 'WP-01 CRC')
        endpoint_delta(z)
        reused = [{'path': name, 'sha256': digest(z.read(name)), 'size_bytes': len(z.read(name))}
                  for name in ('ENDPOINT_42_ROWS.json', 'FLOW_15_ROWS.json', 'FEATURE_CONFIGURATION_MATRIX.json',
                               'TRACE_SAMPLING_DECISION_MATRIX.json', 'CHART_CRD_STATIC_INVENTORY.json',
                               'candidate-datadogagent.yaml', 'candidate-operator-values.yaml', 'candidate-adot.yaml')]
        chart_inventory = json.loads(z.read('CHART_CRD_STATIC_INVENTORY.json'))
        agent_candidate = yaml.safe_load(z.read('candidate-datadogagent.yaml'))
    config = fields()
    from findings import qualify
    qualify(config, agent_candidate, ref, write, need)
    extra = []
    for name, url in (
        ('originals/sites.html', 'https://docs.datadoghq.com/getting_started/site/'),
        ('originals/otlp.html', 'https://docs.datadoghq.com/opentelemetry/setup/otlp_ingest/traces/'),
        ('originals/network.html', 'https://docs.datadoghq.com/agent/configuration/network/'),
    ):
        data = (OLD / name).read_bytes()
        extra.append(dict(path=str(OLD/name), url=url, sha256=digest(data), size_bytes=len(data)))
    replay_refs = []
    for receipt in read(OLD / 'source-fetch.json') + read(OLD / 'source-followup.json'):
        name = receipt['path']
        selected = ('op-internal_controller_datadogagent_feature_enabledefault_feature.go',
                    'op-internal_controller_datadogagent_component_clusteragent.go',
                    'op-internal_controller_datadogagent_component_reconciler.go',
                    'op-internal_controller_datadogagent_reconcile.go',
                    'adot-vendor_go.opentelemetry.io_collector_exporter_otlphttpexporter_config.go')
        if Path(name).name in selected:
            data = (OLD / name).read_bytes()
            need(digest(data) == receipt['sha256'] and blob(data) == receipt['expected_git_blob'], name)
            replay_refs.append(dict(**receipt, wp02_path=str(OLD / name)))
    for name, project, expected in [
        ('DD-S01','datadog-agent','651377bf2bdabf280bae0c168596ca13c311a8b7'),
        ('DD-S02','datadog-agent','ac7376b6c18d531a7b397815e5a3fac1bc8c3405'),
        ('DD-S03','datadog-operator','4880eb5810e2e00361b111ae523b43050c781643'),
    ]:
        data = (OLD / 'retained' / name).read_bytes()
        need(blob(data)==expected, name)
        replay_refs.append(dict(wp02_path=str(OLD / 'retained' / name), git_blob=expected, size_bytes=len(data),
                                sha256=digest(data), url=f'https://api.github.com/repos/DataDog/{project}/git/blobs/{expected}',
                                representation='Decode base64 GitHub blob content to obtain retained bytes.'))
    write('FIXED_SOURCE_IDENTITY_AND_REUSE_MANIFEST.json', dict(
        agent_tree=agent_tree, operator_tree=operator_tree, acquisition=rows, reused_docs=extra, reused_sources=replay_refs,
        charts_from_fixed_wp01_inventory=[dict(path=value['published_path'], uri=value['published_uri'], sha256=value['sha256'],
                                              use='WP-01 fixed static evidence; chart not re-inspected or reacquired')
                                          for key, value in chart_inventory.items() if key in ('datadog-operator','datadog-crds')],
        source_tree_inputs=[
            dict(path=str(path), sha256=digest(path.read_bytes()), size_bytes=path.stat().st_size, url=url)
            for path, url in [
                (RAW/'agent-tree.json','https://api.github.com/repos/DataDog/datadog-agent/git/trees/7.84.1?recursive=1'),
                (OLD/'originals/operator-tree-v1.31.2.json','https://api.github.com/repos/DataDog/datadog-operator/git/trees/v1.31.2?recursive=1')]],
        prior_acceptance='LIMITED_ACCEPTANCE_RETAINED',
        original_archive_sha256=ARCHIVE, original_members=reused,
        final_contracts_sha256=CONTRACT,
        policy_v15_2_sha256='1beba6eb94197247a52718ee05d162dcda27fc6716c809f11643e683714d56e4',
        fixed_versions=dict(agent='7.84.1', operator='1.31.2', operator_chart='2.32.0', crds='2.25.0',
                            adot='v0.51.0', aws_provider='6.72.0'),
        raw_third_party_bytes='WITHHELD',
        dependency_control='No new packages, no chart reacquisition, no preexisting fixture replay.'
    ))


if __name__ == '__main__':
    main()
