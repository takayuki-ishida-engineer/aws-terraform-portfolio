"""Targeted source conclusions and reviewed configuration fragments."""
from pathlib import Path
import yaml


def qualify(schema, old_candidate, ref, write, need):
    def binding(key):
        need(key in schema, 'unsupported configuration key: ' + key)
        return dict(key=key, **schema[key])

    def sources(*pairs):
        return [ref(file, token) for file, token in pairs]

    settings = dict.fromkeys([
        'internal_profiling.enabled', 'apm_config.internal_profiling.enabled',
        'apm_config.profiling_send_to_main_endpoint', 'integration_profiling',
        'hostprofiler.ddprofiling.enabled', 'network_path.connections_monitoring.enabled',
        'network_path.connections_monitoring.basic_tests_enabled', 'network_path.netflow_monitoring.enabled',
        'network_path.remote_config.enabled', 'multi_region_failover.enabled',
        'multi_region_failover.failover_metrics', 'multi_region_failover.failover_logs',
        'multi_region_failover.failover_apm', 'remote_configuration.enabled',
        'remote_configuration.agent_integrations.enabled', 'autoconfig_from_environment',
        'agent_telemetry.enabled'], False)
    settings.update({'additional_endpoints': {}, 'apm_config.additional_endpoints': {},
                     'apm_config.profiling_additional_endpoints': {},
                     'network_path.forwarder.additional_endpoints': [], 'agent_telemetry.additional_endpoints': []})
    profilers = ['security_agent.internal_profiling.enabled', 'system_probe_config.internal_profiling.enabled']
    endpoints = []
    for key in sorted(k for k in schema if k.endswith('additional_endpoints')):
        row = binding(key)
        empty = {} if row['type'] == 'object' else []
        need(row['type'] in ('object', 'array') and row['default'] == empty, key)
        endpoints.append(dict(**row, candidate=empty, activation='BLOCKED',
                              owner='Trace Agent' if key.startswith('apm_config.') else
                              'Core Agent common forwarder' if key == 'additional_endpoints' else
                              key.split('.')[0] + ' signal forwarder'))
    add = sources(('comp_trace_config_impl_setup.go', 'appendEndpoints(c.Endpoints, "apm_config.additional_endpoints")'),
                  ('comp_trace_config_impl_setup.go', 'apm_config.telemetry.additional_endpoints'))
    add.append(ref('retained/DD-S01', 'rawAdditionalEndpoints :=', True))
    shared = ('Operator remoteConfiguration false and Agent remote_configuration.enabled false are separate controls. '
              'Inventory effective RC, fleet policy and CLI changes plus signal-specific RC.')
    def deny(intent, status, rows, owner, source, residual, witness):
        return dict(intent=intent, status=status, activation='BLOCKED', settings=rows, owner=owner,
                    source=source, residual=residual, witness=witness, remote_configuration=shared,
                    precedence='CONFIGURATION_PRECEDENCE_MATRIX.json', candidate='CANDIDATE_CONFIGURATION_SUCCESSOR.json')
    discovered = [
        deny('Profiling', 'STATIC_CONTROLS_IDENTIFIED', [binding(k) for k in (*profilers, *(k for k in settings if 'profiling' in k))],
             'Node core and Cluster Agent; independent trace-agent, system-probe, security-agent, integration and host profiler paths',
             sources(('cmd_agent_subcommands_run_command.go','SetupInternalProfiling(settings'),
                     ('cmd_cluster-agent_subcommands_start_command.go','SetupInternalProfiling(settings'),
                     ('cmd_system-probe_subcommands_run_command.go','GetBool(configPrefix + "internal_profiling.enabled")'),
                     ('cmd_security-agent_subcommands_start_command.go','GetBool(secAgentKey("internal_profiling.enabled"))'),
                     ('comp_trace_config_impl_setup.go','apm_config.profiling_send_to_main_endpoint'),
                     ('pkg_trace_api_endpoints.go','profileProxyHandler()')),
             'Native APM off does not establish other profiler states. Proxy main and replica controls are separate. Local pprof, flare recording, SDK profilers and host/integration consumers are retained verification boundaries.',
             'Effective captures and routes per process; negative IPC/CLI/flare and SDK tests; zero profiling egress.'),
        deny('Network Path', 'STATIC_CONTROLS_IDENTIFIED', [binding(k) for k in settings if k.startswith('network_path.')],
             'Core Agent Network Path collector and event platform, system-probe traceroute, config providers',
             sources(('comp_networkpath_npcollector_impl_config.go','network_path.connections_monitoring'),
                     ('comp_networkpath_npcollector_impl_npcollector.go','EventTypeNetworkPath'),
                     ('comp_core_autodiscovery_providers_networkpath_provider.go','func (p *Provider) Update('),
                     ('comp_networkpath_npcollector_impl_remote_config.go','func ')),
             'Automatic, basic, NetFlow and remote-config controls do not eliminate explicitly scheduled traceroute checks. Check separate forwarding URL overrides.',
             'No active Network Path checks, RC jobs, traceroute collection, payload or intake egress.'),
        deny('Dual Shipping', 'INSPECTED_SCHEMA_SURFACES_INVENTORIED', endpoints,
             'Core/Trace Agent, individual signal forwarders and ADOT exporters',
             add,
             'Review all inspected charts/config inputs for non-empty overrides. Distinguish primary URL/site/proxy, MRF and independent SDK or ADOT routes. Metrics, APM, profiling, process, logs, Agent/APM telemetry, debugger, orchestrator, EVP, DBM, NDM, Network Path, compliance and runtime security included. Uninspected extension/image behavior remains unknown.',
             'Effective endpoint inventory, zero replicas and parallel exports, strict egress and negative redirect checks.'),
        deny('Multi-region Failover', 'STATIC_CONTROLS_IDENTIFIED',
             [binding(k) for k in (*[k for k in settings if k.startswith('multi_region_failover.')],
                                   'multi_region_failover.site','multi_region_failover.dd_url')],
             'Node Agent metrics/logs and Trace Agent, with runtime signal toggles',
             [ref('retained/DD-S01','GetBool("multi_region_failover.enabled")',True),
              *sources(('comp_trace_config_impl_setup.go','GetBool("multi_region_failover.enabled")'),
                       ('cmd_agent_subcommands_run_command.go','NewMultiRegionFailoverRuntimeSetting'),
                       ('cmd_agent_subcommands_run_internal_settings_runtime_settings_multi_region_failover.go','config.Set('))],
             'Master and three signal toggles false. No secondary site/URL/key supplied. Fleet/CLI environment overrides remain a risk.',
             'Each effective signal off; simulated primary failure yields no secondary request.'),
        deny('Unapproved integrations and flare', 'BLOCKED_NO_COMPLETE_STATIC_CONTROL',
             [binding(k) for k in ('confd_path','config_providers','extra_config_providers','listeners','extra_listeners',
                                   'autoconfig_from_environment','ignore_autoconf','remote_configuration.enabled',
                                   'remote_configuration.agent_integrations.enabled','flare.rc_profiling.profile_duration')],
             'Core Agent check scheduler and file/annotation providers; Agent local IPC/CLI and remote tasks. Operator controllers separate.',
             sources(('cmd_agent_subcommands_run_command.go','IsRemoteConfigEnabled'),
                     ('comp_core_autodiscovery_impl_autoconfig.go','RegisterListeners'),
                     ('comp_core_autodiscovery_providers_file.go','Collect('),
                     ('cmd_agent_subcommands_flare_command.go','flareComp.Create('),
                     ('cmd_agent_subcommands_flare_command.go','flareComp.Send(')),
             'No reviewed allowlist of image and mounted conf.d, provider and annotation checks. Empty defaults and name exclusions do not guarantee no checks. A global flare disable was not established. RC deny does not disable local CLI/IPC.',
             'Review image/mounted conf.d, verify active check allowlist, deny unapproved annotation/RC providers and unauthorized flare generation/submission.'),
    ]
    write('DENIED_FEATURE_CLOSURE_DELTA.json', discovered)

    def metadata(category, disposition, keys, effect, witness, source=()):
        return dict(category=category, disposition=disposition, settings=[binding(k) for k in keys],
                    path=effect, witness=witness, source=list(source), activation='BLOCKED')
    inventory = [
        metadata('ADOT direct OTLP traces','PERMITTED_INTENT',[],
                 'Trace payload via selected HTTPS route only. No Agent OTLP and no export replication.',
                 'Intake receipt and scope, TLS, SLO statistics and no unauthorized routes.'),
        metadata('DogStatsD origin, hostname and metric tags','PERMITTED_INTENT',
                 ['dogstatsd_origin_detection','dogstatsd_origin_detection_client','dogstatsd_origin_optout_enabled'],
                 'Local UDS/send and origin processing. Selected attributes may attach to approved metrics.',
                 'Required UID/origin and hostname binding; reject unauthorized origins and filter unapproved tags.'),
        metadata('Host/gohai','CONDITIONAL',['enable_metadata_collection','enable_gohai','metadata_providers'],
                 'Provider scheduling and independent host/v5 payload. Gohai can attach to v5 or be collected through local IPC/flare.',
                 'Establish required identity subset and any registration dependency. Exclude unneeded hardware, IP, or process fields and extra submissions.',
                 sources(('comp_metadata_runner_impl_runner.go','enable_metadata_collection'),
                         ('comp_metadata_host_impl_payload.go','enable_gohai'),
                         ('comp_metadata_host_impl_host.go','SendHostMetadata'),
                         ('comp_metadata_host_impl_host.go','/metadata/gohai'))),
        metadata('Host, Agent and check inventories','DENIED',['inventories_enabled','inventories_configuration_enabled',
                 'inventories_checks_configuration_enabled','inventories_collect_cloud_provider_account_id',
                 'inventories_diagnostics_enabled','enable_signing_metadata_collection'],
                 'Separate collection and submission of host/account, check, configuration and package metadata.',
                 'No inventory or diagnostic payload; confirm local diagnostics boundary.',
                 sources(('comp_metadata_internal_util_inventory_enabled.go','inventories_enabled'),
                         ('comp_metadata_inventorychecks_impl_inventorychecks.go','inventories_checks_configuration_enabled'))),
        metadata('Autodiscovery and packaged checks','CONDITIONAL',['confd_path','config_providers','extra_config_providers',
                 'listeners','extra_listeners','autoconfig_from_environment','ignore_autoconf'],
                 'Local discovery may schedule checks, enrich tags, emit service checks or create outbound integrations.',
                 'Exact conf.d and provider/listener/annotation allowlist. Unapproved checks denied.',
                 sources(('comp_core_autodiscovery_impl_autoconfig.go','RegisterListeners'),
                         ('comp_core_autodiscovery_providers_file.go','Collect('))),
        metadata('Kubernetes metadata','CONDITIONAL',['kubernetes_collect_metadata_tags',
                 'enable_cluster_agent_metadata_collection','cluster_agent.collect_kubernetes_tags',
                 'cluster_agent.kube_metadata_collection.enabled'],
                 'Local tagger/kubelet may enrich approved metric origin. Independent inventories/events outside intent.',
                 'Exact resource/tag subset, kubelet TLS, minimal watch/SA/RBAC and no broad payloads.'),
        metadata('Agent telemetry','DENIED_EXTERNAL_CONDITIONAL_LOCAL',['agent_telemetry.enabled',
                 'agent_telemetry.additional_endpoints','telemetry.enabled','telemetry.offlinereporter.enabled'],
                 'Separate Agent telemetry forwarder; local diagnostics only if required and scoped.',
                 'No independent Agent telemetry call; verify local listeners, access and exposure.',
                 sources(('comp_core_agenttelemetry_impl_config.go','IsAgentTelemetryEnabled'))),
        metadata('Health, service checks and API key validation','CONDITIONAL_LOCAL_UNKNOWN_WIRE',
                 ['health_port','health_platform.enabled','enable_payloads.events','enable_payloads.service_checks',
                  'enable_payloads.json_to_v1_intake','forwarder_apikey_validation_interval'],
                 'Local probe path differs from remote health-platform, service checks and forwarder API validation.',
                 'Retain needed local health. Observe exact independently transmitted endpoint/path and payload before approval.',
                 sources(('cmd_agent_subcommands_run_command.go','health_platform.enabled'),
                         ('comp_forwarder_defaultforwarder_impl_forwarder_health.go','V1ValidateEndpoint'))),
        metadata('Remote configuration and flare','DENIED',['remote_configuration.enabled',
                 'remote_configuration.agent_integrations.enabled','flare.rc_profiling.profile_duration'],
                 'RC can mutate behavior; local CLI/IPC can create archives and submit separately.',
                 'No RC tasks or unapproved diagnostic capture or archive egress.',
                 sources(('cmd_agent_subcommands_flare_command.go','flareComp.Create('),
                         ('cmd_agent_subcommands_flare_command.go','flareComp.Send('))),
        metadata('Monitor/SLO controllers','PERMITTED_INTENT',[],
                 'Scoped CR reconciliation and Datadog API. Separate from Agent telemetry.',
                 'Exact watch/RBAC/credentials/verbs and effective Monitor/SLO operations.'),
        metadata('Other or unmapped payloads and integration','UNKNOWN',[],
                 'Unverified dependencies and wire categories. No deployment default.',
                 'Explicit review, deny or scope approval before activation.'),
    ]
    write('MINIMUM_METADATA_AND_INTEGRATION_INVENTORY.json', inventory)
    describe_precedence_and_conflict(ref, write, sources)
    need(old_candidate['spec']['override']['clusterAgent']['disabled'] is True, 'WP-01 Cluster Agent intent')
    need(old_candidate['spec']['features']['dogstatsd']['originDetectionEnabled'] is True, 'WP-01 origin detection')
    need(old_candidate['spec']['features']['remoteConfiguration']['enabled'] is False, 'WP-01 RC intent')
    fragment = {}
    for key, value in settings.items():
        need(type(value) is {'array':list,'object':dict,'boolean':bool}[binding(key)['type']], key)
        *parents, leaf = key.split('.')
        dest = fragment
        for parent in parents:
            dest = dest.setdefault(parent,{})
        dest[leaf] = value
    Path('candidate-agent-denials.yaml').write_text(
        '# SOURCE-ONLY BLOCKED REVIEW FRAGMENT. Never apply or mount as a complete file.\n'
        '# Node Agent datadog.yaml intent. Full config, per-process assignment and effective layers require review.\n'
        + yaml.safe_dump(fragment, sort_keys=True))
    write('CANDIDATE_CONFIGURATION_SUCCESSOR.json', dict(
        activation='BLOCKED', baseline='WP-01 candidate-datadogagent.yaml, candidate-adot.yaml and candidate-operator-values.yaml retained',
        fragment='candidate-agent-denials.yaml',
        process_specific_review=[dict(**binding(k), reviewed_value=False,
                                      placement='system-probe.yaml' if k.startswith('system_probe_config.') else 'security-agent.yaml')
                                 for k in profilers],
        replica_policy='Every inventoried additional endpoint collection must be empty after merging; no supplemental route.',
        preserve=['Cluster Agent disabled','DogStatsD UDS and origin detection','Agent OTLP and native APM off',
                  'Monitor/SLO scoped controllers','ADOT direct trace only'],
        values_withheld=['unknown metadata and image/check allowlist','Datadog site and credentials',
                         'Cluster Agent client override deployment','role scope and runtime egress']))


def describe_precedence_and_conflict(ref, write, sources):
    write('CONFIGURATION_PRECEDENCE_MATRIX.json', dict(
        policy='Higher-priority contradictions and unknown effective input are BLOCKED.',
        layers=[
            ['Image files', 'Each customConfigurations file replaces the corresponding image file, requiring a complete reviewed replacement.'],
            ['Operator overrides', 'Container env > component env; explicit env > envFrom. Review generated feature/global env and image inputs, including init and sidecars.'],
            ['Agent ascending priority', 'Default, unknown, infrastructure mode, file, env, fleet policies, post-init, secret, local config process, Agent runtime, Remote Configuration, CLI.'],
            ['Agent bindings', 'Explicit schema names or DD_ + uppercase dotted key with dots replaced by underscores. Derived names use the documented model fallback and are not runtime observations.'],
            ['Effective config', 'Include actual mounted files, resolved projected env, injection, Agent fixups, key ordering, fleet policy, RC and CLI/IPC.'],
        ],
        source=sources(('op-docs_configuration.v2alpha1.md','replaces the corresponding default file'),
                       ('op-docs_configuration.v2alpha1.md','Priority is Container > Component'),
                       ('op-docs_configuration.v2alpha1.md','Priority is env > envFrom'),
                       ('pkg_config_nodetreemodel_config.go','sources lists the known sources'),
                       ('pkg_config_nodetreemodel_config.go','mergeWithEnvPrefix derives'),
                       ('pkg_config_create_new.go','NewNodeTreeConfig(name, "DD"'),
                       ('pkg_config_setup_fixup_init.go','applyKubernetesContainerDefaults')),
        retained_source=ref('retained/DD-S02','This calls the generate code from the schema',True)))
    op = 'originals/op-internal_controller_datadogagent_'
    write('CLUSTER_AGENT_CONFLICT_ANALYSIS.json', dict(
        outcome='BLOCKED_DESIGN_CONFLICT', activation='BLOCKED',
        reasoning=[
         'Registered Default Feature always returns RequiredComponents.ClusterAgent.IsRequired=true. BuildFeatures merges the requirements and no approved switch for Default has been established.',
         'DatadogAgent constructs DDAI with copied overrides, manages dependencies then creates/updates DDAI. The DDAI controller is registered whenever DatadogAgent is enabled.',
         'DDAI recalculates features. Component resolution honors disabled; the required component branch records OverrideConflict and invokes cleanup instead of generating its Deployment.',
         'Node Agent follows its separate reconciliation subject to provider and dependency gates. Its default container config injects Cluster Agent enabled plus service and token references. An env override can target the client flag but leaves Default requirement, conflict and verification of all dependent metadata paths unresolved.',
         'Monitor/SLO controller registration runs behind separate flags. These controllers do not change the Default Feature or resolve Node Agent dependencies.',
        ],
        required_decision='A later supported design must preserve Cluster Agent disabled and demonstrate reconciliation, intended Node Agent/DogStatsD dependencies and Monitor/SLO behavior. No such conflict-free path was established within fixed version and scope.',
        source=[ref(op+'feature_enabledefault_feature.go','feature.Register(feature.DefaultIDType',True),
                ref(op+'feature_enabledefault_feature.go','IsRequired: &trueValue',True),
                ref(op+'component_clusteragent.go','requiredComponents.ClusterAgent.IsEnabled()',True),
                ref(op+'component_reconciler.go','res, err = r.Cleanup',True),
                ref(op+'component_reconciler.go','"OverrideConflict"',True),
                ref(op+'reconcile.go','r.generateDDAIFromDDA',True),
                ref(op+'reconcile.go','r.manageDDADependenciesWithDDAI',True),
                ref(op+'reconcile.go','r.createOrUpdateDDAI',True),
                *sources(('op-internal_controller_datadogagent_feature_factory.go','requiredComponents.Merge'),
                         ('op-internal_controller_datadogagent_ddai.go','override.SetOverrideFromDDA'),
                         ('op-internal_controller_datadogagentinternal_reconcile.go','feature.BuildFeatures'),
                         ('op-internal_controller_datadogagentinternal_reconcile.go','r.reconcileV2Agent'),
                         ('op-internal_controller_datadogagentinternal_reconcile_agent.go','NewDefaultAgentDaemonset'),
                         ('op-internal_controller_datadogagent_component_agent_default.go','Name:  common.DDClusterAgentEnabled'),
                         ('op-internal_controller_datadogagent_component_agent_default.go','Name:  common.DDClusterAgentTokenName'),
                         ('op-internal_controller_datadogagent_component_clusteragent_default.go','NewDefaultClusterAgentDeployment'),
                         ('op-internal_controller_setup.go','DatadogAgentInternal is always enabled'),
                         ('op-internal_controller_setup.go','if !options.DatadogMonitorEnabled'),
                         ('op-internal_controller_setup.go','if !options.DatadogSLOEnabled'))]))
