"""Exercise candidate guards using synthetic observations. No clients or processes are started."""
from copy import deepcopy
from pathlib import Path
import json
import re
import yaml

from chart_inspect import inventory, ensure, emit, sha
from qualify import FEATURE_MAP, DRY_DENIALS, review_schema

EXPECTED="cd09cd0e883dcd9bdac7883abf141161ca937c3bf7b14bc970f1b5cd7fd22dab"


def pick(data,path):
    for k in path.split("."):
        if type(data) is not dict: return None
        data=data.get(k)
    return data


def reject(code): return ("REJECT",code)


def evaluate(f,schema):
    table=f["endpoint_table"]
    sites={row["site"] for row in table}
    if f["site"] not in sites:return reject("SITE_UNKNOWN")
    if f["feature"] not in {row["feature"] for row in table}:return reject("FEATURE_UNKNOWN")
    if review_schema(f["spec"],schema["properties"]["spec"]):return reject("UNSUPPORTED_CR_FIELD")
    if any(f.get("desired_feature_flags",{}).get(name) is True for name in set(FEATURE_MAP)|set(DRY_DENIALS)) or any(
        pick(f["spec"],"features."+p) is True for p,_,_ in FEATURE_MAP.values()):
        return reject("DENIED_FEATURE_ENABLED")
    host=f["host"]
    if "*" in host:return reject("WILDCARD_FQDN")
    if (f["site"],f["feature"],host) not in {(r["site"],r["feature"],r["host"]) for r in table}:
        return reject("ENDPOINT_UNAPPROVED")
    if set(f["cname_targets"])-set(f["reviewed_cname_targets"]):return reject("CNAME_UNREVIEWED")
    if set(f["redirect_targets"])-set(f["reviewed_redirect_targets"]):return reject("REDIRECT_UNAPPROVED")
    if (not re.fullmatch(r"[a-z0-9][a-z0-9.-]+[a-z0-9]",host)
        or f["dns_query"].removesuffix(".")!=host or f["tls_sni"]!=host):
        return reject("DNS_SNI_MISMATCH")
    if f["slo_uses_intake_stats"] and f["upstream_sampling"]:
        return reject("SAMPLING_BIASED_SLO")
    if f["native_apm_same_signal"] and f["direct_otlp"]:
        return reject("DUPLICATE_TRACE_SIGNAL")
    if f["same_host_alternative"] and f["source_node"]!=f["dest_node"]:
        return reject("CROSS_HOST_ROUTE")
    if not f["authentication_reference"]:
        return reject("AUTH_REFERENCE_MISSING")
    if f["synthetic_effective_inventory_present"] is not True:
        return ("BLOCKED","EFFECTIVE_CONFIG_UNKNOWN")
    return ("ACCEPT","SYNTHETIC_ONLY")


def main(result_path):
    raw=Path("EXPECTED_FIXTURE_MANIFEST.json").read_bytes()
    ensure(sha(raw)==EXPECTED,"EXPECTED_MANIFEST_CHANGED")
    archives,_,schema=inventory()
    tables=json.loads(Path("ENDPOINT_42_ROWS.json").read_bytes())
    flows=json.loads(Path("FLOW_15_ROWS.json").read_bytes())
    ensure(len(tables)==42 and len(flows)==15,"ROW_COUNT")
    spec=yaml.safe_load(Path("candidate-datadogagent.yaml").read_bytes())["spec"]
    base={"endpoint_table":tables,"site":"US1","feature":"otlp_http","spec":spec,
          "host":"otlp.datadoghq.com","dns_query":"otlp.datadoghq.com.","tls_sni":"otlp.datadoghq.com",
          "cname_targets":[],"reviewed_cname_targets":[],"redirect_targets":[],"reviewed_redirect_targets":[],
          "slo_uses_intake_stats":True,"upstream_sampling":False,
          "native_apm_same_signal":False,"direct_otlp":True,"same_host_alternative":False,
          "source_node":"test-node","dest_node":"test-node","authentication_reference":"synthetic-ref",
          "synthetic_effective_inventory_present":True}
    changes={
      "positive":{},"unknown-site":{"site":"OTHER"},"unknown-feature":{"feature":"unreviewed"},
      "unapproved-endpoint":{"host":"not-listed.example.invalid"},"wildcard":{"host":"*.datadoghq.com"},
      "cname":{"cname_targets":["shadow.example.invalid"]},"redirect":{"redirect_targets":["shadow.example.invalid"]},
      "dns-sni":{"tls_sni":"alias.example.invalid"},"sampling":{"upstream_sampling":True},
      "duplicate-apm":{"native_apm_same_signal":True},
      "cross-host":{"same_host_alternative":True,"direct_otlp":False,"dest_node":"other-node"},
      "unknown-effective":{"synthetic_effective_inventory_present":False},"missing-auth":{"authentication_reference":None},
    }
    out=[]
    for case,expected_outcome,expected_reason in json.loads(raw):
        f=deepcopy(base)
        if case=="unsupported-cr-field":f["spec"]["features"]["unproven"]=True
        elif case=="denied-feature":f["spec"]["features"]["remoteConfiguration"]["enabled"]=True
        else:f.update(changes[case])
        actual,reason=evaluate(f,schema)
        out.append(dict(id=case,expected=[expected_outcome,expected_reason],actual=[actual,reason],
                        match=(actual,reason)==(expected_outcome,expected_reason)))
    ensure(all(r["match"] for r in out),"FIXTURE_FAILURE")
    m=json.loads(Path("FEATURE_CONFIGURATION_MATRIX.json").read_bytes())
    statuses={}
    for row in m:statuses[row["status"]]=statuses.get(row["status"],0)+1
    emit(result_path,dict(fixture_count=len(out),fixture_pass=sum(x["match"] for x in out),
         fixtures=out,expected_sha256=sha(raw),archive_safety={k:v["archive_safety"] for k,v in archives.items()},
         verified_schema="datadogagents.datadoghq.com v2alpha1 served and storage; static-only field/name/type check",
         features=len(m),feature_status_counts=statuses,endpoint_rows=len(tables),flow_rows=len(flows),
         helm_render="NOT_TESTED",effective_reconciliation="NOT_TESTED",network_and_slo="NOT_TESTED",
         telemetry_transmitted=False,activation_authorized=False))
    print(len(out),"expected fixtures reproduced")

if __name__=="__main__":
    import sys
    main(sys.argv[1])
