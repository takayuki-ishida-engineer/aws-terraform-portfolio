"""Fixed public source reads for Datadog v1.31.2, Agent 7.84.1, ADOT v0.51.0."""
import concurrent.futures,json,hashlib,re,subprocess
from datetime import datetime,timezone
from pathlib import Path

repo_op="DataDog/datadog-operator"
repo_ag="DataDog/datadog-agent"
repo_ad="aws-observability/aws-otel-collector"
base="internal/controller/datadogagent"
features=("admissioncontroller apm clusterchecks cspm cws dataplane dogstatsd eventcollection externalmetrics "
          "kubernetesactions kubernetesstatecore livecontainer liveprocess logcollection npm orchestratorexplorer "
          "otelagentgateway otelcollector otlp processdiscovery prometheusscrape remoteconfig sbom usm").split()
groups={
 repo_op:("v1.31.2","operator-tree-v1.31.2.json",[
 f"{base}/defaults/datadogagent_default.go",f"{base}/reconcile.go",f"{base}/reconcile_common.go",
 f"{base}/override/podtemplatespec.go",f"{base}/override/container.go",f"{base}/component_clusteragent.go",
 "internal/controller/datadogmonitor/controller.go","internal/controller/datadogslo/controller.go",
 *[f"{base}/feature/{f}/feature.go" for f in features]]),
 repo_ad:("v0.51.0","adot-tree-v0.51.0.json",["go.mod","vendor/go.opentelemetry.io/collector/exporter/otlphttpexporter/config.go",
        "vendor/go.opentelemetry.io/collector/exporter/otlphttpexporter/factory.go","cmd/awscollector/main.go"]),
 repo_ag:("7.84.1","agent-setup-list-7.84.1.json",["pkg/config/setup/config_init.go","pkg/config/setup/otlp.go",
        "pkg/config/setup/process.go","pkg/config/setup/system_probe.go"]),
}
def fetch(row):
    repo,tag,p,pin=row
    n=("op" if repo==repo_op else "adot" if repo==repo_ad else "agent")+"-"+p.replace("/","_")
    file=Path("originals")/n
    url=f"https://raw.githubusercontent.com/{repo}/{tag}/{p}"
    at=datetime.now(timezone.utc).isoformat()
    cmd=["curl","-q","-sS","--proto","=https","--connect-timeout","6","--max-time","13","--max-filesize","2097152",
         "-o",str(file),"-w","%{http_code} %{http_connect}",url]
    result=subprocess.run(cmd,capture_output=True,check=False)
    status,proxy=(result.stdout.decode().split()+["000","000"])[:2]
    info=dict(path=str(file),source_path=p,url=url,utc=at,http_status=int(status),proxy_connect=int(proxy),expected_git_blob=pin)
    if status=="200" and result.returncode==0:
        b=file.read_bytes()
        actual=hashlib.sha1(f"blob {len(b)}\0".encode()+b).hexdigest()
        info.update(sha256=hashlib.sha256(b).hexdigest(),size_bytes=len(b),
            observed_git_blob=actual,match=pin==actual)
    return info
def main():
    candidates=[]
    for repo,(tag,index,paths) in groups.items():
        d=json.loads((Path("originals")/index).read_bytes())
        idx={r["path"]:r["sha"] for r in (d if isinstance(d,list) else d["tree"])}
        for p in paths:
            if p in idx:candidates.append((repo,tag,p,idx[p]))
            else:print("Path missing from fixed listing:",p)
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        rows=list(pool.map(fetch,candidates))
    Path("source-fetch.json").write_text(json.dumps(rows,indent=2)+"\n")
    print(len(rows),sum(r.get("match") is True for r in rows))
if __name__=="__main__": main()
