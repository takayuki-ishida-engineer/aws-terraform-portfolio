"""Offline Datadog configuration and fixed endpoint qualification. No network calls."""
from pathlib import Path
from html.parser import HTMLParser
from datetime import datetime,timezone,timedelta
import gzip
import json
import re
import yaml

from chart_inspect import sha, ensure, emit, inventory

CONTRACT="29a396daf7cadb9eee1f089b7ac427fcb7b7c9100f6e170ac97a3bcbd633a783"
DOCS={
 "network":"https://docs.datadoghq.com/agent/configuration/network/",
 "sites":"https://docs.datadoghq.com/getting_started/site/",
 "otlp":"https://docs.datadoghq.com/opentelemetry/setup/otlp_ingest/traces/",
 "trace-metrics":"https://docs.datadoghq.com/opentelemetry/integrations/trace_metrics/",
 "agent-otlp":"https://docs.datadoghq.com/opentelemetry/setup/otlp_ingest_in_the_agent/",
}
OP="internal/controller/datadogagent/"
DD03="retained/DD-S03"
DD01="retained/DD-S01"
DD02="retained/DD-S02"
DD04="retained/DD-S04"
FEATURE_MAP={
 "logs":("logCollection.enabled","LogCollection.Enabled","logcollection"),
 "liveProcessCollection":("liveProcessCollection.enabled","LiveProcessCollection.Enabled","liveprocess"),
 "liveContainerCollection":("liveContainerCollection.enabled","LiveContainerCollection.Enabled","livecontainer"),
 "processDiscovery":("processDiscovery.enabled","ProcessDiscovery.Enabled","processdiscovery"),
 "orchestratorExplorer":("orchestratorExplorer.enabled","OrchestratorExplorer.Enabled","orchestratorexplorer"),
 "kubeStateMetricsCore":("kubeStateMetricsCore.enabled","KubeStateMetricsCore.Enabled","kubernetesstatecore"),
 "eventCollection":("eventCollection.collectKubernetesEvents","EventCollection.CollectKubernetesEvents","eventcollection"),
 "prometheusScrape":("prometheusScrape.enabled","PrometheusScrape.Enabled","prometheusscrape"),
 "remoteConfiguration":("remoteConfiguration.enabled","RemoteConfiguration.Enabled","remoteconfig"),
 "clusterChecks":("clusterChecks.enabled","ClusterChecks.Enabled","clusterchecks"),
 "externalMetricsServer":("externalMetricsServer.enabled","ExternalMetricsServer.Enabled","externalmetrics"),
 "admissionController":("admissionController.enabled","AdmissionController.Enabled","admissioncontroller"),
 "dataPlane":("dataPlane.enabled","DataPlane.Enabled","dataplane"),
 "otelCollector":("otelCollector.enabled","OtelCollector.Enabled","otelcollector"),
 "otelAgentGateway":("otelAgentGateway.enabled","OtelAgentGateway.Enabled","otelagentgateway"),
 "kubernetesActions":("kubernetesActions.enabled","KubernetesActions.Enabled","kubernetesactions"),
 "npm":("npm.enabled","NPM.Enabled","npm"),
 "usm":("usm.enabled","USM.Enabled","usm"),
 "cspm":("cspm.enabled","CSPM.Enabled","cspm"),
 "cws":("cws.enabled","CWS.Enabled","cws"),
 "sbom":("sbom.enabled","SBOM.Enabled","sbom"),
}
DRY_DENIALS={"profiling":"SDK/Agent multi-surface configuration; exact aggregate off control not established",
 "network_path":"May be integration or tracer-generated; fixed end-to-end disable mapping is unresolved",
 "dual_shipping":"No generic CR switch; independently inspect effective additional endpoint settings and ADOT exporters",
 "multi_region_failover":"Agent has multi-region endpoint settings; complete fixed-default/override exclusion not established",
 "unapproved integrations and flare":"Per integration, autodiscovery, support bundle/flare and metadata egress policy remain open"}
SOURCE_FILES=json.loads(Path("source-fetch.json").read_bytes())+json.loads(Path("source-followup.json").read_bytes())
BF={r["source_path"]:r for r in SOURCE_FILES if r.get("match") is True}
for r in SOURCE_FILES:
 if r.get("match"):
    ensure(len(Path(r["path"]).read_bytes())==r["size_bytes"] and sha(Path(r["path"]).read_bytes())==r["sha256"],"FIXED_SOURCE_CHANGED")
BLOBS={
 DD01:"651377bf2bdabf280bae0c168596ca13c311a8b7",DD02:"ac7376b6c18d531a7b397815e5a3fac1bc8c3405",
 DD03:"4880eb5810e2e00361b111ae523b43050c781643",DD04:"e7c15dd2e9e99756ebe4959a786a6567578a50d6"
}
from hashlib import sha1
for p,h in BLOBS.items():
 b=Path(p).read_bytes()
 ensure(sha1(f"blob {len(b)}\0".encode()+b,usedforsecurity=False).hexdigest()==h,"RETAINED_GIT_BLOB")
ensure(BF["go.mod"]["expected_git_blob"]=="c8ffe1b7cc678ba8ddb3def281c24764605e1813","ADOT_MODULE_PIN")


def place(path):
    return BF[path]["path"]


def source(path, token, limit=10):
    lines=Path(path).read_text().splitlines()
    result=[n for n,s in enumerate(lines,1) if token in s][:limit]
    if path in BLOBS: h=BLOBS[path]
    else: h=next((r["expected_git_blob"] for r in BF.values() if r["path"]==path),None)
    return {"path":path,"git_blob":h,"token":token,"lines":result}


class Visible(HTMLParser):
    def __init__(self):
        super().__init__();self.skip=0;self.data=[]
    def handle_starttag(self,tag,attrs):
        if tag in ("script","style"):self.skip+=1
    def handle_endtag(self,tag):
        if tag in ("script","style") and self.skip:self.skip-=1
    def handle_data(self,data):
        if not self.skip:self.data.append(data)


def doc_value(name):
    b=Path(f"originals/{name}.html").read_bytes()
    if b.startswith(b"\x1f\x8b"):
        from io import BytesIO
        with gzip.GzipFile(fileobj=BytesIO(b)) as stream:b=stream.read(6_000_001)
        ensure(len(b)<=6_000_000,"DOC_SIZE")
    text=Visible();text.feed(b.decode(errors="replace"))
    return " ".join(" ".join(text.data).split())


def locate(schema,path):
    x=schema
    for p in path.split("."):
        x=x.get("properties",{}).get(p) or x.get("additionalProperties") or {}
    return x if isinstance(x,dict) else {}


def put(obj,path,value):
    parts=path.split(".")
    for p in parts[:-1]:obj=obj.setdefault(p,{})
    obj[parts[-1]]=value


def review_schema(data,schema,prefix=""):
    typ=schema.get("type")
    valid={"object":dict,"string":str,"boolean":bool,"array":list,"integer":int}
    if typ in valid and type(data) is not valid[typ]: return prefix or "<root>"
    if isinstance(data,dict):
        for key,value in data.items():
            node=schema.get("properties",{}).get(key) or schema.get("additionalProperties")
            p=f"{prefix}.{key}" if prefix else key
            if not isinstance(node,dict):return p
            issue=review_schema(value,node,p)
            if issue:return issue
        if any(k not in data for k in schema.get("required",[])):return prefix or "<root>"
    elif isinstance(data,list):
        for v in data:
            issue=review_schema(v,schema.get("items",{}),prefix+"[]")
            if issue:return issue
    return None


def defaults_value(key):
    path=place(OP+"defaults/datadogagent_default.go")
    lines=Path(path).read_text().splitlines()
    const=re.compile(r"^\s*(\w+)\s+bool\s*=\s*(true|false)\b")
    known={m[1]:(m[2]=="true",n) for n,s in enumerate(lines,1) if (m:=const.search(s))}
    out=[]
    for n,s in enumerate(lines,1):
        m=re.search(r"DefaultBooleanIfUnset\(&ddaSpec\.Features\."+re.escape(key)+r",\s*(\w+)\)",s)
        if m:
            value,num=known.get(m[1],(None,None))
            out.append(dict(path=path,git_blob=BF[OP+"defaults/datadogagent_default.go"]["expected_git_blob"],
                            assignment_line=n,default_constant=m[1],constant_line=num,value=value))
    return out


def generated(path):
    # Record fixed reconciler symbol locations, without treating feature removal as an env=false value.
    lines=Path(path).read_text().splitlines()
    return [{"line":n,"symbol":m[1]} for n,s in enumerate(lines,1)
            if (m:=re.search(r"Name:\s+((?:common\.|constants\.)?DD\w+)",s))][:14]


def config(contract,schema):
    rows=[]
    expected=set(contract["feature_intent"]["deny_or_disable"])
    ensure(expected==set(FEATURE_MAP)|set(DRY_DENIALS),"DENIED_SCOPE_CHANGED")
    cr={"apiVersion":"datadoghq.com/v2alpha1","kind":"DatadogAgent",
        "metadata":{"name":"b09-static-candidate","annotations":{"portfolio.example.invalid/activation":"blocked"}},
        "spec":{"global":{},"features":{},"override":{"clusterAgent":{"disabled":True}}}}
    for feature in sorted(expected):
        if feature in DRY_DENIALS:
            rows.append(dict(intent=feature,desired="DENY",field=None,type=None,default="UNKNOWN",
                 precedence="UNKNOWN",generated_candidate="UNRESOLVED_NO_EMITTED_FIELD",
                 evidence=[source(DD03,feature),source(DD02,feature)],
                 status="BLOCKED_NO_EXACT_CONTROL",activation="BLOCKED",reason=DRY_DENIALS[feature]))
            continue
        short,go,impl=FEATURE_MAP[feature]
        field="spec.features."+short
        ensure(locate(schema,field).get("type")=="boolean","CRD_BOOLEAN_"+feature)
        put(cr,field,False)
        path=place(OP+f"feature/{impl}/feature.go")
        defaults=defaults_value(go)
        precedence=("Explicit CR field > legacy annotation > Operator deployment default"
                    if feature=="dataPlane" else "Source default only when unset if evidenced. Feature enabler is separate from later Pod/container/env/config overrides.")
        if feature=="sbom":precedence+=" Remote-config status merge is present; effective no-reenable must be verified."
        rows.append(dict(intent=feature,desired=False,field=field,type="boolean",
          default=(defaults or ("chart default auto: AP1/AP2 under eligible Agent when unset" if feature=="dataPlane" else
                                "OPERATOR_DEFAULT_CONDITIONAL_OR_UNPROVEN")),
          override_precedence=precedence,
          generated_candidate={"feature_branch":"disabled by explicit false candidate; downstream omission or rendered env proof pending",
                               "env_symbols_in_feature_source":generated(path)},
          evidence=[source(DD03,'json:"'+short.split(".")[0]+',omitempty"'),source(path,"Configure("),
                    source(path,"."+go),source(place(OP+"override/container.go"),"addEnvsToContainer"),
                    *([source(place(OP+"feature/utils/utils.go"),"IsDataPlaneEnabled")] if feature=="dataPlane" else [])],
          status="FIELD_VERIFIED_EFFECTIVE_UNKNOWN",activation="BLOCKED"))
    extra={
      "spec.features.apm.enabled":False,
      "spec.features.otlp.receiver.protocols.grpc.enabled":False,
      "spec.features.otlp.receiver.protocols.http.enabled":False,
      "spec.features.dogstatsd.hostPortConfig.enabled":False,
      "spec.features.dogstatsd.unixDomainSocketConfig.enabled":True,
      "spec.features.dogstatsd.nonLocalTraffic":False,
      "spec.features.dogstatsd.originDetectionEnabled":True,
      "spec.features.controlPlaneMonitoring.enabled":False,
      "spec.features.dynamicInstrumentation.enabled":False,
      "spec.override.nodeAgent.hostNetwork":False,
      "spec.override.nodeAgent.image.name":"registry.datadoghq.com/agent",
      "spec.override.nodeAgent.image.tag":"7.84.1",
    }
    for field,value in extra.items():
        ensure(locate(schema,field).get("type") == ("boolean" if type(value) is bool else "string"),"CANDIDATE_FIELD_"+field)
        put(cr,field,value)
    ensure(review_schema(cr["spec"],schema["properties"]["spec"]) is None,"CANDIDATE_CR_SCHEMA")
    rows.extend([
      dict(intent="ADOT direct OTLP traces / no native APM duplicate",desired="ADOT_HTTP_TRACE_ONLY",
           field="spec.features.apm.enabled and spec.features.otlp.receiver.protocols.{grpc,http}.enabled",
           type="boolean",default=defaults_value("APM.Enabled")+defaults_value("OTLP.Receiver.Protocols.GRPC.Enabled")+defaults_value("OTLP.Receiver.Protocols.HTTP.Enabled"),
           override_precedence="Explicit false candidate for primary path; component/env overrides and SDK must not open alternate intake.",
           generated_candidate="Disable native Agent APM and both Agent OTLP receivers; keep the trace-only ADOT candidate separate.",
           evidence=[source(DD04,"otlphttpexporter.NewFactory"),source(place(OP+"feature/apm/feature.go"),"DDAPMEnabled")],
           status="FIELDS_VERIFIED_EFFECTIVE_UNKNOWN",activation="BLOCKED"),
      dict(intent="scoped DogStatsD",desired="SAME_NODE_ONLY_NO_HOSTPORT",
           field="spec.features.dogstatsd.{nonLocalTraffic,hostPortConfig.enabled,unixDomainSocketConfig.enabled,originDetectionEnabled}",
           type="boolean",default=sum((defaults_value("Dogstatsd."+f) for f in ("NonLocalTraffic","OriginDetectionEnabled","UnixDomainSocketConfig.Enabled")),[]),
           override_precedence="Explicit fields; ADP delegation must remain disabled and no generic container overrides.",
           generated_candidate="UDS only for explicitly authorized mounts; localhost UDP candidate, no nonlocal or hostPort. Socket ACL, paths and source scope are open.",
           evidence=[source(place(OP+"feature/dogstatsd/feature.go"),"AddEnvVarToContainer")],
           status="FIELD_VERIFIED_PER_NODE_SCOPE_OPEN",activation="BLOCKED"),
      dict(intent="Monitor/SLO reconciliation",desired=True,field="Helm values datadogMonitor.enabled / datadogSLO.enabled; matching bundled CRDs",
           type="boolean",default=False,override_precedence="Chart values and separately observed Operator Pod/controller runtime flags",
           generated_candidate="Separate Operator API controller paths; scoped Operator App/API key refs and watchNamespacesMonitor/SLO allowlists remain open. Defaults may watch broadly; no deployment.",
           evidence=[source(place("internal/controller/datadogmonitor/controller.go"),"Reconcile"),
                     source(place("internal/controller/datadogslo/controller.go"),"Reconcile")],
           status="CONTROLLERS_STATICALLY_SEPARATE_FROM_CLUSTER_AGENT",activation="BLOCKED"),
      dict(intent="required minimum metadata only",desired="MINIMUM_ALLOWLIST",
           field=None,type=None,default="CORE_AGENT_DEFAULT_INVENTORY_OPEN",
           override_precedence="Operator feature merge + Agent config loader runtime sources; explicit metadata allowlist unresolved.",
           generated_candidate="No arbitrary tags/checks/integrations or flare. Candidate disables Operator metrics and extra metadata-heavy features. Node Agent payload classes still unknown.",
           evidence=[source(DD02,"AgentRuntime")],status="BLOCKED_NO_COMPLETE_PAYLOAD_INVENTORY",activation="BLOCKED"),
      dict(intent="Cluster Agent disabled",desired=True,field="spec.override.clusterAgent.disabled",
           type="boolean",default="Default feature requires ClusterAgent",
           override_precedence="Component required + override.disabled produces conflict and returns false, true",
           generated_candidate="Disabled override kept in candidate; conflict and remaining reconcile effects unverified.",
           evidence=[source(place(OP+"feature/enabledefault/feature.go"),"ClusterAgent:"),
                     source(place(OP+"component_reconciler.go"),"componentRequired"),source(place(OP+"reconcile.go"),"DefaultDatadogAgentSpec")],
           status="CONFIRMED_STATIC_DEFAULT_REQUIREMENT_CONFLICT",activation="BLOCKED")
    ])
    return rows,cr


def chart_values(original):
    v={"operatorMetricsEnabled":"false","collectOperatorMetrics":False,"defaultDataPlaneEnabled":{"linux":"false"},
       "datadogMonitor":{"enabled":True},"datadogSLO":{"enabled":True},"installCRDs":True,
       "datadogCRDs":{"crds":{n:n in {"datadogAgents","datadogMonitors","datadogSLOs"}
                             for n in original["datadogCRDs"]["crds"]}},
       "image":{"repository":"registry.datadoghq.com/operator","tag":"1.31.2","doNotCheckTag":False}}
    for k,typed in v.items():
        ensure(k in original and type(typed) is type(original[k]),"CHART_VALUES_TYPE_"+k)
    return v


def route_matrix(docs):
    sources={
      "registered_receiver":source(DD04,"otlpreceiver.NewFactory"),
      "registered_otlp_http":source(DD04,"otlphttpexporter.NewFactory"),
      "registered_probabilistic_sampler":source(DD04,"probabilisticsamplerprocessor.NewFactory"),
      "registered_tail_sampler":source(DD04,"tailsamplingprocessor.NewFactory"),
      "span_metrics_registration":source(DD04,"spanmetrics"),
      "datadog_exporter_gate":source(DD04,"IsEnabled()"),
      "http_exporter_traces_endpoint":source(place("vendor/go.opentelemetry.io/collector/exporter/otlphttpexporter/config.go"),"traces_endpoint"),
    }
    ensure(sources["registered_receiver"]["lines"] and sources["registered_otlp_http"]["lines"]
           and not sources["span_metrics_registration"]["lines"],"ADOT_COMPONENT_MATRIX")
    ensure("compute_stats" in docs["otlp"] and "/v1/traces" in docs["otlp"] and
           "before any sampling" in docs["trace-metrics"] and "localhost:4318" in docs["agent-otlp"],"DOCUMENTED_ROUTE")
    common={"activation":"BLOCKED","tls":"TLS identity and CA verification required; redirect and SG/NP/NFW checks OPEN",
            "billing":"No paid intake authorized; projected volume and product cost require evidence"}
    return {
      "fixed_sources":sources,
      "A":{**common,"route":"ADOT otlphttp direct trace-only","status":"DESIGN_CANDIDATE_BLOCKED",
           "receiver":"Private OTLP/HTTP trace receiver; certificate/SA boundary not selected",
           "exporter":"otlphttp explicit traces_endpoint .../v1/traces; dd-api-key via deferred reference and compute_stats: 'true'",
           "sdk_sampling":"AlwaysOn intent plus no upstream/Collector span sampling; ensure upstream SDK honors policy",
           "red_source":"Datadog intake computes from spans received; dropped/incomplete/span naming differences can bias or change RED",
           "duplicates":"Disable native APM and Agent OTLP for the direct route. No parallel second exporter or SDK direct bypass.",
           "slo_correctness":"OPEN received-completeness, retry/202 acknowledgement, deduplication, RED semantics and actual SLO",
           "additional_endpoint":"Exact per-site intake hostname and route closure. Higher trace volume remains unbudgeted."},
      "B":{**common,"route":"Sample after generating metrics from all spans","status":"BLOCKED_DESIGN_CONFLICT",
           "receiver":"OTLP receiver exists, sampler registration is separate",
           "exporter":"otlphttp exists; Datadog exporter conditional on adot.exporter.datadogexporter.deprecation; neither proves a registered pre-sampling connector",
           "sdk_sampling":"SDK must deliver all spans before metric generation; Collector sampling afterward would bias intake-derived metrics alone",
           "red_source":"span_metrics connector not found in fixed factory registration; no new OTLP metrics route authorized",
           "duplicates":"Intake-derived metrics plus independent pre-sampling metrics would require one reviewed owner and distinct source",
           "slo_correctness":"Pre-export sampling with trace-only compute_stats cannot establish unbiased full-traffic RED/SLO",
           "additional_endpoint":"None authorized; independent metrics export would need a separate decision."},
      "C":{**common,"route":"Same-host ADOT to Agent OTLP only if separately selected","status":"CONDITIONAL_BLOCKED",
           "receiver":"Agent OTLP HTTP localhost:4318 or gRPC localhost:4317 only with actual co-location and shared network namespace witness",
           "exporter":"ADOT otlphttp or otlp exists; do not forward direct-intake dd-api-key or compute_stats headers to local Agent; Agent owns downstream auth",
           "sdk_sampling":"No prior sampling for representativeness unless independent approved full-traffic stats owner exists",
           "red_source":"Agent path must prove actual APM stats and metadata/trace categories; direct-intake compute_stats semantics do not transfer by assumption",
           "duplicates":"Disable direct DD-F02 for the same trace signal; native APM and generic Agent OTLP signals remain controlled",
           "slo_correctness":"OPEN exact Agent components, trace stats and received spans",
           "additional_endpoint":"Candidate Agent trace intake plus currently approved Agent metrics only; no cross-host traffic or OTLP metrics route"},
    }


def flow_tables(contract,docs,history):
    sites=contract["sites"]
    expected={(s,f) for s in sites for f in ("metrics","apm_native","operator_api","agent_api","instrumentation_telemetry","otlp_http")}
    ensure(len(contract["endpoints"])==42 and {(r["site"],r["feature"]) for r in contract["endpoints"]}==expected,"ENDPOINT_SCOPE")
    ensure(all(v in docs["sites"] for v in sites.values()),"SITE_TABLE_NOT_PRESENT")
    ensure(len(contract["flows"])==15 and {x["flow_id"] for x in contract["flows"]}=={f"DD-F{i:02d}" for i in range(1,16)},"FLOW_SCOPE")
    hist={(r["input"]["site"],r["input"]["feature"]):r.get("dns",{}) for r in history["endpoint_rows"]}
    output=[]
    config={
      "metrics":("CONDITIONAL_MINIMUM_ONLY","UNKNOWN effective Agent series/payload paths","NODE_AGENT_API_KEY_REF_PENDING"),
      "apm_native":("DISABLED_PRIMARY_CONDITIONAL_ALTERNATIVE","UNKNOWN trace-agent request path","NODE_AGENT_API_KEY_REF_PENDING"),
      "operator_api":("CONDITIONAL_MONITOR_SLO_ONLY","UNKNOWN exact controller verbs/paths; separately authorize Monitor/SLO resource methods","OPERATOR_API_AND_APP_KEY_REFS_PENDING"),
      "agent_api":("CONDITIONAL_NONCRITICAL_VALIDATION","UNKNOWN exact optional key validation path","NODE_AGENT_API_KEY_REF_PENDING"),
      "instrumentation_telemetry":("DISABLED_UNLESS_APPROVED","UNKNOWN telemetry transport route","UNAPPROVED_NO_REFERENCE"),
      "otlp_http":("CONDITIONAL_TRACE_ONLY","/v1/traces","ADOT_DD_API_KEY_REF_PENDING"),
    }
    for r in contract["endpoints"]:
        feat,site,host=r["feature"],r["site"],r["host"]
        ensure(r["site_parameter"]==sites[site] and host.endswith("."+sites[site]) and "*" not in host
             and r["transport"]=="HTTPS" and r["port"]==443,"ENDPOINT_CONTRACT")
        applicability,path,auth=config[feat]
        site_source={"site_parameter":sites[site],"official_site_listing":DOCS["sites"],"host_literal_in_official_page":host in docs["network"]}
        if feat=="metrics":
            coverage="FIXED_AGENT_PREFIX_RULE_PLUS_OFFICIAL_VERSIONED_METRICS_PATTERN"
            agent=[source(DD01,"BuildURLWithPrefix"),source(DD01,"AddAgentVersionToDomain"),
                   source(DD01,"GetMainEndpoint")]
        elif feat=="otlp_http":
            coverage="OFFICIAL_PROTOCOL_AND_HEADER_ONLY_SITE_HOST_UNVERIFIED"
            agent=None
        elif feat=="apm_native":
            coverage="OFFICIAL_TRACE_AGENT_PREFIX_SITE_PROJECTION"
            agent=source(DD01,"BuildURLWithPrefix")
        else:
            coverage="PART19_HOST_CANDIDATE_SITE_FAMILY_ONLY_EXACT_PATH_OPEN"
            agent=None
        prior=hist.get((site,feat),{})
        output.append({**r,"candidate_state":applicability,"url_path":path,"auth_reference":auth,
          "evidence_coverage":coverage,"site_source":site_source,"source_detail":agent,
          "public_network_doc":DOCS["otlp"] if feat=="otlp_http" else DOCS["network"],
          "dns":{"canonical_name":host,"query_name_candidate":host+".","terminal_dot_representation":
                 "Agent BuildURLWithPrefix uses configured feature flag for well-known sites; this is a DNS encoding candidate, not a wire observation.",
                 "cname":"UNKNOWN. Inspect complete chain; approve DNS-only aliases individually; no automatic TLS trust.",
                 "resolved_ip":"UNKNOWN_MANAGED_VPC",
                 "prior_external_lookup":{"state":"HISTORICAL_ONLY","exit_code":prior.get("exit_code"),"at":prior.get("at"),
                                           "cname":"NOT_ESTABLISHED"}},
          "tls":{"sni_candidate":host,"actual_sni":"NOT_TESTED_TRAILING_DOT_MUST_BE_OBSERVED_SEPARATELY",
                 "certificate_validation":"Require CA/hostname validation for exact approved origin; no skip verify or CNAME-to-SNI substitution."},
          "network":{"sg_np":"Default deny. Bind source SA/pod/ENI and SG/NP to exact selected role/flow; hostNetwork gaps must be proven.",
                     "nfw":"Require same AZ ID, symmetric routing, exact TCP443 SNI AND current resolved IP, TTL expiry drop; no wildcard, NAT bypass or shared broad pool."},
          "activation":"BLOCKED"})
    flows=[]
    for r in contract["flows"]:
        n=r["flow_id"]
        state="CONDITIONAL"
        if n in ("DD-F04","DD-F06","DD-F09"):state="DISABLED_PRIMARY"
        if n in ("DD-F10","DD-F11","DD-F12","DD-F13","DD-F14"):state="INDEPENDENT_BOUNDARY_OPEN"
        flows.append({**r,"state":state,"activation":"BLOCKED",
                      "verification":"NOT_TESTED_EFFECTIVE_RENDER_ROUTE_AND_RETURN_PATH",
                      "dns_tls_auth_sg_np":"Use exact source role/SA/identity, approved scoped DNS and auth ref, CA/SNI/transport validation as applicable. Preserve same-AZ NFW for external Datadog flows."})
    return output,flows


def main():
    raw=Path("final-contracts.json").read_bytes()
    ensure(sha(raw)==CONTRACT,"FINAL_CONTRACT_IDENTITY")
    contract=json.loads(raw)["catalogs"]["current_plan_v130"]["technical_candidate_catalogs"]["19"]
    archives,raw_archives,schema=inventory()
    docs={name:doc_value(name) for name in DOCS}
    matrix,cr=config(contract,schema)
    values=chart_values(raw_archives["datadog-operator"][1])
    routes=route_matrix(docs)
    ep,flow=flow_tables(contract,docs,json.loads(Path("historical-render.json").read_bytes()))
    src=Path("originals/datadog-operator-2.32.0.release.tgz.at").read_text().strip()
    observed=datetime.fromisoformat(src)
    for row in archives.values():
        pub=datetime.fromisoformat(row["release_published_at"])
        row["release_age_timestamp_only"]= "PASS_14_DAY_PUBLISHER_TIMESTAMP_ONLY" if observed>=pub+timedelta(days=14) else "HOLD_TOO_NEW"
    emit("CHART_CRD_STATIC_INVENTORY.json",archives)
    emit("FEATURE_CONFIGURATION_MATRIX.json",matrix)
    emit("TRACE_SAMPLING_DECISION_MATRIX.json",routes)
    emit("ENDPOINT_42_ROWS.json",ep)
    emit("FLOW_15_ROWS.json",flow)
    Path("candidate-datadogagent.yaml").write_text("# STATIC ONLY. BLOCKED. Site, credentials and runtime witnesses intentionally unset.\n"+
                                                    yaml.safe_dump(cr,sort_keys=False))
    Path("candidate-operator-values.yaml").write_text("# STATIC ONLY. BLOCKED. Use bundled CRD ownership if independently approved.\n"+
                                                        yaml.safe_dump(values,sort_keys=False))
    cfg={"receivers":{"otlp":{"protocols":{"http":{"endpoint":"${env:B09_PRIVATE_RECEIVER_ENDPOINT}",
                                       "tls":{"cert_file":"${env:B09_TLS_CERT_FILE}","key_file":"${env:B09_TLS_KEY_FILE}"}}}}},
         "exporters":{"otlphttp/datadog":{"traces_endpoint":"${env:B09_REVIEWED_HTTPS_TRACE_URL}",
                   "headers":{"dd-api-key":"${env:B09_DD_API_KEY}","compute_stats":"true"}}},
         "service":{"pipelines":{"traces":{"receivers":["otlp"],"exporters":["otlphttp/datadog"]}}}}
    Path("candidate-adot.yaml").write_text("# STATIC ONLY. BLOCKED. No active endpoints or credential values. SDK AlwaysOn intent; redirect/TLS policy OPEN.\n"+
                                           yaml.safe_dump(cfg,sort_keys=False))
    print("static chart, CRD, features, endpoints, flows",len(archives),len(archives["datadog-crds"]["crd_documents"]),len(matrix),len(ep),len(flow))
if __name__=="__main__":main()
