"""Read pinned published Helm archives and literal CRD schemas without Helm."""
from hashlib import sha256
from io import BytesIO
from pathlib import Path, PurePosixPath
import gzip
import json
import re
import tarfile
import yaml

RAW=Path("originals")
CHARTS={"datadog-operator":("2.32.0",109930,"9478528d69cb3ecc9c1fdca60bea61c0b6ef327e8bf7e457a98cb73b758184b7"),
        "datadog-crds":("2.25.0",90005,"8cd9de902d73df11173c6f8e98b2631fc467eaa20c51ac0ab9d2ee605db5c66b")}
RAW_RELEASE_DIGESTS={"datadog-operator":"5dab300f7f08e3933684b181b3f92f70d32c1c8bd1ff989577b02bf19ed3f52a",
                     "datadog-crds":"98f8f9a953b6699427ecaa130e88b83bfe816be3d67a6638df96aa7341928301"}

def sha(b): return sha256(b).hexdigest()

def ensure(ok,msg):
    if not ok: raise ValueError(msg)

def emit(path,data): Path(path).write_text(json.dumps(data,sort_keys=True,indent=2)+"\n")

def files(blob,root):
    with gzip.GzipFile(fileobj=BytesIO(blob)) as stream:
        content=stream.read(12_000_001)
    ensure(len(content)<=12_000_000,"ARCHIVE_LIMIT")
    included,seen={},set()
    with tarfile.open(fileobj=BytesIO(content),mode="r:") as t:
        for m in t:
            path=PurePosixPath(m.name)
            ensure(path.parts and path.parts[0]==root and not path.is_absolute() and ".." not in path.parts
                   and str(path)==m.name and "\\" not in m.name and not any(ord(c)<32 for c in m.name),
                   "ARCHIVE_PATH")
            ensure(m.name not in seen and (m.isfile() or m.isdir()),"ARCHIVE_DUPLICATE_OR_LINK")
            seen.add(m.name)
            if m.isfile(): included[m.name]=t.extractfile(m).read()
    ensure(not any(p.as_posix() in included for f in seen for p in PurePosixPath(f).parents),"ARCHIVE_DIRECTORY_COLLISION")
    return included

def crd_static(payload):
    """Only strip exact whole-line rendering guards/annotations. No rendering."""
    raw=payload.decode()
    out=[]
    started=False
    for line in raw.splitlines():
        if line.startswith("spec:"): started=True
        if "{{" in line:
            if started:
                ensure(line=="{{- end }}","UNEXPECTED_CRD_SPEC_TEMPLATE")
                continue
            if not line.lstrip().startswith("{{"):
                ensure(line.startswith("    ") and "'" in line,"UNKNOWN_TEMPLATE_LOCATION")
                out.append(line.split(":",1)[0]+": static-template-metadata")
        else: out.append(line)
    d=yaml.safe_load("\n".join(out))
    ensure(d["kind"]=="CustomResourceDefinition","NOT_CRD")
    return d

def inventory():
    out={}
    originals={}
    for root,(ver,size,digest) in CHARTS.items():
        p=RAW/f"{root}-{ver}.release.tgz"
        b=p.read_bytes()
        ensure((len(b),sha(b))==(size,digest),"PUBLISHED_CHART_IDENTITY")
        data=files(b,root)
        chart=yaml.safe_load(data[root+"/Chart.yaml"])
        ensure((chart["name"],chart["version"])==(root,ver),"CHART_METADATA")
        meta=Path("retained")/(root+"-release.json")
        raw=meta.read_bytes()
        ensure(sha(raw)==RAW_RELEASE_DIGESTS[root],"EXISTING_RELEASE_SHA")
        detail=json.loads(raw)
        assets=[a for a in detail["assets"] if a["name"]==f"{root}-{ver}.tgz"]
        ensure(len(assets)==1 and (assets[0]["size"],assets[0]["digest"])==(size,"sha256:"+digest),"PUBLISHER_ASSET_IDENTITY")
        legal=[n for n in data if PurePosixPath(n).name.lower().startswith(("license","licence","notice","copying"))]
        v=yaml.safe_load(data[root+"/values.yaml"])
        rows,docs={},{}
        if root=="datadog-crds":
            for n,body in sorted(data.items()):
                if not n.startswith(root+"/templates/datadoghq.com_") or not n.endswith(".yaml"): continue
                d=crd_static(body)
                rows[d["metadata"]["name"]]=dict(path=n,group=d["spec"]["group"],
                  kind=d["spec"]["names"]["kind"],scope=d["spec"]["scope"],
                  versions=[{**{k:ver[k] for k in ("name","served","storage")},
                   "schema_sha256":sha(json.dumps(ver.get("schema"),sort_keys=True).encode())}
                  for ver in d["spec"]["versions"]],source_bytes_sha256=sha(body),
                  conversion=d["spec"].get("conversion"))
                docs[d["metadata"]["name"]]=d
        out[root]=dict(version=ver,appVersion=chart.get("appVersion"),published_path=str(p),published_uri=assets[0]["browser_download_url"],
          size_bytes=size,sha256=digest,source_release_api=detail["url"],release_published_at=detail["published_at"],
          publisher_asset_created_at=assets[0].get("created_at"),publisher_asset_updated_at=assets[0].get("updated_at"),
          release_asset_list=[a["name"] for a in detail["assets"]],
          signature_locator="NO_PROV_ASSET_IN_RETAINED_RELEASE_METADATA; other signature/provenance locators OPEN",
          signature_verified="NOT_TESTED",archive_safety="PASS",dependencies=chart.get("dependencies",[]),
          values_file_sha256=sha(data[root+"/values.yaml"]),
          values_excerpt={k:v[k] for k in ("image","datadogMonitor","datadogSLO","installCRDs","defaultDataPlaneEnabled",
                     "operatorMetricsEnabled","collectOperatorMetrics","crds") if k in v},
          license_notice_paths=legal,license_gate="OPEN_REDISTRIBUTION_NOT_ESTABLISHED",crd_documents=rows)
        originals[root]=(data,v,docs)
    a=out["datadog-operator"]
    ensure(a["appVersion"]=="1.31.2","OPERATOR_APPVERSION")
    ensure(a["dependencies"][0]["version"]=="2.25.0","CHART_PINNED_CRD_DEPENDENCY")
    old=originals["datadog-crds"][0]
    vendor=originals["datadog-operator"][0]
    pairs={p:vendor.get("datadog-operator/charts/"+p)==b for p,b in old.items()
          if p.startswith("datadog-crds/templates/")}
    a["vendored_crd_template_byte_matches"]=pairs
    d=originals["datadog-crds"][2]["datadogagents.datadoghq.com"]
    t=next(v for v in d["spec"]["versions"] if v["name"]=="v2alpha1")
    ensure(t["served"] and t["storage"],"CRD_VERSION")
    return out,originals,t["schema"]["openAPIV3Schema"]
