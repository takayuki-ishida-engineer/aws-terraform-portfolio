"""Synthetic independent-review fixtures for the v2 contract."""

from copy import deepcopy

from contract_v2 import digest


def rebind(envelope, trust):
    """Seal a deliberately changed fixture while preserving the independent trust seam."""
    context = trust.contexts[envelope["subject"]]
    envelope["input_sha256"] = digest(envelope["payload"])
    context["input_sha256"] = envelope["input_sha256"]
    trust.anchors[envelope["subject"]] = digest(context)


def scope_case(h, case):
    if case == "resource-scope-mismatch":
        return ownership_case(h, "wrong-arn-account")
    if case == "cross-environment-approval":
        envelope, trust = h.a("profile-approval")
        approval = trust.approvals["AP-FIXTURE"]
        approval["scope"]["environment"] = "prod"
        trust.approval_verifications["AP-FIXTURE"] = digest(approval)
        return envelope, trust
    envelope, trust = h.a("profile-approval")
    if case == "old-schema":
        envelope["schema_version"] = "rev6-x01-x04-offline-v1"
    else:
        field = "project" if case.endswith("project") else "environment"
        if case.startswith("missing"):
            envelope["scope"].pop(field)
        else:
            envelope["scope"][field] = "other" if field == "project" else "prod"
    return envelope, trust


def state_case(h, case):
    starting = {
        "root-present-resource-absent": "absent-create",
        "migration-drops-source": "engine-migration",
        "legacy-write": "update-denied",
    }.get(case, "present-retain")
    envelope, trust = h.b(starting)
    data = envelope["payload"]
    witness = trust.contexts[envelope["subject"]]["evidence"]
    state = data["observed"]
    allowed = witness["reviewed_inventory"]
    if case in ("legacy-zero-diff", "legacy-write", "api-db-mismatch"):
        state.update(root="api", key="infra/services/dev/ca-central-1/api/terraform.tfstate")
        allowed["root"] = "api"
        if case != "api-db-mismatch":
            address = "module.api_gateway_rest.aws_api_gateway_rest_api.this"
            data["address"] = witness["address"] = address
            data["plan"]["before"] = [address]
            data["plan"]["after"] = [address]
            witness["inventory"] = [address]
            allowed["addresses"] = [address]
    if case == "unknown-root":
        state["root"] = "unlisted"
    if case == "wrong-backend":
        state.update(root="tfstate", backend="remote")
    if case == "coordinated-wrong-key":
        state["key"] = "unreviewed/terraform.tfstate"
    if case == "root-absent-resource-present":
        state.update(root_presence="ABSENT", lineage=None, serial=None)
    if case == "root-present-resource-absent":
        state.update(root_presence="PRESENT", lineage="existing-state-without-db", serial=7)
    if case == "no-reviewed-inventory":
        witness.pop("reviewed_inventory")
    if case == "migration-drops-source":
        data["plan"]["after"].remove(data["address"])
    if case == "s3-exact-template":
        state.update(backend="remote", key="project-a/dev/ca-central-1/database/terraform.tfstate")
    witness["state"] = deepcopy(state)
    rebind(envelope, trust)
    if case == "root-present-resource-absent":
        h.review(envelope, trust, "state:create", data)
    return envelope, trust


def ownership_case(h, case):
    name = {"global-regional-alias": "org-create", "global-explicit": "org-create",
            "missing-service-owner": "service-managed"}.get(case, "create")
    envelope, trust = h.c(name)
    data = envelope["payload"]
    boundary = data["boundary"]
    rows = trust.contexts[envelope["subject"]]["evidence"]["registry"]
    if case in ("cross-feature-duplicate-writer", "shared-feature-single-writer",
                "separate-attributes", "unrelated-registry-conflict"):
        extra = deepcopy(rows[0])
        extra["boundary"]["feature"] = "security-hub-unified"
        if case != "shared-feature-single-writer":
            extra["writers"] = ["second-writer"]
        if case == "separate-attributes":
            extra["boundary"]["attribute"] = "different-settings"
        if case == "unrelated-registry-conflict":
            other = deepcopy(rows[0])
            other["boundary"]["resource"] += "-unrelated"
            extra["boundary"]["resource"] = other["boundary"]["resource"]
            rows.append(other)
        rows.append(extra)
    if case in ("global-explicit", "global-regional-alias"):
        data.update(mode="existing", operation="read")
        rows[0]["mode"] = "existing"
        if case == "global-regional-alias":
            boundary["resource"] = boundary["resource"].replace("organizations::", "organizations:ca-central-1:")
            boundary["resource_region"] = "ca-central-1"
        rows[0]["boundary"] = deepcopy(boundary)
    if case == "missing-service-owner":
        rows[0].pop("service_identity")
    if case == "wrong-arn-account":
        boundary["resource"] = boundary["resource"].replace("000000000000", "000000000001")
        rows[0]["boundary"] = deepcopy(boundary)
    if case in ("wrong-resource-region", "cross-region-reviewed"):
        boundary["resource_region"] = "us-east-1"
        if case == "cross-region-reviewed":
            boundary["resource"] = boundary["resource"].replace("ca-central-1", "us-east-1")
        rows[0]["boundary"] = deepcopy(boundary)
    rebind(envelope, trust)
    return envelope, trust


def key_case(h, case):
    name = {"active-key-dependency": "disable-denied",
            "invented-exception-resource": "lake-exception",
            "strict-new-noncmk": "alb"}.get(case, "scoped-fixture")
    envelope, trust = h.d(name)
    payload = envelope["payload"]
    binding = payload["binding"]
    row = trust.contexts[envelope["subject"]]["evidence"]["key_row"]
    if case == "missing-cmk-key":
        binding["key"] = None
    if case == "wrong-resource-type":
        binding["resource_type"] = "security-lake-managed"
    if case == "wrong-service-owner":
        binding["service_owner"] = "aws-service"
    if case == "wrong-key-scope":
        binding["key"] = binding["key"].replace("ca-central-1", "us-east-1")
    if case == "strict-new-noncmk":
        row.update(lifecycle="NEW", strict=True)
    if case == "active-key-dependency":
        row["active_dependencies"] = ["fixture-live-data"]
    if case == "invented-exception-resource":
        binding["resource_id"] += "-unreviewed"
    row["binding"] = deepcopy(binding)
    rebind(envelope, trust)
    if case == "active-key-dependency":
        h.review(envelope, trust, "key:disable", payload)
    return envelope, trust


def independent_case(h, ident):
    _, group, case = ident.split("-", 2)
    return {"F01": scope_case, "F02": state_case, "F03": ownership_case, "F04": key_case}[group](h, case)
