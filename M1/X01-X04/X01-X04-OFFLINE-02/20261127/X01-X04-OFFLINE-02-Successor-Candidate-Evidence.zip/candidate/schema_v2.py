"""Schemas for the Scratch-only X01–X04 v2 envelope and payloads."""

DIGEST = {"type": "string", "pattern": "^[0-9a-f]{64}$"}
GIT_ID = {"type": "string", "pattern": "^[0-9a-f]{40}$"}
TEXT = {"type": "string", "minLength": 1}
BOOLEAN = {"type": "boolean"}
INTEGER = {"type": "integer", "minimum": 0}
NULL = {"type": "null"}


def enum(*values):
    return {"enum": list(values)}


def sequence(items):
    return {"type": "array", "items": items, "uniqueItems": True}


def record(**properties):
    return {
        "type": "object", "properties": properties,
        "required": sorted(properties), "additionalProperties": False,
    }


SCOPE = record(
    project={"type": "string", "pattern": "^[a-z]([a-z0-9-]{0,8}[a-z0-9])?$",
             "not": {"pattern": "aws|amazon|cognito"}},
    environment=enum("dev", "stg", "prod"),
    partition={"const": "aws"},
    account_id={"type": "string", "pattern": "^[0-9]{12}$"},
    region={"type": "string", "pattern": "^[a-z]{2}-[a-z]+-[0-9]$"},
)
SCOPED = dict(SCOPE["properties"])
RESOURCE = record(**{**SCOPED, "partition": TEXT}, feature=enum(
    "config-recorder", "config-service-linked-recorder", "security-hub-cspm",
    "security-hub-unified", "security-lake", "organizations",
), resource=TEXT, resource_region=TEXT, attribute=TEXT)
STATE = record(scope=SCOPE, root=TEXT, backend=enum("local", "remote"), key=TEXT,
               resource_presence=enum("ABSENT", "PRESENT", "UNKNOWN"), root_presence=enum("ABSENT", "PRESENT", "UNKNOWN"),
               lineage={"oneOf": [TEXT, NULL]}, serial={"oneOf": [INTEGER, NULL]})
PLAN = record(action=enum("retain", "create", "update", "delete", "replace", "migrate"),
              before=sequence(TEXT), after=sequence(TEXT),
              migration_target={"oneOf": [TEXT, NULL]})
KEY_BINDING = record(**SCOPED, root=TEXT, consumer=TEXT, key={"oneOf": [TEXT, NULL]},
                     resource_id=TEXT, resource_type=TEXT, service_owner=TEXT,
                     service=TEXT, operation=enum("read", "grant", "disable", "delete"),
                     encryption_context={"type": "object", "additionalProperties": TEXT})
PAYLOADS = {
    "profile": {"type": "object"},  # checked against the pinned original profile-v2
    "state": record(
        observed=STATE, selected=BOOLEAN, address=TEXT, plan=PLAN,
        legacy_inventory_sha256=DIGEST, moved_blocks_sha256=DIGEST,
        engine_before=enum("rds", "aurora"), engine_after=enum("rds", "aurora"),
        backup_before=enum("continuous", "native"), backup_after=enum("continuous", "native"),
        pitr_writers=sequence(enum("native-pitr", "aws-backup-continuous")),
        migration_evidence_sha256={"oneOf": [DIGEST, NULL]},
        approval_ref={"oneOf": [TEXT, NULL]},
    ),
    "ownership": record(
        boundary=RESOURCE, mode=enum("create", "existing", "disabled", "service-managed"),
        operation=enum("create", "read", "retain", "update", "delete", "import"),
        writers=sequence(TEXT),
    ),
    "key": record(
        binding=KEY_BINDING, encryption_before=enum("CMK", "SSE-S3", "AES256", "SERVICE-MANAGED"),
        encryption_after=enum("CMK", "SSE-S3", "AES256", "SERVICE-MANAGED"),
        historical_dependencies=sequence(TEXT), retained_dependencies=sequence(TEXT),
        exception={"oneOf": [TEXT, NULL]},
        retention_days={"oneOf": [{"type": "integer", "minimum": 1}, NULL]},
        approval_ref={"oneOf": [TEXT, NULL]},
    ),
    "boundary": record(root=TEXT, field=TEXT, value={"type": "null"}),
}
SCHEMA_VERSION = "rev6-x01-x04-offline-v2"
ENVELOPE = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    **record(schema_version=enum(SCHEMA_VERSION), kind=enum(*PAYLOADS),
             subject=TEXT, scope=SCOPE, input_sha256=DIGEST, payload={"type": "object"}),
}
