"""Run the predeclared cases without loading credentials or executing tools."""

from collections import Counter
from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import sys

from jsonschema import Draft202012Validator

from contract_v1 import (
    Contract, DECISION, OfflineFixtureTrust, POLICY_DIGEST, PRODUCERS, TRUST_ORIGIN, digest,
)
import schema_v1 as schema

ROOT = Path(__file__).resolve().parent.parent
INPUT = ROOT / "input"
ORIGINAL = INPUT / "original"
SPEC = importlib.util.spec_from_file_location(
    "legacy", ORIGINAL / "rev6_semantic_validator_final.py",
)
LEGACY = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(LEGACY)
SCOPE = {"partition": "aws", "account_id": "000000000000", "region": "ca-central-1"}
COMMIT, TREE = "a" * 40, "b" * 40
REF = "AP-FIXTURE"
ADDRESS = "aws_db_instance.fixture"


def read(path):
    return json.loads(path.read_bytes())


class Harness:
    def __init__(self):
        self.contract = Contract(ORIGINAL / "Revision6_Final_Contracts.json", LEGACY)
        self.profile_by_id = {p["profile_id"]: p for p in self.contract.catalog["profiles"]}
        self.r3 = read(ROOT / "r3-fixtures.json")["fixtures"]
        self.r3_by_id = {case["id"]: case for case in self.r3}

    def fixture(self, kind, payload, evidence, *, subject=None, scope=None):
        # Build evidence independently of the serialized request passed to Contract.check.
        scope = deepcopy(scope or SCOPE)
        subject = subject or f"{kind}:fixture"
        envelope = {"schema_version": schema.SCHEMA_VERSION, "kind": kind, "subject": subject,
                    "scope": scope, "payload": deepcopy(payload), "input_sha256": digest(payload)}
        context = {
            "origin": TRUST_ORIGIN, "producer_verified": True, "producer": PRODUCERS[kind],
            "subject": subject, "scope": deepcopy(scope), "input_sha256": digest(payload),
            "retrieved_at": "2026-11-27T12:00:00Z", "fresh_until": "2026-11-27T12:06:00Z",
            "source_commit": COMMIT, "source_tree": TREE, "evidence": deepcopy(evidence),
        }
        trust = OfflineFixtureTrust("2026-11-27T12:05:00Z", {subject: context},
                                    {subject: digest(context)}, {}, {}, {})
        return envelope, trust

    def review(self, envelope, trust, operation, effective, change=None):
        op_id = f"{envelope['subject']}:{operation}"
        approval = {
            "decision_id": DECISION, "authority": "OD-DELEGATION-01",
            "policy_sha256": POLICY_DIGEST, "approval_id": REF, "operation_id": op_id,
            "operation": operation, "subject": envelope["subject"],
            "scope": deepcopy(envelope["scope"]), "input_sha256": envelope["input_sha256"],
            "effective_input_sha256": digest(effective), "source_commit": COMMIT, "source_tree": TREE,
            "issued_at": "2026-11-27T12:00:00Z", "expires_at": "2026-11-27T12:10:00Z",
            "status": "ACTIVE", "evidence_ref": "synthetic-review-object",
        }
        approval.update(change or {})
        trust.approvals[REF] = approval
        trust.approval_verifications[REF] = digest(approval)
        trust.replay[REF] = {"operation_id": op_id, "revoked": False, "consumed": False}

    def candidate_profile(self, profile, evidence=None):
        scope = {k: profile["scope"][k] for k in SCOPE}
        return self.fixture("profile", profile, evidence or {}, scope=scope,
                            subject=profile["profile_id"])

    def a(self, name):
        profile = deepcopy(self.profile_by_id["minimal"])
        flags = profile["flags"]
        is_approval_case = name in {
            "profile-approval", "reference-only", "unverified-approval", "wrong-scope",
            "wrong-subject", "wrong-operation", "wrong-input", "wrong-effective",
            "wrong-tree", "wrong-commit", "wrong-decision", "wrong-policy", "expired",
            "future", "ttl-too-long", "revoked", "consumed", "replay-collision", "missing-replay-state",
        }
        if is_approval_case:
            flags["ebs_csi_persistence"] = True
            profile["owner_approvals"] = {"OD-R07-EBS": REF}
        if name == "missing-dependency":
            profile["roots_selected"] = ["platform"]
            profile["root_modes"] = {"platform": "create"}
            profile["identity_sources"] = {}
            profile["backend_modes"] = {}
        if name == "strict-dependency":
            profile["security_profile"] = "strict"
        if name in ("unknown-region", "nonregion-catalog-key"):
            profile["scope"]["region"] = "eu-west-1" if name == "unknown-region" else "owner"
        if name == "paused-effective":
            profile["flags"]["k8s.network_policy_mode"] = "np2b"
            profile["owner_approvals"] = {"NP-2B": REF}
        if name == "paused-desired-only":
            profile["desired_flags"] = {"k8s.network_policy_mode": "np2b"}
        if name == "desired-substitution":
            profile = deepcopy(self.profile_by_id["R5"])
            profile["flags"]["observability.investigations"] = False
            profile["desired_flags"] = {"observability.investigations": True}
        if name == "canada-forced":
            profile = deepcopy(self.profile_by_id["R1"])
            profile["flags"]["observability.investigations"] = True
        envelope, trust = self.candidate_profile(profile)
        if is_approval_case and name != "reference-only":
            changes = {
                "wrong-scope": {"scope": {**envelope["scope"], "account_id": "000000000001"}},
                "wrong-subject": {"subject": "other-profile"},
                "wrong-operation": {"operation": "profile:np2b"},
                "wrong-input": {"input_sha256": "0" * 64},
                "wrong-effective": {"effective_input_sha256": "0" * 64},
                "wrong-tree": {"source_tree": "0" * 40},
                "wrong-commit": {"source_commit": "0" * 40},
                "wrong-decision": {"decision_id": "UNRELATED"},
                "wrong-policy": {"policy_sha256": "0" * 64},
                "expired": {"expires_at": "2026-11-27T12:05:00Z"},
                "future": {"issued_at": "2026-11-27T12:06:00Z"},
                "ttl-too-long": {"expires_at": "2026-11-27T12:16:00Z"},
            }
            self.review(envelope, trust, "profile:ebs-persistence", flags, changes.get(name))
        subject = envelope["subject"]
        context = trust.contexts[subject]
        if name == "unverified-producer":
            context["producer_verified"] = False
            trust.anchors[subject] = digest(context)
        if name == "missing-producer-evidence":
            trust.contexts.clear()
        if name == "wrong-anchor":
            trust.anchors[subject] = "0" * 64
        if name == "missing-anchor":
            trust.anchors.clear()
        if name == "unverified-approval":
            trust.approval_verifications.clear()
        if name == "stale-context":
            trust.now = context["fresh_until"]
        if name in ("revoked", "consumed"):
            trust.replay[REF][name] = True
        if name == "replay-collision":
            trust.replay[REF]["operation_id"] = "another-operation"
        if name == "missing-replay-state":
            trust.replay.clear()
        return envelope, trust

    def b(self, name):
        presence = "ABSENT" if name.startswith("absent-") else "PRESENT"
        if name == "unknown":
            presence = "UNKNOWN"
        actual = {"root": "api", "backend": "local", "key": "fixtures/legacy-api.tfstate",
                  "presence": presence, "lineage": "synthetic-lineage" if presence == "PRESENT" else None,
                  "serial": 7 if presence == "PRESENT" else None}
        actions = {"absent-create": "create", "exact-delete": "delete", "delete-denied": "delete",
                   "replace-denied": "replace", "engine-replace": "replace", "engine-migration": "migrate",
                   "update-denied": "update", "absent-replace": "replace"}
        action = actions.get(name, "retain")
        inventory = [ADDRESS] if presence == "PRESENT" else []
        after = [ADDRESS] if action == "create" else [] if action == "delete" else inventory
        payload = {
            "observed": deepcopy(actual), "selected": name not in ("absent-unselected", "unselected-present"),
            "address": ADDRESS, "plan": {"action": action, "before": list(inventory), "after": list(after),
                                         "migration_target": None},
            "legacy_inventory_sha256": self.contract.legacy_inventory,
            "moved_blocks_sha256": self.contract.moved, "engine_before": "rds", "engine_after": "rds",
            "backup_before": "continuous", "backup_after": "continuous",
            "pitr_writers": ["aws-backup-continuous"], "migration_evidence_sha256": None,
            "approval_ref": REF,
        }
        evidence = {"state": actual, "address": ADDRESS, "inventory": inventory,
                    "backup_mode": "continuous", "engine": "rds"}
        for case, field, value in (
            ("state-key-change", "key", "fixtures/other.tfstate"),
            ("state-lineage-change", "lineage", "other-lineage"), ("state-serial-change", "serial", 8),
        ):
            if name == case:
                payload["observed"][field] = value
        if name in ("legacy-root-change", "moved-change"):
            field = "moved_blocks_sha256" if name == "moved-change" else "legacy_inventory_sha256"
            payload[field] = "0" * 64
        if name in ("engine-replace", "engine-migration"):
            payload["engine_after"] = "aurora"
        if name == "engine-migration":
            payload["migration_evidence_sha256"] = evidence["migration_evidence_sha256"] = "c" * 64
            target = "aws_rds_cluster.fixture"
            payload["plan"]["migration_target"] = evidence["migration_target"] = target
            payload["plan"]["after"].append(target)
        if name.startswith("backup-migration"):
            payload["backup_after"] = "native"
            payload["pitr_writers"] = ["native-pitr"]
        if name == "dual-writer":
            payload["pitr_writers"] += ["native-pitr"]
        if name == "no-writer":
            payload["pitr_writers"].clear()
        if name == "inventory-change":
            payload["plan"]["after"].append("aws_db_instance.unreviewed")
        envelope, trust = self.fixture("state", payload, evidence)
        approvals = {"absent-create": "state:create", "exact-delete": "state:delete",
                     "engine-migration": "state:migrate", "backup-migration-fixture": "state:backup-mode-migration"}
        if name in approvals:
            self.review(envelope, trust, approvals[name], payload)
        return envelope, trust

    def c(self, name):
        feature = {"org-create": "organizations", "no-org-trail-witness": "security-lake",
                   "recorder-separate": "config-recorder"}.get(name, "security-hub-cspm")
        if name in ("service-managed", "service-import", "service-wrong-writer"):
            feature = "config-service-linked-recorder"
        boundary = {**SCOPE, "feature": feature, "resource": "fixture-resource", "attribute": "settings"}
        mode, operation = {
            "existing": ("existing", "read"), "existing-update": ("existing", "update"),
            "disabled-retain": ("disabled", "retain"), "disabled-delete": ("disabled", "delete"),
            "service-managed": ("service-managed", "read"), "service-import": ("service-managed", "import"),
            "service-wrong-writer": ("service-managed", "read"),
        }.get(name, ("create", "create"))
        writers = [] if mode == "disabled" else ["fixture-writer"]
        row = {"boundary": deepcopy(boundary), "mode": mode, "writers": list(writers),
               "service_created": mode == "service-managed", "service_writer": "fixture-writer",
               "requires_org_trail": name == "no-org-trail-witness"}
        mutations = {
            "wrong-scope": ("account_id", "000000000001"), "wrong-region": ("region", "us-east-1"),
            "wrong-partition": ("partition", "aws-cn"), "wrong-resource": ("resource", "other-resource"),
            "wrong-attribute": ("attribute", "other-settings"),
            "cross-domain": ("feature", "security-hub-unified"),
            "recorder-separate": ("feature", "config-service-linked-recorder"),
        }
        if name in mutations:
            field, value = mutations[name]
            boundary[field] = value
        if name == "multi-writer":
            writers.append("second-writer")
        if name == "service-wrong-writer":
            row["service_writer"] = "independent-service-writer"
        registry = [row, deepcopy(row)] if name == "duplicate-row" else [] if name == "unknown-row" else [row]
        return self.fixture("ownership", {"boundary": boundary, "mode": mode, "operation": operation,
                                          "writers": writers}, {"registry": registry})

    def d(self, name):
        service, root, key, algorithm, fixed, exception = (
            "rds.amazonaws.com", "database", "fixture-key", "CMK", None, None,
        )
        if name in ("tfstate", "legacy-ecr", "alb", "legacy-downgrade"):
            root, algorithm, fixed = {
                "tfstate": ("tfstate", "SSE-S3", "tfstate"),
                "legacy-ecr": ("registry", "AES256", "legacy-ecr"),
                "legacy-downgrade": ("registry", "AES256", "legacy-ecr"),
                "alb": ("network", "SSE-S3", "alb-delivery"),
            }[name]
            service, key = ("ecr.amazonaws.com" if root == "registry" else "s3.amazonaws.com"), None
        if name.startswith("lake-exception"):
            service, root, key, algorithm, exception = (
                "securitylake.amazonaws.com", "security-baseline", None, "SERVICE-MANAGED", "D-04-EX01",
            )
        operation = {"disable-denied": "disable", "delete-denied": "delete",
                     "key-still-referenced": "disable"}.get(name, "grant" if key else "read")
        history = ["fixture-recovery-point"] if name in ("drop-historical", "key-still-referenced") else []
        consumer = ('module.repositories.aws_ecr_repository.this["istio-pilot"]'
                    if fixed == "legacy-ecr" else "fixture-consumer")
        binding = {**SCOPE, "root": root, "consumer": consumer, "key": key,
                   "service": service, "operation": operation, "encryption_context": {"purpose": "fixture"}}
        row = {"binding": deepcopy(binding), "encryption": algorithm, "retention_days": 30,
               "historical_dependencies": list(history), "active_dependencies": [],
               "fixed_class": fixed, "exception": exception}
        payload = {"binding": binding, "encryption_before": algorithm, "encryption_after": algorithm,
                   "historical_dependencies": history, "retained_dependencies": list(history),
                   "exception": exception, "retention_days": 30, "approval_ref": REF}
        bad_bindings = {
            "missing-consumer": ("consumer", " "), "cross-scope": ("account_id", "000000000001"),
            "wrong-service": ("service", "kms.amazonaws.com"), "wrong-operation": ("operation", "read"),
            "wrong-key": ("key", "other-fixture-key"), "wrong-context": ("encryption_context", {"purpose": "other"}),
            "lake-exception-cross-scope": ("region", "us-east-1"),
        }
        if name in bad_bindings:
            field, value = bad_bindings[name]
            binding[field] = value
        if name in ("encryption-downgrade", "legacy-downgrade"):
            payload["encryption_after"] = "SSE-S3"
        if name == "no-auto-reencrypt":
            payload["encryption_after"] = "AES256"
        if name == "unknown-retention":
            payload["retention_days"] = None
        if name == "drop-historical":
            payload["retained_dependencies"].clear()
        if name == "arbitrary-exception":
            payload["exception"] = "EXCEPTION-UNAPPROVED"
        return self.fixture("key", payload, {} if name == "open-without-witness" else {"key_row": row})

    def g(self, name):
        envelope, trust = self.candidate_profile(self.profile_by_id["minimal"])
        if name == "wrong-digest":
            envelope["input_sha256"] = "0" * 64
        if name == "unknown-schema":
            envelope["schema_version"] = "unknown-v2"
        if name == "missing-trust-evidence":
            trust = None
        if name == "extra-self-asserted-trust":
            envelope["producer_verified"] = True
        if name == "invalid-typed-value":
            envelope["payload"]["flags"]["security.macie"] = "false"
            envelope["input_sha256"] = digest(envelope["payload"])
            context = trust.contexts[envelope["subject"]]
            context["input_sha256"] = envelope["input_sha256"]
            trust.anchors[envelope["subject"]] = digest(context)
        return envelope, trust

    def run_case(self, ident):
        group, name = ident.split("-", 1)
        envelope, trust = getattr(self, group.lower())(name)
        raw = json.dumps(envelope)
        if name == "duplicate-json-key":
            raw = '{"kind":"profile",' + raw[1:]
        return self.contract.check(raw, trust)


def matching_results(rows, expected):
    by_id = {r["id"]: r for r in rows}
    return [
        {"id": row["id"], "expected": row["outcome"], "actual": by_id[row["id"]]["observed"],
         "expected_rules": row["all_rules"], "expected_rules_any": row["any_rules"],
         "actual_rules": [rule.split(":", 1)[0] for key in ("reject", "blocked")
                          for rule in by_id[row["id"]][key]],
         "pass": (by_id[row["id"]]["pass"] and row["outcome"] == by_id[row["id"]]["observed"]
                  and row["all_rules"] == by_id[row["id"]]["expected_rules"]
                  and row["any_rules"] == by_id[row["id"]]["expected_rules_any"])}
        for row in expected
    ]


def main(path):
    expected = read(ROOT / "expected-result-manifest.json")
    harness = Harness()
    original = harness.contract.original
    results = {}
    results["ttl"] = matching_results(
        LEGACY.run(original, read(ORIGINAL / "Revision6_Final_TTL_Fixtures.json")), expected["ttl"],
    )
    results["unaffected_r3"] = matching_results(
        LEGACY.run(original, {"fixtures": [harness.r3_by_id[r["id"]] for r in expected["unaffected_r3"]]}),
        expected["unaffected_r3"],
    )
    tests = []
    for row in expected["new_tests"]:
        actual = harness.run_case(row["id"])
        tests.append({
            **row, "actual": actual["outcome"], "actual_reasons": actual["reasons"],
            "pass": (actual["outcome"] == row["outcome"] and row["reason"] in actual["reasons"]
                     and actual["execution_authorized"] is False),
        })
    results["new_tests"] = tests
    profiles = []
    for ident, status in expected["profiles"].items():
        profile = harness.profile_by_id[ident]
        raw, trust = harness.candidate_profile(profile)
        result = harness.contract.check(json.dumps(raw), trust)
        details = result["details"]
        inv = "observability.investigations"
        actual = {
            "outcome": result["outcome"],
            "desired_investigations": details.get("desired_flags", {}).get(inv),
            "effective_investigations": details.get("effective_flags", {}).get(inv),
        }
        legacy = LEGACY.run(original, {"fixtures": [{
            "id": ident, "kind": "profile", "input": profile, "expect": status["outcome"],
        }]})[0]
        profiles.append({
            "id": ident, "expected": status, "actual": actual, "original_outcome": legacy["observed"],
            "actual_reasons": result["reasons"],
            "pass": (actual == status and legacy["pass"]
                     and details.get("effective_flags", {}).get("database.backup_mode") == "continuous"
                     and result["execution_authorized"] is False),
        })
    results["profiles"] = profiles
    boundaries = []
    for row in expected["boundaries"]:
        payload = {"root": row["root"], "field": row["field"], "value": None}
        raw, trust = harness.fixture("boundary", payload, {})
        result = harness.contract.check(json.dumps(raw), trust)
        actual = {"root": row["root"], "field": row["field"], "outcome": result["outcome"],
                  "execution_authorized": result["execution_authorized"], **result["details"]}
        boundaries.append({"id": f"{row['root']}.{row['field']}", "expected": row, "actual": actual,
                           "actual_reasons": result["reasons"], "pass": actual == row})
    results["boundaries"] = boundaries
    for candidate_schema in [schema.ENVELOPE, *schema.PAYLOADS.values()]:
        Draft202012Validator.check_schema(candidate_schema)
    summary = {
        group: {"tested": len(items), "passed": sum(r["pass"] for r in items),
                "outcomes": dict(Counter(r["actual"] if isinstance(r["actual"], str)
                                         else r["actual"]["outcome"] for r in items))}
        for group, items in results.items()
    }
    output = {"original_schemas_checked": len(LEGACY.meta_check(original)),
              "candidate_schemas_checked": 1 + len(schema.PAYLOADS),
              "summary": summary, "results": results}
    Path(path).write_text(json.dumps(output, indent=2) + "\n")
    failed = [(group, r["id"]) for group, items in results.items() for r in items if not r["pass"]]
    print(json.dumps({"summary": summary, "failed": failed}))
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
