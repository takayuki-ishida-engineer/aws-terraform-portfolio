"""Revision 6 shared-contract candidate. Offline fixtures and pure comparisons only."""

from copy import deepcopy
from dataclasses import dataclass
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path

from jsonschema import Draft202012Validator

import schema_v1 as schema


CONTRACTS_DIGEST = "29a396daf7cadb9eee1f089b7ac427fcb7b7c9100f6e170ac97a3bcbd633a783"
POLICY_DIGEST = "ff7a86e31430e7c4eac4f330ed5bbec5d806babb2327f320e4577bba0f40d28f"
DECISION = "OD-X01X04-OFFLINE-01"
TRUST_ORIGIN = "NON_PRODUCTION_OFFLINE_FIXTURE"
PRODUCERS = {
    "profile": "FIXTURE_PROFILE",
    "state": "FIXTURE_STATE",
    "ownership": "FIXTURE_OWNERSHIP",
    "key": "FIXTURE_KEY_INVENTORY",
    "boundary": "FIXTURE_TYPED_BOUNDARY",
}
APPROVAL_OPERATIONS = {
    "D-10": "profile:exposure-findings", "D-13": "profile:compliance-vault",
    "NP-2B": "profile:np2b", "OD-R07-EBS": "profile:ebs-persistence",
}


def digest(value):
    canonical = json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False,
    )
    return sha256(canonical.encode()).hexdigest()


def unique_json(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON key")
        result[key] = value
    return result


def invalid_constant(value):
    raise ValueError("invalid JSON numeric constant")


def parse(raw):
    return json.loads(raw, object_pairs_hook=unique_json, parse_constant=invalid_constant)


def time(value):
    return datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)


class Violation(Exception):
    def __init__(self, code, outcome="REJECT", details=None):
        self.code = code
        self.outcome = outcome
        self.details = details or {}
        super().__init__(code)


def require(condition, code, outcome="REJECT"):
    if not condition:
        raise Violation(code, outcome)


@dataclass
class OfflineFixtureTrust:
    """Fixture inputs are supplied separately by the harness, outside the envelope.

    The maps and clock are test doubles. This interface cannot authorize a write.
    """

    now: str
    contexts: dict
    anchors: dict
    approvals: dict
    approval_verifications: dict
    replay: dict
    ttl_limit_seconds: int = 900


class Contract:
    def __init__(self, path, legacy):
        raw = Path(path).read_bytes()
        require(sha256(raw).hexdigest() == CONTRACTS_DIGEST, "CONTRACT_DIGEST")
        self.original = parse(raw)
        self.catalog = self.original["catalogs"]
        self.legacy = legacy
        self.fields = {
            (row["root"], row["field"]): row
            for row in self.catalog["current_plan_v130"]["fields"]
        }
        self.legacy_inventory = digest({
            k: self.catalog["legacy_addresses"][k]
            for k in ("backends", "catalog", "per_root_blocks", "registry_legacy_keys")
        })
        self.moved = digest(self.catalog["legacy_addresses"]["historical_moved_blocks"])

    def check(self, raw, provider):
        try:
            try:
                envelope = parse(raw)
            except (ValueError, UnicodeError, RecursionError):
                raise Violation("JSON_INPUT") from None
            require(isinstance(envelope, dict), "INPUT_SHAPE")
            require(envelope.get("schema_version") == schema.SCHEMA_VERSION, "SCHEMA_VERSION")
            require(Draft202012Validator(schema.ENVELOPE).is_valid(envelope), "INPUT_SHAPE")
            kind, payload = envelope["kind"], envelope["payload"]
            require(Draft202012Validator(schema.PAYLOADS[kind]).is_valid(payload), "INPUT_SHAPE")
            require(digest(payload) == envelope["input_sha256"], "INPUT_DIGEST")
            require(envelope["scope"]["region"] in {"ca-central-1", "us-east-1", "us-east-2"},
                    "SCP-S2")
            context = self.trusted_context(envelope, provider)
            result = getattr(self, kind)(envelope, payload, provider, context["evidence"])
            return {"outcome": "ACCEPT", "reasons": ["OFFLINE_ONLY"], "details": result,
                    "execution_authorized": False}
        except Violation as exc:
            return {"outcome": exc.outcome, "reasons": [exc.code], "details": exc.details,
                    "execution_authorized": False}
        except (ValueError, KeyError, TypeError, AttributeError, RecursionError):
            return {"outcome": "REJECT", "reasons": ["MALFORMED_FIXTURE_EVIDENCE"],
                    "details": {}, "execution_authorized": False}

    def trusted_context(self, envelope, trust):
        require(type(trust) is OfflineFixtureTrust, "TRUST_MISSING")
        context = trust.contexts.get(envelope["subject"])
        require(isinstance(context, dict), "TRUST_MISSING")
        require(context.get("origin") == TRUST_ORIGIN
                and context.get("producer") == PRODUCERS[envelope["kind"]]
                and context.get("producer_verified") is True, "PRODUCER")
        require(trust.anchors.get(envelope["subject"]) == digest(context), "ANCHOR")
        require(context["subject"] == envelope["subject"] and context["scope"] == envelope["scope"]
                and context["input_sha256"] == envelope["input_sha256"], "CONTEXT_BINDING")
        now = time(trust.now)
        retrieved, fresh_until = map(time, (context["retrieved_at"], context["fresh_until"]))
        require(retrieved <= now < fresh_until and (fresh_until - retrieved).total_seconds() <= 900,
                "CONTEXT_TIME")
        require(Draft202012Validator(schema.GIT_ID).is_valid(context["source_commit"])
                and Draft202012Validator(schema.GIT_ID).is_valid(context["source_tree"]),
                "CONTEXT_SOURCE")
        evidence = context["evidence"]
        require(isinstance(evidence, dict), "TRUST_MISSING")
        return context

    def approval(self, envelope, trust, approval_ref, operation, effective):
        approval = trust.approvals.get(approval_ref)
        require(isinstance(approval, dict), "APPROVAL_MISSING")
        require(trust.approval_verifications.get(approval_ref) == digest(approval),
                "APPROVAL_UNVERIFIED")
        context = trust.contexts[envelope["subject"]]
        binding = {
            "decision_id": DECISION, "authority": "OD-DELEGATION-01",
            "policy_sha256": POLICY_DIGEST, "approval_id": approval_ref,
            "operation_id": f"{envelope['subject']}:{operation}",
            "operation": operation, "subject": envelope["subject"], "scope": envelope["scope"],
            "input_sha256": envelope["input_sha256"], "effective_input_sha256": digest(effective),
            "source_commit": context["source_commit"], "source_tree": context["source_tree"],
        }
        for field, expected in binding.items():
            require(approval.get(field) == expected, "APPROVAL_" + field.upper())
        require(isinstance(approval.get("evidence_ref"), str) and approval["evidence_ref"],
                "APPROVAL_UNVERIFIED")
        issued, expiry, now = map(time, (approval["issued_at"], approval["expires_at"], trust.now))
        require(type(trust.ttl_limit_seconds) is int and 0 < trust.ttl_limit_seconds <= 900
                and issued <= now < expiry
                and 0 < (expiry - issued).total_seconds() <= trust.ttl_limit_seconds, "APPROVAL_TIME")
        replay = trust.replay.get(approval_ref)
        require(approval.get("status") == "ACTIVE" and replay == {
            "operation_id": binding["operation_id"], "revoked": False, "consumed": False,
        } and replay["revoked"] is False and replay["consumed"] is False, "APPROVAL_STATE")

    def profile(self, envelope, payload, trust, evidence):
        require(not self.legacy.schema_errors(self.original["schemas"]["profile-v2"], payload),
                "INPUT_SHAPE")
        require({k: payload["scope"][k] for k in envelope["scope"]} == envelope["scope"]
                and envelope["subject"] == payload["profile_id"], "PROFILE_BINDING")
        requested = deepcopy(payload)
        desired = {**requested["flags"], **requested.get("desired_flags", {})}
        effective = requested["flags"].copy()
        blocked = []
        inv = "observability.investigations"
        if "observability" in requested["roots_selected"] and desired[inv] is not False:
            if (effective[inv] is not True or
                    evidence.get("capabilities", {}).get(inv) != "FIXTURE_RESOLVED" or
                    self.catalog["region_capabilities"][inv].get(envelope["scope"]["region"])
                    != "DOCUMENTED"):
                effective[inv] = "BLOCKED"
                blocked.append("CAPABILITY_UNRESOLVED")
        paused = {"k8s.network_policy_mode": "np1", "k8s.vpc_cni_network_policy": False}
        if any(requested["flags"][flag] != standard for flag, standard in paused.items()):
            for flag, standard in paused.items():
                if requested["flags"][flag] != standard:
                    effective[flag] = "BLOCKED"
                requested["flags"][flag] = standard
            blocked.append("CAPABILITY_UNRESOLVED")
        if any(value != effective.get(flag) for flag, value in requested.get("desired_flags", {}).items()):
            blocked.append("DESIRED_UNRESOLVED")
        flags = payload["flags"]
        references = requested.pop("owner_approvals", {})
        required = {
            "D-10": flags["security.exposure_findings_automation"] is True,
            "D-13": flags["backup.vault_lock_mode"] == "compliance",
            "OD-R07-EBS": flags["ebs_csi_persistence"] is True,
        }
        for decision, active in required.items():
            if active:
                self.approval(envelope, trust, references.get(decision),
                              APPROVAL_OPERATIONS[decision], effective)
                requested.setdefault("owner_approvals", {})[decision] = references[decision]
        # Graph and security checks still run on otherwise-blocked profiles.
        result = self.legacy.Result()
        self.legacy.Ctx(self.original).profile(result, requested)
        reasons = [reason.split(":", 1)[0] for reason in result.blocked]
        if result.reject:
            raise Violation(result.reject[0].split(":", 1)[0])
        details = {"profile_reasons": sorted(set(reasons + blocked)),
                   "desired_flags": desired, "effective_flags": effective}
        if blocked or reasons:
            raise Violation((blocked or reasons)[0], "BLOCKED", details)
        return details

    def state(self, envelope, payload, trust, evidence):
        current = payload["observed"]
        require(current == evidence["state"], "STATE_BINDING")
        if current["presence"] == "UNKNOWN":
            raise Violation("STATE_UNKNOWN", "BLOCKED")
        require((current["lineage"] is None and current["serial"] is None)
                if current["presence"] == "ABSENT"
                else (current["lineage"] is not None and current["serial"] is not None),
                "STATE_BINDING")
        require(payload["legacy_inventory_sha256"] == self.legacy_inventory
                and payload["moved_blocks_sha256"] == self.moved, "LEGACY_INVENTORY")
        backends = self.catalog["legacy_addresses"]["backends"]
        if current["root"] in backends:
            require(current["backend"] == backends[current["root"]], "STATE_BINDING")
        plan, address = payload["plan"], payload["address"]
        action = plan["action"]
        require(address == evidence["address"] and plan["before"] == evidence["inventory"],
                "PLAN_SCOPE")
        if current["presence"] == "PRESENT" and not payload["selected"]:
            raise Violation("STATE_RETENTION", "BLOCKED")
        transitions = {"ABSENT": {"create", "retain"},
                       "PRESENT": {"retain", "update", "delete", "replace", "migrate"}}
        require(action in transitions[current["presence"]], "STATE_OPERATION")
        before, after = set(plan["before"]), set(plan["after"])
        require((address in before) == (current["presence"] == "PRESENT"), "PLAN_SCOPE")
        expected = {"create": before | {address}, "delete": before - {address}}
        if action != "migrate":
            require(plan["migration_target"] is None, "ENGINE_MIGRATION")
            require(after == expected.get(action, before), "PLAN_SCOPE")
        require(payload["selected"] or action == "retain", "STATE_OPERATION")
        require(current["presence"] == "PRESENT" or not payload["selected"] or action == "create",
                "STATE_OPERATION")
        require(payload["engine_before"] == evidence["engine"]
                and payload["backup_before"] == evidence["backup_mode"], "STATE_BINDING")
        engine_changed = payload["engine_before"] != payload["engine_after"]
        if engine_changed or action == "migrate":
            require(engine_changed and action == "migrate", "ENGINE_MIGRATION")
            target = plan["migration_target"]
            resource_type = {"rds": "aws_db_instance", "aurora": "aws_rds_cluster"}
            require(target is not None and target not in before
                    and target == evidence.get("migration_target")
                    and resource_type[payload["engine_before"]] in address.split(".")[:-1]
                    and resource_type[payload["engine_after"]] in target.split(".")[:-1]
                    and before | {target} == after, "ENGINE_MIGRATION")
            require(payload["migration_evidence_sha256"] is not None
                    and payload["migration_evidence_sha256"] == evidence.get("migration_evidence_sha256"),
                    "ENGINE_MIGRATION")
        wanted_writer = {"native": "native-pitr", "continuous": "aws-backup-continuous"}
        require(payload["pitr_writers"] == [wanted_writer[payload["backup_after"]]], "BACKUP_WRITERS")
        backup_changed = payload["backup_before"] != payload["backup_after"]
        operations = []
        if action != "retain":
            operations.append("state:" + action)
        if backup_changed:
            require(payload["selected"] and current["presence"] == "PRESENT", "STATE_OPERATION")
            operations.append("state:backup-mode-migration")
        if operations:
            self.approval(envelope, trust, payload["approval_ref"], "+".join(operations), payload)
        return {"presence": current["presence"], "plan_action": action, "restore_witness": "NOT_TESTED"}

    def ownership(self, envelope, payload, trust, evidence):
        boundary = payload["boundary"]
        mode, operation = payload["mode"], payload["operation"]
        require({k: boundary[k] for k in envelope["scope"]} == envelope["scope"],
                "OWNERSHIP_BINDING")
        registry = evidence["registry"]
        identities = [digest(row["boundary"]) for row in registry]
        require(len(identities) == len(set(identities)), "OWNERSHIP_REGISTRY")
        matching = [row for row in registry if row["boundary"] == boundary]
        require(len(matching) == 1 and matching[0]["mode"] == mode, "OWNERSHIP_BINDING")
        row = matching[0]
        feature = boundary["feature"]
        if operation == "create":
            require(feature != "organizations", "ORG_CREATE")
        if operation == "import":
            require(mode != "service-managed" and not row.get("service_created"), "SERVICE_IMPORT")
        require(feature != "config-service-linked-recorder" or mode in ("service-managed", "disabled"),
                "OWNERSHIP_BINDING")
        if mode == "create":
            require(not row.get("service_created"), "OWNERSHIP_BINDING")
        if mode == "create" and feature == "security-lake":
            requires_trail = row.get("requires_org_trail")
            require(type(requires_trail) is bool and (
                not requires_trail or row.get("org_trail_witness") == "FIXTURE_VERIFIED"
            ), "ORG_TRAIL_PREREQUISITE", "BLOCKED")
        permitted = {"create": {"create", "read", "retain"}, "existing": {"read", "retain"},
                     "disabled": {"retain"}, "service-managed": {"read", "retain"}}
        require(operation in permitted[mode], "OWNERSHIP_READ_ONLY")
        require(payload["writers"] == row["writers"], "OWNERSHIP_WRITERS")
        count = len(payload["writers"])
        require(count <= 1 if mode == "disabled" else count == 1,
                "OWNERSHIP_WRITERS")
        if mode == "service-managed":
            require(row.get("service_writer") == payload["writers"][0], "OWNERSHIP_WRITERS")
        return {"feature": feature, "mode": mode, "operation": operation}

    def key(self, envelope, payload, trust, evidence):
        binding = payload["binding"]
        status = self.catalog["key_consumers"].get(binding["root"])
        fixed = {"tfstate": "SSE-S3", "legacy-ecr": "AES256", "alb-delivery": "SSE-S3"}
        root, consumer = binding["root"], binding["consumer"]
        require(not consumer.isspace() and (root == "tfstate" or
                (status is not None and root != "$comment")), "KEY_CONSUMER")
        row = evidence.get("key_row")
        if row is None and status == "OPEN":
            raise Violation("KEY_CONSUMER_OPEN", "BLOCKED")
        require(isinstance(row, dict), "KEY_CONSUMER")
        require({k: binding[k] for k in envelope["scope"]} == envelope["scope"]
                and binding == row["binding"], "KEY_SCOPE")
        before, after = payload["encryption_before"], payload["encryption_after"]
        require(before == after == row["encryption"], "ENCRYPTION_CHANGE")
        fixed_class = row.get("fixed_class")
        require(fixed_class is None or fixed.get(fixed_class) == before, "ENCRYPTION_CHANGE")
        if root == "tfstate":
            require(fixed_class == "tfstate" and binding["service"] == "s3.amazonaws.com",
                    "ENCRYPTION_CHANGE")
        if root == "registry" and consumer in self.catalog["legacy_addresses"]["registry_legacy_keys"]:
            require(fixed_class == "legacy-ecr" and binding["service"] == "ecr.amazonaws.com",
                    "ENCRYPTION_CHANGE")
        if fixed_class == "alb-delivery":
            require(binding["service"] == "s3.amazonaws.com", "ENCRYPTION_CHANGE")
        if payload["exception"] is not None:
            require(payload["exception"] == row.get("exception") == "D-04-EX01"
                    and binding["root"] == "security-baseline"
                    and binding["service"] == "securitylake.amazonaws.com"
                    and before == "SERVICE-MANAGED" and binding["operation"] == "read",
                    "EXCEPTION_SCOPE")
        else:
            require(not row.get("exception"), "EXCEPTION_SCOPE")
        if binding["operation"] in ("grant", "disable", "delete"):
            require(before == "CMK" and binding["key"] is not None, "KEY_SCOPE")
        require(payload["retention_days"] is not None and row.get("retention_days") is not None,
                "RETENTION_UNKNOWN", "BLOCKED")
        require(payload["retention_days"] == row["retention_days"], "RETENTION_SCOPE")
        require(payload["historical_dependencies"] == row["historical_dependencies"]
                and set(payload["historical_dependencies"]) <= set(payload["retained_dependencies"]),
                "KEY_HISTORY")
        if binding["operation"] in ("disable", "delete"):
            require(not row["historical_dependencies"] and row.get("active_dependencies") == [],
                    "KEY_HISTORY")
            self.approval(envelope, trust, payload["approval_ref"], "key:" + binding["operation"],
                          payload)
        return {"catalog_status": status, "retention": "FIXTURE_ONLY"}

    def boundary(self, envelope, payload, trust, evidence):
        row = self.fields.get((payload["root"], payload["field"]))
        require(row is not None, "UNKNOWN_TYPED_BOUNDARY")
        require(row["technical_acceptance"] == "OPEN" and row["execution_authorized"] is False,
                "TYPED_BOUNDARY_DRIFT")
        raise Violation("TYPED_INPUT_OPEN", "BLOCKED", {
            "class": row["original_class"], "technical_acceptance": "OPEN",
        })
