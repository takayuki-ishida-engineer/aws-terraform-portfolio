"""Static Maven declarations and parent/BOM projection. No Maven resolver is invoked."""
from pathlib import Path
import re

from acquire import RAW, key, xml

FIELDS = ("groupId", "artifactId", "version", "type", "classifier", "scope", "optional", "systemPath")
PROPERTY = re.compile(r"\$\{([^}]+)\}")


def coord(node):
    return tuple(node.findtext(k, "") for k in FIELDS[:3])


def binding(row):
    return (row.get("groupId"), row.get("artifactId"), row.get("type", "jar"), row.get("classifier", ""))


def resolve(value, props):
    if not isinstance(value, str):
        return value
    for _ in range(20):
        replaced = PROPERTY.sub(lambda m: props.get(m[1]) or m[0], value)
        if replaced == value:
            break
        value = replaced
    return value


def declaration(node, origin, props):
    row = {k: node.findtext(k) for k in FIELDS if node.find(k) is not None}
    return {
        **{k: resolve(v, props) for k, v in row.items()},
        "declared": row,
        "exclusions": [
            {k: resolve(e.findtext(k), props) for k in ("groupId", "artifactId")}
            for e in node.findall("exclusions/exclusion")
        ],
        "origin": origin,
    }


def bounded_graph(coords, stack=()):
    if coords in stack:
        raise ValueError("Cyclic parent/BOM model")
    name = key(coords, "pom")
    path = RAW / name
    if not path.is_file():
        return {"missing": [":".join(coords)], "properties": {}, "managed": {}, "dependencies": {},
                "parents": [], "imports": [], "profiles": [], "plugin_declarations": []}
    root = xml(path.read_bytes())
    parent = root.find("parent")
    base = bounded_graph(coord(parent), (*stack, coords)) if parent is not None else {
        "missing": [], "properties": {}, "managed": {}, "dependencies": {}, "parents": [],
        "imports": [], "profiles": [], "plugin_declarations": [],
    }
    properties = {**base["properties"], **{el.tag: el.text for el in root.findall("properties/*")},
                  **{f"{prefix}.{part}": value for prefix in ("project","pom")
                     for part,value in zip(FIELDS[:3],coords)}}
    if parent is not None:
        properties.update({f"project.parent.{part}": value for part,value in zip(FIELDS[:3],coord(parent))})
    managed = dict(base["managed"])
    inherited = dict(base["dependencies"])
    parents = [*base["parents"], *([":".join(coord(parent))] if parent is not None else [])]
    imports = list(base["imports"])
    missing = list(base["missing"])
    imported = {}
    management_declarations = [
        declaration(node, name, properties) for node in root.findall("dependencyManagement/dependencies/dependency")
    ]
    for row in management_declarations:
        if row.get("scope") != "import" or row.get("type") != "pom":
            continue
        bom = tuple(row.get(k,"") for k in FIELDS[:3])
        model = bounded_graph(bom, (*stack, coords))
        for k, v in model["managed"].items():
            imported.setdefault(k, v)
        imports += [":".join(bom), *model["imports"]]
        missing += model["missing"]
    managed.update(imported)
    for row in management_declarations:
        if row.get("scope") != "import":
            managed[binding(row)] = row
    direct = [declaration(node,name,properties) for node in root.findall("dependencies/dependency")]
    for item in direct:
        k = binding(item)
        previous = inherited.get(k,{})
        inherited[k] = {**previous, **item}
    profiles = [*base["profiles"], *[{"model":name,"id":p.findtext("id"),
                                     "scope":"NOT_EVALUATED",
                                     "dependency_count":len(p.findall("dependencies/dependency")),
                                     "management_count":len(p.findall("dependencyManagement/dependencies/dependency"))}
                                   for p in root.findall("profiles/profile")]]
    plugins = list(base["plugin_declarations"])
    for context in ("build/plugins/plugin", "build/pluginManagement/plugins/plugin"):
        for p in root.findall(context):
            if p.findtext("artifactId") != "maven-shade-plugin":
                continue
            plugins.append({
                "origin":name,"context":context,"artifactId":p.findtext("artifactId"),"version":p.findtext("version"),
                "relocations":[{"pattern":r.findtext("pattern"),"shadedPattern":r.findtext("shadedPattern")}
                               for r in p.findall(".//relocation")],
                "artifact_set_includes":[s.text for s in p.findall(".//artifactSet/includes/include")],
                "artifact_set_excludes":[s.text for s in p.findall(".//artifactSet/excludes/exclude")],
                "executions":[{"id":e.findtext("id"),"phase":e.findtext("phase"),
                               "goals":[g.text for g in e.findall("goals/goal")]} for e in p.findall("executions/execution")],
            })
    return {"missing":sorted(set(missing)),"properties":properties,"managed":managed,"dependencies":inherited,
            "parents":parents,"imports":list(dict.fromkeys(imports)),"profiles":profiles,"plugin_declarations":plugins,
            "direct":direct,"management_declarations":management_declarations,
            "pom_license_declarations":[{"name":n.findtext("name"),"url":n.findtext("url")}
                                        for n in root.findall("licenses/license")]}


def inspect_model(coords):
    graph = bounded_graph(coords)
    output = []
    for k, row in graph["dependencies"].items():
        defaults = graph["managed"].get(k,{})
        scope = row.get("scope") or defaults.get("scope") or "compile"
        version = row.get("version") or defaults.get("version")
        optional = row.get("optional") or defaults.get("optional") or "false"
        inherited_exclusions = defaults.get("exclusions",[])
        exclusions = list({tuple(sorted(e.items())):e for e in inherited_exclusions+row["exclusions"]}.values())
        entry = {
            "coordinates": f"{k[0]}:{k[1]}","type":k[2],"classifier":k[3],"version":version,"scope":scope,"optional":optional,
            "exclusions":exclusions,"declared_in":row["origin"],"inherited":row["origin"]!=key(coords,"pom"),
            "managed_default_origin":defaults.get("origin"),"literal_declaration":row["declared"],
            "version_status":"MODEL_VERSION_KNOWN" if version and "${" not in version else "UNRESOLVED",
            "runtime_role":{"compile":"MODEL_RUNTIME_CANDIDATE","runtime":"MODEL_RUNTIME_CANDIDATE",
                            "provided":"RUNTIME_PROVIDED_CONTRACT_ONLY","test":"TEST_ONLY",
                            "system":"LOCAL_SYSTEM_NOT_VERIFIED"}.get(scope,"UNRESOLVED_SCOPE")}
        output.append(entry)
    return {"coordinates":":".join(coords),"parent_chain":graph["parents"],"imported_boms":graph["imports"],
            "unresolved_parent_or_bom":graph["missing"],"version_properties":{k:v for k,v in graph["properties"].items()
                                                                               if re.search(r"kafka|flink|avro|java|aws.sdk",k,re.I)},
            "direct_declarations":graph.get("direct",[]),"management_declarations":graph.get("management_declarations",[]),
            "effective_management_entries":len(graph["managed"]),"static_direct_scope_projection":output,
            "inherited_and_local_shade_plugin_declarations":graph["plugin_declarations"],"profiles":graph["profiles"],
            "pom_license_declarations":graph.get("pom_license_declarations",[]),
            "resolution":"PARTIAL_NO_ACTIVE_PROFILE_OR_TRANSITIVE_GRAPH_EXECUTED"}
