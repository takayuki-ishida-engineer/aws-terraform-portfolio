"""Derive route compatibility and recorded advisory applicability from measured metadata."""
from pathlib import Path

from acquire import RAW, identity, key, save
from qualify import read, require


def main():
    inventory=read("JAR_PLUGIN_CLASS_INVENTORY.json")
    deps=read("DEPENDENCY_INVENTORY.json")["models"]
    java=read("JAVA_COMPATIBILITY_MATRIX.json")["artifacts"]
    advisory_path=RAW/"kafka-cve-existing.json"
    advisory=read(advisory_path)
    require(advisory["cve_id"]=="CVE-2026-35554" and advisory["ghsa_id"]=="GHSA-5qcv-4rpc-jp93","Advisory identity")
    ranges=[{k:d[k] for k in ("package","vulnerable_version_range","first_patched_version")}
            for d in advisory["vulnerabilities"] if d["package"]["name"]=="org.apache.kafka:kafka-clients"]
    expected={">= 2.8.0, < 3.9.2",">= 4.0.0, < 4.0.2",">= 4.1.0, < 4.1.2"}
    require({d["vulnerable_version_range"] for d in ranges}==expected,"Recorded advisory range delta")
    kafka="org.apache.kafka:kafka-clients"
    observations=[]
    for gav,d in deps.items():
        for entry in d["static_direct_scope_projection"]:
            if entry["coordinates"]==kafka:
                v=entry["version"]
                cases={"3.4.0":"WITHIN_AFFECTED_APACHE_MAVEN_RANGE","3.6.1":"WITHIN_AFFECTED_APACHE_MAVEN_RANGE",
                       "3.9.2":"FIRST_PATCHED_IN_3_X_RANGE_FOR_THIS_ADVISORY_ONLY"}
                observations.append(dict(artifact=gav,kind="POM_STATIC_DIRECT_SCOPE_PROJECTION",kafka_version=v,
                                          scope=entry["scope"],outcome=cases.get(v,"UNRESOLVED")))
    observations += [
         dict(artifact="org.apache.kafka:kafka-clients:3.9.2",kind="EXACT_STANDALONE_JAR_IDENTITY",
              outcome="FIRST_PATCHED_IN_3_X_RANGE_FOR_THIS_ADVISORY_ONLY"),
         dict(artifact="Lenses S3 Sink 11.7.3",kind="ASSEMBLY_HEADER_AND_DISTRIBUTION_SBOM",
              kafka_manifest_version=inventory["jars"]["lenses-assembly"]["manifest_flags"]["kafka-version"],
              sbom_distribution="8.1.0-ccs",base_non_connect_kafka_classes=inventory["jars"]["lenses-assembly"]["base_non_connect_kafka_class_count"],
              outcome="OPEN_CCS_MAPPING_AND_EFFECTIVE_WORKER_CLASSPATH; 4.1.0 marker alone is not version identity of a shipped Apache client"),
    ]
    for v in ("1.1.27","2.0.2"):
        jar=key(("software.amazon.glue","schema-registry-kafkaconnect-converter",v),"jar")
        stats=inventory["jars"][jar]
        matches=stats["base_kafka_class_overlap_vs_3_9_2"]["byte_identical"]
        observations.append(dict(artifact="Glue Connect Converter "+v,kind="BASE_KAFKA_BYTE_COMPARISON",
              classes=stats["base_non_connect_kafka_class_count"],identical_vs_pinned_apache_3_9_2=matches,
              outcome=("EXACT_NON_CONNECT_BASE_CLASS_SET_MATCHES_3_9_2; EFFECTIVE_ROUTE_OPEN" if matches==3849
                       else "DIFFERS_FROM_3_9_2; ASSOCIATED_SERDE_AFFECTED_DECLARATION; SHIPPED_VERSION_NOT_PROVEN_BY_DECLARATION")))
    save("CVE_APPLICABILITY_REPORT.json",dict(advisory=advisory["cve_id"],ghsa=advisory["ghsa_id"],url=advisory["html_url"],
         advisory_raw_sha256=identity(advisory_path.read_bytes()),ranges=ranges,observations=observations,
         scope="Single recorded advisory. No scan, runtime reachability, or overall security conclusion."))
    routes={
      "A_MSK_Connect_3_7_x_Java17":{
        "status":"HOLD",
        "lenses_artifact":"Pinned official S3 ZIP, no purchase or license acceptance needed for retrieval",
        "compatibility":"Assembly max normal major 61 fits Java17. Manifest Kafka marker 4.1.0, publisher SBOM Connect API 4.1.0 and kafka-clients 8.1.0-ccs; worker is 3.7.x. Linkage remains NOT_TESTED.",
        "auth":"SBOM AWS SDK auth, STS and S3 2.29.52. No pinned MSK IAM Auth or unrelocated Kafka client classes identified in the assembly. Worker IAM support, callbacks and plugin loader visibility require independent route evidence.",
        "glue_boundary":"Glue Kafka Connect Converter is an independent module and is not established as Lenses assembly content. Lenses includes Confluent converter classes; Glue converter selection and runtime isolation require evidence.",
        "overlap_observations":{v:inventory["route_duplicate_class_candidates"][v]["connect"] for v in ("1.1.27","2.0.2")},
      },
      "B_Managed_Flink_1_20_5_Java11":{
        "status":"HOLD",
        "compatibility":"Connector 3.3.0-1.20 POM projects Flink 1.19.1 provided. 3.4.0-1.20 projects 1.20.0 provided. Both project Kafka client 3.4.0 compile and their ordinary classes max at major 52. Managed 1.20.5 linkage, effective classpath, and state recovery remain unverified.",
        "glue_boundary":"If this route uses Glue, use the route-specific Flink SerDe plus core SerDe as candidates. Both Glue Flink SerDe POMs use Flink 1.12.2 provided. Do not put the Kafka Connect converter on the Flink Java11 classpath.",
        "iam_boundary":"The pinned MSK IAM Auth 2.4.0 JAR includes major 61 normal classes. A route loading this JAR on Java11 is statically incompatible. No alternate version or classloader change selected.",
        "sql_connector":"NOT_ACQUIRED; no approved SQL-specific connector route in the input",
      },
      "C_Glue_modules":{
        "status":"HOLD",
        "scope":"Only core SerDe; Connect Avro converter for MSK Connect; Flink Avro SerDe for Managed Flink. Parent/BOM POMs for those models.",
        "projections":"Core SerDe compile Kafka 3.6.1 vs 3.9.2. Both Connect converters contain major 61 normal classes. Both Flink bridge JARs contain major 52 normal classes; their provided Flink 1.12.2 remains a compatibility risk.",
        "api_delta":{k:{'old_symbols':v['old_symbols'],'new_symbols':v['new_symbols'],
                        'removed':len(v['removed_public_or_protected']),'added':len(v['added_public_or_protected'])}
                     for k,v in inventory["glue_api_delta"].items()},
        "migration":"2.0.2 remains a separate major-migration decision. Static API deltas do not attest safe Schema Evolution or Wire Compatibility.",
      },
      "D_Kafka_and_MSK_IAM":{
        "status":"HOLD",
        "kafka":"Kafka Java Client 3.9.2 standalone JAR fits Java11/17 by class major 52; this artifact matches the fixed candidate for the recorded advisory only.",
        "iam":"IAM Auth 2.4.0 requires Java17 by ordinary class major 61; AWS SDK auth, regions, SSO, SSO OIDC, STS and Apache5 client project SDK 2.51.2 via the BOM. Runtime/ABI, worker integration and security remain OPEN.",
      },
      "runtime_tests":{n:"NOT_TESTED" for n in ("Maven resolution","Java linkage","Plugin loading","MSK IAM authentication",
                     "Checkpoint","Savepoint","Schema Evolution","Wire Compatibility","Managed Runtime","S3 output identity")},
    }
    require(java[key(("software.amazon.msk","aws-msk-iam-auth","2.4.0"),"jar")]["versions"]["11"]["normal_bytecode_result"]=="FAIL_MAJOR","IAM compatibility")
    require(inventory["jars"]["lenses-assembly"]["base_non_connect_kafka_class_count"]==0 and
            inventory["jars"]["lenses-assembly"]["manifest_flags"]["kafka-version"]=="4.1.0","Lenses facts")
    save("PER_ROUTE_COMPATIBILITY_MATRIX.json",routes)
    save("REMAINING_GATE_REGISTER.json",{
      "B-06":"HOLD","B-07":"HOLD","M1-TOOLS":"HOLD","CI-INT-01":"HOLD","INT-00":"HOLD",
      "OD-HO-06":"NOT_AUTHORIZED","technical_witnesses":{"status":"OPEN","count":120},
      "L1":"PARTIAL_EXACT_BYTES_AND_REPOSITORY_CHECKSUMS; PUBLISHER_TRUST_OPEN",
      "L2":"PARTIAL_NO_FULL_EFFECTIVE_CLASSPATH",
      "L3":"PARTIAL_BYTECODE_ONLY; MSK_IAM_AUTH_2_4_0_JAVA11_FAIL_MAJOR",
      "L4":"PARTIAL_TIMESTAMP_AND_RECORDED_ADVISORY; SCAN_AND_SIGNATURE_NOT_TESTED",
      "L5":"PARTIAL_OFFLINE_REPLAY; NO_MANAGED_LOCK_OR_ROLLBACK_WITNESS",
      "L6":"NOT_TESTED","L7":"NOT_TESTED","artifact_adoption":"HOLD","independent_review":"PENDING",
    })


if __name__=="__main__":
    main()
