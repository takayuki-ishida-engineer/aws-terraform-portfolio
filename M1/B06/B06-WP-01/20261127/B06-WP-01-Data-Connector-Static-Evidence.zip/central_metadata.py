"""Fetch timestamp evidence for only the exact qualifying Central GAVs."""
from urllib.parse import urlencode
from acquire import TOP,batch,save

def main():
    tasks=[]
    for g,a,v in sum(TOP.values(),[]):
        query=urlencode(dict(q=f"g:{g} AND a:{a} AND v:{v}",core="gav",rows=1,wt="json"))
        tasks.append((f"{g}.{a}.{v}.central.json","https://central.sonatype.com/solrsearch/select?"+query,524288))
    save("acquisition-central-metadata.json",batch(tasks))

if __name__=="__main__":
    main()
