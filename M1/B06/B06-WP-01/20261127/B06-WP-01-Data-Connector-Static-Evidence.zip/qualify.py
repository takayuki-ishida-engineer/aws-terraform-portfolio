"""Offline verification and route evidence for fixed B06 candidates."""
from collections import Counter
from datetime import datetime, timezone, timedelta
from email.utils import parsedate_to_datetime
from hashlib import sha1
from io import BytesIO
import json
from pathlib import Path
import re
from zipfile import ZipFile

from acquire import A_SHA, A_SIZE, LA, ROOT, RAW, TOP, identity, key, save, xml
from jar_inventory import choice, inspect_jar, require, safe_members
from pom_model import inspect_model


def read(path):
    return json.loads(Path(path).read_bytes())


def test_controls():
    checks = []
    def record(name, expected, call):
        try:
            actual = call()
        except ValueError as error:
            actual = str(error)
        checks.append(dict(id=name,expected=expected,actual=actual,match=actual==expected))
    def archive_check(names):
        out = BytesIO()
        with ZipFile(out,"w") as z:
            for name in names:
                z.writestr(name,b"fixture")
        with ZipFile(out) as z:
            safe_members(z)
        return "ACCEPT"
    record("ZIP_NORMAL","ACCEPT",lambda:archive_check(["safe.class"]))
    record("ZIP_TRAVERSAL","UNSAFE_OR_DUPLICATE_ZIP_MEMBER",lambda:archive_check(["../bad.class"]))
    record("XML_EXTERNAL_ENTITY_BLOCK","DTD/entity prohibited",lambda:xml(b'<!DOCTYPE x SYSTEM "file:///forbidden"><x/>'))
    fixture = [(0,"Test.class",52),(11,"Test.class",55),(17,"Test.class",61)]
    record("MR_JAVA11_OVERRIDE",55,lambda:choice(fixture,11,True)["Test.class"][1])
    record("MR_NOT_ENABLED",52,lambda:choice(fixture,11,False)["Test.class"][1])
    record("MR_JAVA17_OVERRIDE",61,lambda:choice(fixture,17,True)["Test.class"][1])
    require(all(r["match"] for r in checks),"Guards fail")
    return checks


def inventory_receipts():
    acquisition_files=sorted(Path(".").glob("acquisition-*.json"))
    rows=[r for p in acquisition_files for r in read(p)]
    retained=read("existing-source-receipts.json")
    build=RAW/"lenses-build-sbt-11.7.3"
    okay=Path('lenses-build-http.txt').read_text().strip().split()==["200","200"]
    require(okay,"Lenses source response")
    retained.append(dict(name=build.name,path=str(build),sha256=identity(build.read_bytes()),
        size_bytes=build.stat().st_size,http_status=200,proxy_connect=200,
        observed_at_utc=Path("lenses-build-observed.txt").read_text().strip(),
        status="ACQUIRED",url="https://raw.githubusercontent.com/lensesio/stream-reactor/11.7.3/build.sbt"))
    files={r["name"]:r for r in rows+retained if r.get("path")}
    require({str(p) for p in RAW.iterdir()}=={r["path"] for r in files.values()},"Raw inventory coverage")
    for r in files.values():
        b=Path(r["path"]).read_bytes()
        require((len(b),identity(b))==(r["size_bytes"],r["sha256"]),"Raw identity")
        r["publication"]="SCRATCH_IMMUTABLE_REFERENCE_ONLY"
        r["publication_reason"]="Third-party release, distribution or repository bytes. Redistribution clearance not established."
    matched=[]
    for name,row in sorted(files.items()):
        if row["url"].startswith(ROOT+"/") and not name.endswith(".sha1"):
            offered=files.get(name+".sha1")
            require(offered is not None,"Missing checksum response for "+name)
            expected=Path(offered["path"]).read_text().strip().split()[0].lower()
            require(re.fullmatch("[a-f0-9]{40}",expected) is not None,"Publisher checksum format")
            actual=sha1(Path(row["path"]).read_bytes(),usedforsecurity=False).hexdigest()
            require(actual==expected,"Publisher repository checksum mismatch "+name)
            matched.append(dict(name=name,checksum_uri=offered["url"],algorithm="SHA-1",
                                expected=expected,actual=actual,result="MATCH_REPOSITORY_CHECKSUM_ONLY"))
    l=read(RAW/"lenses-release-existing.json")
    a=[x for x in l["assets"] if x["name"]=="kafka-connect-aws-s3-11.7.3.zip"]
    require(l["tag_name"]=="11.7.3" and len(a)==1 and a[0]["browser_download_url"]==LA
            and (a[0]["size"],a[0]["digest"])==(A_SIZE,"sha256:"+A_SHA)
            and (files["lenses-s3-11.7.3.zip"]["size_bytes"],files["lenses-s3-11.7.3.zip"]["sha256"])
            ==(A_SIZE,A_SHA),"Lenses publisher identity")
    matched.append(dict(name="lenses-s3-11.7.3.zip",algorithm="SHA-256",expected=A_SHA,actual=A_SHA,
                        checksum_uri="https://api.github.com/repos/lensesio/stream-reactor/releases/tags/11.7.3",
                        result="MATCH_RELEASE_ASSET_CHECKSUM"))
    return files,rows+retained,matched,l["published_at"]


def jar_analysis():
    jars,classes,api={}, {}, {}
    ref=key(TOP["D"][0],"jar")
    result,variants,signatures,reference_hashes=inspect_jar(RAW/ref)
    jars[ref],classes[ref],api[ref]=result,variants,signatures
    for coords in sum(TOP.values(),[]):
        n=key(coords,"jar")
        if n==ref:
            continue
        r,c,s,_=inspect_jar(RAW/n,glue_api=coords[0]=="software.amazon.glue",kafka_reference=reference_hashes)
        jars[n],classes[n],api[n]=r,c,s
    with ZipFile(RAW/"lenses-s3-11.7.3.zip") as z:
        members=safe_members(z)
        require(z.testzip() is None,"Plugin CRC")
        jar,=sorted(n for n in members if n.endswith(".jar"))
        bom,=sorted(n for n in members if n.endswith(".spdx.json"))
        data=z.read(jar)
        sbom=json.loads(z.read(bom))
        license_members=[dict(path=n,size_bytes=len(z.read(n)),sha256=identity(z.read(n)),
                              apache_2_header=b"Apache License" in z.read(n) and b"Version 2.0" in z.read(n))
                         for n in sorted(members) if n.rsplit("/",1)[-1].lower().startswith(("license","notice"))]
        components=[]
        for p in sbom["packages"]:
            name=p.get("name","")
            if re.search(r"kafka|schema.registry|msk|awssdk|^connect-(api|runtime|json)$|^auth$|^sts$|^s3$|sdk-core|^avro$",name,re.I):
                purls=[e["referenceLocator"] for e in p.get("externalRefs",[]) if e.get("referenceType")=="purl"]
                components.append(dict(name=name,version=p.get("versionInfo"),purls=purls))
        plugin=dict(nested_assembly=dict(path=jar,size_bytes=len(data),sha256=identity(data)),
                    sbom=dict(path=bom,sha256=identity(z.read(bom)),components=components,
                              status="SUPPLIED_SBOM_STATIC_DECLARATIONS"),
                    archive_members=sorted(members),archive_safety_crc="PASS",
                    outer_license_notice_members=license_members)
    jar_result,c,s,_=inspect_jar(BytesIO(data),kafka_reference=reference_hashes)
    jars["lenses-assembly"]=jar_result
    classes["lenses-assembly"]=c
    api_delta={}
    for a in ("schema-registry-serde","schema-registry-flink-serde","schema-registry-kafkaconnect-converter"):
        older=api[key(("software.amazon.glue",a,"1.1.27"),"jar")]
        newer=api[key(("software.amazon.glue",a,"2.0.2"),"jar")]
        api_delta[a]=dict(old_symbols=len(older),new_symbols=len(newer),
                          removed_public_or_protected=sorted(older-newer),
                          added_public_or_protected=sorted(newer-older),
                          status="BYTECODE_SYMBOL_DELTA_ONLY_RUNTIME_OPEN",
                          limits="No source signature, behavior, wire, reflection, generics or actual linkage test.")
    routes={}
    for v in ("1.1.27","2.0.2"):
        converter=key(("software.amazon.glue","schema-registry-kafkaconnect-converter",v),"jar")
        serde=key(("software.amazon.glue","schema-registry-serde",v),"jar")
        flink=key(("software.amazon.glue","schema-registry-flink-serde",v),"jar")
        iam=key(TOP["D"][1],"jar")
        connect=[("lenses-assembly",converter,17),(converter,ref,17),("lenses-assembly",ref,17),(converter,serde,17)]
        flink_set=[(flink,serde,11),(ref,serde,11),(ref,iam,11)]
        def rows(pairs):
            result=[]
            for left,right,level in pairs:
                common=classes[left][level]&classes[right][level]
                result.append(dict(left=left,right=right,java=level,count=len(common),sample=sorted(common)[:10]))
            return result
        routes[v]=dict(connect=rows(connect),flink=rows(flink_set))
    return jars,plugin,api_delta,routes


def main():
    receipts,attempts,checks,published=inventory_receipts()
    guards=test_controls()
    models={":".join(c):inspect_model(c) for c in sum(TOP.values(),[])}
    jars,plugin,api,collisions=jar_analysis()
    require(all(v["archive_safety_crc"]=="PASS" for v in jars.values()),"Unsafe archive")
    require(all(not v["unresolved_parent_or_bom"] for v in models.values()),"Missing parent or BOM")
    threshold=14
    ages={}
    for name,row in receipts.items():
        if row["url"].startswith(ROOT+"/") and name.endswith(".jar"):
            dt=parsedate_to_datetime(row["last-modified"])
            now=datetime.fromisoformat(row["observed_at_utc"])
            ages[name] = dict(repository_http_last_modified_utc=dt.isoformat(),observed_at_utc=now.isoformat(),
                age_seconds=int((now-dt).total_seconds()),threshold_days=threshold,
                age_on_repository_object_clock="PASS_TIMESTAMP_ONLY" if now>=dt+timedelta(days=threshold) else "HOLD_AGE",
                independent_first_publication_timestamp="OPEN")
    for group,artifact,release in sum(TOP.values(),[]):
        gav=f"{group}:{artifact}:{release}"
        record=receipts.get(f"{group}.{artifact}.{release}.central.json")
        if record is None:
            continue
        listing=read(record["path"])["response"]
        docs=listing["docs"]
        require(listing["numFound"]==1 and len(docs)==1 and docs[0]["id"]==gav
                and docs[0]["repositoryId"]=="central","Central timestamp identity")
        stamp=datetime.fromtimestamp(docs[0]["timestamp"]/1000,timezone.utc)
        observed=datetime.fromisoformat(record["observed_at_utc"])
        ages[key((group,artifact,release),"jar")].update(
            central_index_timestamp_utc=stamp.isoformat(),central_index_url=record["url"],
            central_index_age_seconds=int((observed-stamp).total_seconds()),
            central_index_age="PASS_INDEXED_RELEASE_TIMESTAMP_ONLY" if observed>=stamp+timedelta(days=threshold) else "HOLD_AGE",
            timestamp_scope="Central exact GAV index. Object Last-Modified and any build clock are separate.")
    pub=datetime.fromisoformat(published)
    now=datetime.fromisoformat(receipts["lenses-s3-11.7.3.zip"]["observed_at_utc"])
    ages["Lenses-11.7.3"]=dict(official_release_published_at_utc=published,
           age_seconds=int((now-pub).total_seconds()),threshold_days=threshold,
           release_age="PASS_RELEASE_TIMESTAMP_ONLY" if now>=pub+timedelta(days=threshold) else "HOLD_AGE")
    save("EXACT_ARTIFACT_IDENTITY_MANIFEST.json",dict(files=list(receipts.values()),attempts=attempts))
    top_poms={key(c,"pom") for c in sum(TOP.values(),[])}
    controls={}
    for path in sorted(RAW.glob("*.pom")):
        if path.name in top_poms:
            continue
        root=xml(path.read_bytes())
        parent=root.find("parent")
        def declarations(selector):
            return [{k:node.findtext(k) for k in ("groupId","artifactId","version","scope","type","classifier","optional")
                     if node.find(k) is not None} for node in root.findall(selector)]
        controls[path.name]=dict(
            declared_parent=([parent.findtext(k) for k in ("groupId","artifactId","version")] if parent is not None else None),
            declared_dependencies=declarations("dependencies/dependency"),
            dependency_management_declarations=declarations("dependencyManagement/dependencies/dependency"),
            license_declarations=[dict(name=n.findtext("name"),url=n.findtext("url")) for n in root.findall("licenses/license")])
    save("DEPENDENCY_INVENTORY.json",dict(models=models,control_pom_inventory=controls,closure="PARTIAL",
         lens_build="Official source tag identifies an sbt assembly; Maven project POM/Parent/BOM do not describe the published Lenses assembly.",
         limitations=["No active-profile build, equivalent Maven effective model, transitive dependency mediation or classloader execution.",
                       "Reported direct scopes are a static projection. System/provided scopes are not resolved runtime dependencies."]))
    save("JAR_PLUGIN_CLASS_INVENTORY.json",dict(jars=jars,lenses_plugin=plugin,glue_api_delta=api,
         route_duplicate_class_candidates=collisions))
    save("JAVA_COMPATIBILITY_MATRIX.json",dict(artifacts={name:{
          "multi_release":data["multi_release"],"versions":data["java_selection"],"runtime_linkage":"NOT_TESTED"
        } for name,data in jars.items()},major_limits={"11":55,"17":61},
        scope="Normal selected class headers with multi-release metadata and classpath selection. Module descriptors are reported separately."))
    save("RELEASE_AGE_AND_TRUST.json",dict(ages=ages,checksum_count=len(checks),
         publisher_trust="OPEN",signature_verification="NOT_TESTED",security_scan="NOT_TESTED",artifact_adoption="HOLD"))
    save("LICENSE_NOTICE_INVENTORY.json",dict(
      jars={name:data["license_notice_members"] for name,data in jars.items()},
      lenses_outer_archive=plugin["outer_license_notice_members"],
      poms={name:data["pom_license_declarations"] for name,data in models.items()},
      redistribution_eligibility_of_third_party_originals="NOT_ESTABLISHED"))
    save("ACTUAL_TEST_RESULTS.json",dict(controls=guards,raw_originals_rehashed=len(receipts),
         checksum_tests=checks,jar_or_assembly_crc_checks=len(jars),outer_plugin_crc="PASS",
         java_headers_measured=len(jars),maven_models_projected=len(models),
         runtime_activation="NOT_TESTED",execution_authorized=False))
    print(f"{len(receipts)} original identities, {len(checks)} checksum matches, {len(jars)} JAR archives, {len(guards)} guard controls")


if __name__=="__main__":
    main()
