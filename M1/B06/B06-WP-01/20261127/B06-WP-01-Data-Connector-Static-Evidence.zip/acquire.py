"""Bounded public acquisition of exact B06 coordinates. No Maven or Java execution."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
from urllib.parse import urlparse
import json
import re
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET

ROOT = "https://repo.maven.apache.org/maven2"
LA = "https://github.com/lensesio/stream-reactor/releases/download/11.7.3/kafka-connect-aws-s3-11.7.3.zip"
A_SHA = "a1ac8438643189b8e44a778879a9ff918e974feec811dfac29d6af8d1a4f1933"
A_SIZE = 118643663
RAW = Path("originals")
TOP = {
    "B": [("org.apache.flink", "flink-connector-kafka", v) for v in ("3.3.0-1.20", "3.4.0-1.20")],
    "C": [("software.amazon.glue", a, v) for v in ("1.1.27", "2.0.2") for a in
          ("schema-registry-serde", "schema-registry-flink-serde", "schema-registry-kafkaconnect-converter")],
    "D": [("org.apache.kafka", "kafka-clients", "3.9.2"),
          ("software.amazon.msk", "aws-msk-iam-auth", "2.4.0")],
}


def identity(data):
    return sha256(data).hexdigest()


def key(coordinates, suffix):
    return ".".join(coordinates) + "." + suffix


def maven_url(coords, suffix):
    group, artifact, version = coords
    if not all(re.fullmatch(r"[A-Za-z0-9_.-]+", x) and x not in (".", "..") for x in coords):
        raise ValueError("Unsafe Maven coordinate")
    return f"{ROOT}/{group.replace('.', '/')}/{artifact}/{version}/{artifact}-{version}.{suffix}"


def save(name, value):
    Path(name).write_text(json.dumps(value, sort_keys=True, indent=2) + "\n")


def fetch(task):
    name, url, limit = task
    origin = urlparse(url)
    if origin.scheme != "https" or origin.hostname not in ("repo.maven.apache.org", "github.com", "central.sonatype.com"):
        raise ValueError("Feed outside authorized allowlist")
    at = datetime.now(timezone.utc).isoformat()
    target = RAW / name
    if target.exists():
        raise ValueError("Refusing to overwrite retained bytes: " + name)
    with tempfile.TemporaryDirectory(dir=RAW) as work:
        temporary = Path(work) / "body"
        headers = Path(work) / "headers"
        args = ["curl", "-q", "--silent", "--show-error", "--proto", "=https", "--proto-redir", "=https",
                "--location", "--max-redirs", "3", "--connect-timeout", "8", "--max-time", "55",
                "--max-filesize", str(limit), "--dump-header", str(headers),
                "--output", str(temporary), "--write-out", "%{http_code} %{http_connect}", url]
        proc = subprocess.run(args, capture_output=True, timeout=60, check=False)
        text = proc.stdout.decode("ascii", errors="replace").split()
        status, connect = (list(map(int, text)) if len(text)==2 and all(x.isdigit() for x in text) else (0,0))
        row = dict(name=name, url=url, observed_at_utc=at, http_status=status, proxy_connect=connect,
                   exit_code=proc.returncode)
        if headers.exists():
            safe = headers.read_text(errors="replace").split("\n\n")[-2:]
            for header in ("last-modified", "content-type", "retry-after"):
                matches = re.findall(r"(?im)^" + header + r": ([^\r\n]+)", "\n".join(safe))
                if matches:
                    row[header] = matches[-1]
        if status != 200 or proc.returncode != 0 or not temporary.exists():
            return {**row, "status": "NOT_ACQUIRED"}
        data = temporary.read_bytes()
        if not data or len(data) > limit:
            return {**row, "status": "SIZE_LIMIT_OR_EMPTY"}
        temporary.replace(target)
        return {**row, "path": str(target), "status": "ACQUIRED", "size_bytes": len(data),
                "sha256": identity(data)}


def batch(tasks):
    with ThreadPoolExecutor(max_workers=5) as pool:
        return list(pool.map(fetch, tasks))


def xml(data):
    if re.search(rb"<!\s*(DOCTYPE|ENTITY)", data, re.I):
        raise ValueError("DTD/entity prohibited")
    root = ET.fromstring(data)
    for el in root.iter():
        el.tag = el.tag.rsplit("}", 1)[-1]
    return root


def control_model(root):
    props = {e.tag: e.text for e in root.findall("properties/*")}
    candidates = []
    parent = root.find("parent")
    if parent is not None:
        candidates.append(tuple(parent.findtext(k, "") for k in ("groupId", "artifactId", "version")))
    for dep in root.findall("dependencyManagement/dependencies/dependency"):
        if dep.findtext("scope") == "import" and dep.findtext("type") == "pom":
            versions = [dep.findtext(k, "") for k in ("groupId","artifactId","version")]
            candidates.append(tuple(props.get(v[2:-1], v) if v.startswith("${") and v.endswith("}") else v
                                    for v in versions))
    return candidates


def requested_top():
    tasks = [("lenses-s3-11.7.3.zip", LA, 125000000)]
    for coords in sum(TOP.values(), []):
        for suffix, limit in (("pom", 1048576), ("jar", 65000000)):
            tasks.append((key(coords,suffix), maven_url(coords,suffix), limit))
    return tasks


def main():
    RAW.mkdir(exist_ok=True)
    round_name = sys.argv[1]
    if round_name == "top":
        tasks = requested_top()
    elif round_name == "controls":
        # Fixed parents or imported BOMs from inspected POMs only, no ordinary transitive artifacts.
        coords = [tuple(line.split(":")) for line in Path("control-coordinates.txt").read_text().splitlines() if line]
        tasks = [(key(c,"pom"), maven_url(c,"pom"), 1048576) for c in coords if not (RAW/key(c,"pom")).exists()]
    elif round_name == "checksum":
        top = json.loads(Path("acquisition-top.json").read_bytes())
        controls = [row for p in sorted(Path(".").glob("acquisition-controls*.json"))
                    for row in json.loads(p.read_bytes())]
        targets = {row["name"]: row for row in top+controls+json.loads(Path("acquisition-bounded-recovery.json").read_bytes()) if row.get("path")
                   and row["url"].startswith(ROOT + "/")}
        tasks = [(name+".sha1", row["url"]+".sha1", 1024) for name,row in sorted(targets.items())]
    else:
        raise ValueError("Unknown acquisition round")
    save("acquisition-"+round_name+".json",batch(tasks))


if __name__ == "__main__":
    main()
