"""Safe static archive and JVM class-header inspection. No classes are loaded."""
from collections import Counter
from hashlib import sha256
from io import BytesIO
from pathlib import PurePosixPath
from struct import unpack_from
from zipfile import ZipFile
import re
import stat

GLUE = "com/amazonaws/services/schemaregistry/"
MR = re.compile(r"^META-INF/versions/([0-9]+)/(.+\.class)$")
HEX = lambda data: sha256(data).hexdigest()


def require(ok, reason):
    if not ok:
        raise ValueError(reason)


def safe_members(archive):
    names = set()
    total = 0
    for entry in archive.infolist():
        name = entry.filename
        path = PurePosixPath(name.rstrip("/"))
        require(name not in names and path.parts and str(path) == name.rstrip("/")
                and not path.is_absolute() and ".." not in path.parts
                and not re.search(r"[\\\x00-\x1f]", name), "UNSAFE_OR_DUPLICATE_ZIP_MEMBER")
        require(not stat.S_ISLNK(entry.external_attr >> 16) and not entry.flag_bits & 1,
                "ZIP_LINK_OR_ENCRYPTED")
        total += entry.file_size
        require(total <= 900_000_000 and entry.file_size <= 220_000_000, "ZIP_SIZE_LIMIT")
        names.add(name)
    require(len({n.rstrip("/") for n in names}) == len(names), "ZIP_FILE_DIRECTORY_COLLISION")
    return names


def manifest(data):
    values = {}
    current = None
    for line in data.decode("utf-8", errors="replace").splitlines():
        if not line:
            break
        if line.startswith(" ") and current:
            values[current] += line[1:]
        elif ": " in line:
            key, value = line.split(": ", 1)
            current = key.casefold()
            require(current not in values,"MANIFEST_DUPLICATE_HEADER")
            values[current] = value
    return values


def versioned_name(name):
    match = MR.fullmatch(name)
    if match:
        return int(match[1]), match[2]
    return (0, name) if not name.startswith("META-INF/") else (-1, name)


def choice(rows, level, multirelease):
    used = {}
    for version,path,major in rows:
        if version == 0 or (multirelease and 9 <= version <= level):
            if path not in used or used[path][0] < version:
                used[path] = (version,major)
    return used


def api_signatures(data):
    """Read symbolic descriptors for public/protected Glue members and direct super types."""
    position = 8
    def unpack(fmt):
        nonlocal position
        got = unpack_from(">"+fmt,data,position)
        position += sum({"B":1,"H":2,"I":4}[c] for c in fmt)
        return got[0] if len(got)==1 else got
    count = unpack("H")
    pool = [None]*count
    i = 1
    while i < count:
        tag = unpack("B")
        if tag == 1:
            length = unpack("H")
            require(position+length <= len(data),"CLASS_UTF8_OUT_OF_RANGE")
            pool[i] = data[position:position+length].decode("utf-8",errors="replace")
            position += length
        elif tag == 7:
            pool[i] = unpack("H")
        elif tag in (4,3,9,10,11,12,17,18):
            position += 4
        elif tag in (5,6):
            position += 8
            i += 1
        elif tag in (8,16,19,20):
            position += 2
        elif tag == 15:
            position += 3
        else:
            raise ValueError("UNKNOWN_CLASS_CONSTANT_TAG")
        i += 1
    access, this, superclass = unpack("HHH")
    interfaces = [pool[pool[unpack("H")]] for _ in range(unpack("H"))]
    klass = pool[pool[this]]
    if not access & 0x0005:
        return []
    sig = [f"type {klass} {'public' if access & 1 else 'protected'} "
           f"{'final' if access & 16 else 'non-final'} {'abstract' if access & 1024 else 'concrete'} "
           f"extends {pool[pool[superclass]] if superclass else '-'} "
           f"implements {','.join(sorted(interfaces))}"]
    for kind in ("field","method"):
        for _ in range(unpack("H")):
            flags,name,descriptor,attributes = unpack("HHHH")
            if flags & 0x0005:
                sig.append(f"{kind} {klass} {'public' if flags & 1 else 'protected'} "
                           f"{'static' if flags & 8 else 'instance'} {pool[name]} {pool[descriptor]}")
            for _ in range(attributes):
                _, length = unpack("HI")
                position += length
                require(position <= len(data),"CLASS_ATTRIBUTE_OUT_OF_RANGE")
    return sig


def inspect_jar(source, glue_api=False, kafka_reference=None):
    with ZipFile(source) as z:
        members = safe_members(z)
        require(z.testzip() is None,"ZIP_CRC")
        mf = manifest(z.read("META-INF/MANIFEST.MF")) if "META-INF/MANIFEST.MF" in members else {}
        multirelease = mf.get("multi-release","").lower()=="true"
        rows, api, embedded, kafka_hashes = [], set(), [], {}
        roots = Counter()
        for name in sorted(members):
            if name.endswith(".class"):
                with z.open(name) as stream:
                    header = stream.read(8)
                require(len(header)==8 and header[:4]==b"\xca\xfe\xba\xbe","CLASS_MAGIC_OR_SIZE")
                minor, major = unpack_from(">HH",header,4)
                version,rel = versioned_name(name)
                rows.append((version,rel,major))
                prefix = "/".join(rel.split("/")[:4])
                roots[prefix]+=1
                if version == 0 and rel.startswith("org/apache/kafka/") and not rel.startswith("org/apache/kafka/connect/"):
                    kafka_hashes[rel]=HEX(z.read(name))
                if glue_api and version == 0 and rel.startswith(GLUE):
                    api.update(api_signatures(z.read(name)))
            if name.endswith("/pom.properties") and name.startswith("META-INF/maven/"):
                properties={}
                for line in z.read(name).decode(errors="replace").splitlines():
                    field, sep, value = line.partition("=")
                    if sep and field.strip() in ("groupId","artifactId","version"):
                        properties[field.strip()]=value.strip()
                embedded.append({"path":name,**properties})
        selection = {}
        selected_names = {}
        for level in (11,17):
            used=choice(rows,level,multirelease)
            max_class=44+level
            high=[{"path":n,"major":m,"entry_java":v} for n,(v,m) in used.items()
                  if m>max_class and not n.endswith("module-info.class")]
            selection[str(level)]={
                "selected_class_count":len(used),"max_selected_normal_major":max((m for n,(v,m) in used.items()
                                                                                if not n.endswith("module-info.class")),default=None),
                "normal_classes_over_platform_limit":len(high),"examples":sorted(high,key=lambda x:x["path"])[:12],
                "normal_bytecode_result":"FAIL_MAJOR" if high else "PASS_HEADER_ONLY",
                "newer_mr_entries_not_selected":sum(version>level for version,_,_ in rows),
                "module_descriptors":sum(n.endswith("module-info.class") for n in used),
            }
            selected_names[level]={name for name in used if not name.endswith("module-info.class")}
        legal=sorted(n for n in members if not n.endswith("/") and PurePosixPath(n).name.lower().startswith(
              ("license","licence","notice","copying","third-party","third_party")))
        overlaps={}
        if kafka_reference is not None:
            common=kafka_hashes.keys() & kafka_reference.keys()
            overlaps=dict(shared_class_names=len(common),
                          byte_identical=sum(kafka_hashes[n]==kafka_reference[n] for n in common),
                          candidate_only_names=len(kafka_hashes.keys()-kafka_reference.keys()),
                          reference_only_names=len(kafka_reference.keys()-kafka_hashes.keys()),
                          scope="BASE_NON_CONNECT_KAFKA_CLASSES_ONLY; NO_WHOLE_ARTIFACT_IDENTITY_INFERENCE")
        return {
            "class_count":len(rows),"package_prefix_counts":dict(roots),
            "multi_release":multirelease,"manifest_flags":{k:mf[k] for k in ("multi-release","implementation-version","automatic-module-name","specification-version","kafka-version","streamreactor-version","git-commit-hash") if k in mf},
            "physical_major_counts":dict(Counter(m for _,_,m in rows)),
            "versioned_major_counts":{str(v):dict(Counter(m for ver,_,m in rows if ver==v)) for v in sorted({v for v,_,_ in rows if v>0})},
            "java_selection":selection,"embedded_maven_properties":embedded,
            "embedded_pom_paths":sorted(n for n in members if n.endswith("/pom.xml") and n.startswith("META-INF/maven/")),
            "license_notice_members":[{"path":n,"sha256":HEX(z.read(n)),"size_bytes":z.getinfo(n).file_size} for n in legal],
            "archive_safety_crc":"PASS",
            "base_connect_api_class_count":sum(v==0 and n.startswith("org/apache/kafka/connect/") for v,n,_ in rows),
            "iam_login_module_members":sorted(n for n in members if n.endswith("/IAMLoginModule.class")),
            "glue_converter_members":sorted(n for n in members if n.endswith("/AWSKafkaAvroConverter.class")),
            "nested_jar_members":sorted(n for n in members if n.endswith(".jar")),
            "base_non_connect_kafka_class_count":len(kafka_hashes),"base_kafka_class_overlap_vs_3_9_2":overlaps,
        }, selected_names, api, kafka_hashes
