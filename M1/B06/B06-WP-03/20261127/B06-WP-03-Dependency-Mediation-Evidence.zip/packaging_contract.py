"""Static fixture contract for future packaging without creating a JAR."""
from collections import Counter

KAFKA = "org.apache.kafka:kafka-clients"
CONNECT_CONVERTER = "software.amazon.glue:schema-registry-kafkaconnect-converter"
PROVIDED = {
    "org.apache.flink:flink-streaming-java", "org.apache.flink:flink-annotations",
    "org.apache.flink:flink-connector-datagen", "org.apache.flink:flink-core",
    "org.apache.flink:flink-core-api", "org.apache.flink:flink-metrics-core",
    "org.apache.flink:flink-runtime", "org.apache.flink:flink-connector-base",
    "org.apache.flink:flink-table-api-java-bridge", "org.apache.flink:flink-table-api-java",
    "org.apache.flink:flink-table-common", "org.slf4j:slf4j-api", "com.google.code.findbugs:jsr305",
}


def result(outcome, reason):
    return {"outcome":outcome,"reason":reason}


def affected(value):
    if not isinstance(value,str) or not value or not all(v.isascii() and v.isdigit() for v in value.split(".")):
        return False
    v=tuple(map(int,value.split(".")))
    return ((2,8,0)<=v<(3,9,2)) or ((4,0,0)<=v<(4,0,2)) or ((4,1,0)<=v<(4,1,2))


def check_packaging(fixture):
    if fixture.get("effective_classpath_known") is not True:
        return result("BLOCKED","EFFECTIVE_CLASSPATH_UNKNOWN")
    entries=fixture["entries"]
    if any(e["coordinate"]==CONNECT_CONVERTER or any(
        c.startswith("com/amazonaws/services/schemaregistry/kafkaconnect/") for c in e["classes"]) for e in entries):
        return result("REJECT","CONNECT_CONVERTER_FORBIDDEN")
    if any(e["coordinate"] in PROVIDED and e["placement"]=="application" for e in entries):
        return result("REJECT","RUNTIME_PROVIDED_BUNDLED")
    clients=[e for e in entries if e["coordinate"]==KAFKA]
    if any(affected(e["version"]) for e in clients):
        return result("REJECT","AFFECTED_KAFKA_VERSION")
    if any(type(c["major"]) is not int or c["major"]>61 or c.get("minor")==65535
           for e in entries for c in e["classes"].values()):
        return result("REJECT","JAVA17_HEADER")
    classes=Counter(c for e in entries for c in e["classes"] if c.startswith("org/apache/kafka/"))
    if any(count>1 for count in classes.values()):
        return result("REJECT","DUPLICATE_KAFKA_CLASS")
    if not clients or any(e["version"]!="3.9.2" or e["placement"]!="application" for e in clients):
        return result("BLOCKED","KAFKA_ARTIFACT_IDENTITY_OPEN")
    if any(c not in classes for c in fixture["required_kafka_classes"]):
        return result("REJECT","MISSING_KAFKA_CLASS")
    return result("ACCEPT","SYNTHETIC_STATIC_CONTRACT_ONLY")
