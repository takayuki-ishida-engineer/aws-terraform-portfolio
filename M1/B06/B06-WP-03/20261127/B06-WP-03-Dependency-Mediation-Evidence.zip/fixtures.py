"""Small original fixtures for the fixed test manifest."""
from copy import deepcopy

from abi_mediation import PUB, STATIC, Symbol, Type, resolve
from packaging_contract import CONNECT_CONVERTER, KAFKA, check_packaging

CLASS="org/apache/kafka/fixture/Client"
CHILD="org/apache/kafka/fixture/ChildClient"
T=("method","call","()V")
BASE={"effective_classpath_known":True,
      "entries":[{"coordinate":KAFKA,"version":"3.9.2","placement":"application","classes":{CLASS:{"major":52,"minor":0}}}],
      "required_kafka_classes":[CLASS]}


def packaging(case):
    f=deepcopy(BASE)
    item=f["entries"][0]
    version={"NEG-390":"3.9.0","NEG-361":"3.6.1","NEG-340":"3.4.0"}.get(case)
    if version:
        # Leaked version beside the desired client, possibly from a parent.
        f["entries"].append({**item,"version":version,"placement":"runtime"})
    elif case=="NEG-MISSING-CLASS":
        item["classes"]={}
    elif case=="NEG-DUPLICATE":
        f["entries"].append({**item,"coordinate":"fixture:shaded-copy"})
    elif case=="NEG-JAVA17":
        item["classes"][CLASS]["major"]=65
    elif case=="NEG-PROVIDED":
        f["entries"].append({"coordinate":"org.apache.flink:flink-core","version":"2.2.1",
                              "placement":"application","classes":{}})
    elif case=="NEG-CONVERTER":
        f["entries"].append({"coordinate":CONNECT_CONVERTER,"version":"2.0.2","placement":"application","classes":{}})
    elif case=="NEG-UNKNOWN":
        f["effective_classpath_known"]=False
    elif case!="POS-PACKAGING":
        raise ValueError("Unknown packaging fixture")
    return check_packaging(f)


def abi(case):
    api={CLASS:Type(CLASS,PUB,["java/lang/Object"],{T:PUB}),
         CHILD:Type(CHILD,PUB,[CLASS],{})}
    static=False
    owner=CLASS
    if case=="NEG-WRONG-DESCRIPTOR":
        api[CLASS].members={("method","call","(I)V"):PUB}
    elif case=="NEG-ACCESS":
        api[CLASS].members={T:2}
    elif case=="NEG-INVOKE-KIND":
        api[CLASS].members={T:PUB|STATIC}
    elif case=="POS-INHERITED":
        owner=CHILD
    else:
        raise ValueError("Unknown ABI fixture")
    return resolve(api,Symbol("example/Caller",owner,"method","call","()V","invokevirtual",static,10))


def run(case):
    if case in ("NEG-WRONG-DESCRIPTOR","NEG-ACCESS","NEG-INVOKE-KIND","POS-INHERITED"):
        return abi(case)
    return packaging(case)
