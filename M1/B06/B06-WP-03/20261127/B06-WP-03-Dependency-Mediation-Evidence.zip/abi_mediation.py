"""Extend the pinned WP02 parser with static access and invocation-shape checks."""
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from struct import unpack_from
import re

from api_refs import check, class_files

KAFKA = "org/apache/kafka/"
PUB, PRIVATE, PROTECTED, STATIC, INTERFACE = 1, 2, 4, 8, 0x200
TARGET_INSN = {
    0xb2:("field",True,"getstatic"), 0xb3:("field",True,"putstatic"),
    0xb4:("field",False,"getfield"), 0xb5:("field",False,"putfield"),
    0xb6:("method",False,"invokevirtual"), 0xb7:("method",False,"invokespecial"),
    0xb8:("method",True,"invokestatic"), 0xb9:("method",False,"invokeinterface"),
}
HANDLE_IDS = {1:0xb4,2:0xb2,3:0xb5,4:0xb3,5:0xb6,6:0xb8,7:0xb7,8:0xb7,9:0xb9}


def u(raw, pos, fmt):
    data = unpack_from(">"+fmt, raw, pos)
    return data[0] if len(data)==1 else data


def code_parts(cf):
    """Read Code attributes using the WP02 parser's verified constant-pool shape."""
    raw=cf.data
    pos=10
    for item in cf.pool:
        if item is None:
            continue
        tag,value=item
        check(raw[pos]==tag,"CONSTANT_POOL_POSITION")
        pos+=1
        if tag==1:
            pos+=2+u(raw,pos,"H")
        else:
            pos+={3:4,4:4,5:8,6:8,7:2,8:2,9:4,10:4,11:4,12:4,15:3,16:2,
                  17:4,18:4,19:2,20:2}[tag]
    pos+=6
    pos+=2+2*u(raw,pos,"H")
    for methods in (False,True):
        count=u(raw,pos,"H")
        pos+=2
        for _ in range(count):
            _,name,desc,n=u(raw,pos,"HHHH")
            pos+=8
            for _ in range(n):
                tag,size=u(raw,pos,"HI")
                pos+=6
                check(pos+size<=len(raw),"ATTRIBUTE_BOUNDARY")
                if methods and cf.utf(tag)=="Code":
                    length=u(raw,pos+4,"I")
                    check(size>=8 and 8+length<=size,"CODE_BOUNDARY")
                    yield cf.utf(name),cf.utf(desc),raw[pos+8:pos+8+length]
                pos+=size


TWO={0x10,0x12,0xa9,0xbc,*range(0x15,0x1a),*range(0x36,0x3b)}
THREE={0x11,0x13,0x14,0x84,0xbb,0xbd,0xc0,0xc1,0xc6,0xc7,
       *range(0x99,0xa9),*range(0xb2,0xb9)}
FIVE={0xb9,0xba,0xc8,0xc9}


def instructions(code):
    pos=0
    while pos<len(code):
        op=code[pos]
        if op in TWO: length=2
        elif op in THREE: length=3
        elif op==0xc5: length=4
        elif op in FIVE: length=5
        elif op==0xc4:
            check(pos+1<len(code),"WIDE_TRUNCATED")
            length=6 if code[pos+1]==0x84 else 4
        elif op in (0xaa,0xab):
            aligned=(pos+4)&~3
            if op==0xaa:
                low,high=u(code,aligned+4,"ii")
                entries=high-low+1
                check(0<=entries<=len(code)//4,"TABLESWITCH_BOUNDS")
                length=aligned-pos+12+4*entries
            else:
                entries=u(code,aligned+4,"i")
                check(0<=entries<=len(code)//8,"LOOKUPSWITCH_BOUNDS")
                length=aligned-pos+8+8*entries
        else:
            check(op<=0xc9,"INVALID_OPCODE")
            length=1
        check(pos+length<=len(code),"TRUNCATED_INSTRUCTION")
        yield pos,op
        pos+=length


@dataclass(frozen=True)
class Symbol:
    caller: str
    owner: str
    kind: str
    member: str
    descriptor: str
    opcode: str
    is_static: bool | None
    cp_tag: int


def compile_references(jar, prefix):
    classes=defaultdict(set)
    refs=defaultdict(set)
    dynamics=Counter()
    count=0
    callers={}
    for cf in class_files(jar,prefix):
        count+=1
        callers[cf.name]=cf
        sites=defaultdict(list)
        for method,descriptor,code in code_parts(cf):
            for pos,op in instructions(code):
                if op in TARGET_INSN:
                    sites[u(code,pos+1,"H")].append((op,method+descriptor))
                elif op==0xba:
                    dynamics["invokedynamic_instructions"]+=1
        for item in cf.pool:
            if item is None: continue
            tag,value=item
            if tag==15:
                kind,index=value
                check(kind in HANDLE_IDS,"METHOD_HANDLE_KIND")
                sites[index].append((HANDLE_IDS[kind],"CONSTANT_METHOD_HANDLE"))
                dynamics["method_handles"]+=1
            if tag==17:
                dynamics["dynamic_constants"]+=1
        for index,item in enumerate(cf.pool):
            if item is None: continue
            tag,value=item
            if tag==7:
                name=cf.utf(value)
                for name in ([name] if name.startswith(KAFKA) else re.findall(r"L("+KAFKA+r"[^;]+);",name)):
                    classes[name].add(cf.name)
            if tag not in (9,10,11): continue
            owner=cf.class_name(value[0])
            pair,n=cf.pool[value[1]]
            check(pair==12,"BAD_DESCRIPTOR_REFERENCE")
            member,descriptor=(cf.utf(part) for part in n)
            for name in re.findall(r"L("+KAFKA+r"[^;]+);",descriptor):
                classes[name].add(cf.name)
            if not owner.startswith(KAFKA): continue
            classes[owner].add(cf.name)
            for op,site in sites.get(index,[(None,"CONSTANT_POOL_ONLY")]):
                kind,static,opcode=(TARGET_INSN[op] if op is not None else
                    ("field" if tag==9 else "method",None,"NOT_OBSERVED"))
                check(kind==("field" if tag==9 else "method"),"REFERENCE_KIND")
                refs[Symbol(cf.name,owner,kind,member,descriptor,opcode,static,tag)].add(site)
        for _,_,descriptor in cf.members:
            for name in re.findall(r"L("+KAFKA+r"[^;]+);",descriptor):
                classes[name].add(cf.name)
    return classes,refs,callers,count,dynamics


@dataclass
class Type:
    name: str
    flags: int
    parents: list
    members: dict


JAVA = {
    # Exact public Java SE 17 contract. No java.* classes are loaded.
    "java/lang/Iterable":Type("java/lang/Iterable",PUB|INTERFACE,[],{
        ("method","iterator","()Ljava/util/Iterator;"):PUB|0x400}),
    "java/lang/Object":Type("java/lang/Object",PUB,[],{("method",n,d):PUB for n,d in
        (("toString","()Ljava/lang/String;"),("hashCode","()I"),("equals","(Ljava/lang/Object;)Z"),
         ("getClass","()Ljava/lang/Class;"))}),
    "java/lang/Enum":Type("java/lang/Enum",PUB,["java/lang/Object"],{("method",n,d):PUB for n,d in
        (("name","()Ljava/lang/String;"),("ordinal","()I"),("toString","()Ljava/lang/String;"))}),
}


def lookup_graph(api, owner, key, kind):
    graph={**JAVA,**api}
    visited=set()
    external=set()
    candidates=[]
    def visit(name,priority):
        if name in visited: return
        visited.add(name)
        node=graph.get(name)
        if node is None:
            external.add(name)
            return
        if key in node.members:
            flags=node.members[key]
            # Static/private interface methods are not inherited.
            if name==owner or not (node.flags&INTERFACE and flags&(STATIC|PRIVATE)):
                candidates.append((priority,name,flags))
                return
        if key[1] in ("<init>","<clinit>"): return
        for parent in node.parents:
            # Methods search the known class/superclass chain before interfaces.
            p=graph.get(parent)
            rank=(1 if p is None or p.flags&INTERFACE else priority) if kind=="method" else 0
            visit(parent,rank)
    visit(owner,0)
    if not candidates: return None,external,False
    best=min(c[0] for c in candidates)
    choices=[c for c in candidates if c[0]==best]
    # An interface diamond sharing one owner is already deduplicated; unresolved
    # unrelated declarations are conservatively held.
    return (choices[0] if len(choices)==1 else None),external,len(choices)>1


def access(flags, owner, caller):
    if flags&PUB: return "PUBLIC"
    if flags&PRIVATE: return "PRIVATE" if owner!=caller else "SAME_CLASS_PRIVATE"
    if owner.rpartition("/")[0]==caller.rpartition("/")[0]:
        return "PACKAGE_CLASSLOADER_UNPROVEN"
    if flags&PROTECTED:
        return "PROTECTED_RECEIVER_OR_SUBCLASS_UNPROVEN"
    return "PACKAGE_ACCESS_DENIED"


def resolve(api, sym):
    node=api.get(sym.owner)
    if node is None:
        return {"outcome":"REJECT","reason":"MISSING_KAFKA_CLASS"}
    if access(node.flags,sym.owner,sym.caller)!="PUBLIC":
        return {"outcome":"BLOCKED" if sym.owner.rpartition("/")[0]==sym.caller.rpartition("/")[0] else "REJECT",
                "reason":"CLASS_ACCESS_UNPROVEN_OR_DENIED"}
    if sym.kind=="method" and (bool(node.flags&INTERFACE)!=(sym.cp_tag==11)
                               or (sym.opcode=="invokeinterface" and sym.cp_tag!=11)
                               or (sym.opcode=="invokevirtual" and sym.cp_tag!=10)):
        return {"outcome":"REJECT","reason":"CLASS_INTERFACE_REFERENCE_MISMATCH"}
    found,external,ambiguous=lookup_graph(api,sym.owner,(sym.kind,sym.member,sym.descriptor),sym.kind)
    if found is None:
        if ambiguous or external:
            return {"outcome":"BLOCKED","reason":"HIERARCHY_RESOLUTION_OPEN","external":sorted(external)}
        return {"outcome":"REJECT","reason":"MISSING_METHOD_DESCRIPTOR" if sym.kind=="method" else "MISSING_FIELD_DESCRIPTOR"}
    _,owner,flags=found
    details={"declared_owner":owner,"access_flags_hex":f"0x{flags:04x}",
             "inherited":owner!=sym.owner,"built_in_java_api":owner in JAVA}
    member_access=access(flags,owner,sym.caller)
    if member_access not in ("PUBLIC","SAME_CLASS_PRIVATE"):
        return {**details,"outcome":"BLOCKED" if "UNPROVEN" in member_access else "REJECT",
                "reason":"MEMBER_NOT_ADMITTED","access_check":member_access}
    if sym.is_static is not None and bool(flags&STATIC)!=sym.is_static:
        return {**details,"outcome":"REJECT","reason":"STATIC_INSTANCE_MISMATCH"}
    if sym.is_static is None:
        return {**details,"outcome":"BLOCKED","reason":"INVOCATION_KIND_UNOBSERVED"}
    return {**details,"outcome":"ACCEPT","reason":"SYMBOL_RESOLVED"}


def compare_artifact(jar, prefix, api):
    classes,refs,_callers,count,dynamics=compile_references(jar,prefix)
    rows=[]
    for sym,sites in sorted(refs.items(),key=lambda x:tuple(str(v) for v in vars(x[0]).values())):
        rows.append({**vars(sym),"sample_sites":sorted(sites)[:4],"site_count":len(sites),**resolve(api,sym)})
    class_rows=[]
    for name,calls in sorted(classes.items()):
        target=api.get(name)
        if target is None: outcome="MISSING"
        elif target.flags&PUB: outcome="PUBLIC"
        else: outcome="CLASS_ACCESS_UNPROVEN_OR_DENIED"
        class_rows.append({"class":name,"callers":len(calls),"sample_callers":sorted(calls)[:4],"outcome":outcome})
    status="STATIC_SYMBOLS_RESOLVED" if all(x["outcome"]=="ACCEPT" for x in rows) and all(
        x["outcome"]=="PUBLIC" for x in class_rows) else "PARTIAL_OR_INCOMPATIBLE"
    return {"artifact":Path(jar).name,"application_classes_examined":count,"kafka_classes":class_rows,
            "references":rows,"class_counts":dict(Counter(x["outcome"] for x in class_rows)),
            "member_counts":dict(Counter(x["outcome"] for x in rows)),
            "unresolved_reasons":dict(Counter(x["reason"] for x in rows if x["outcome"]!="ACCEPT")),
            "dynamic_inventory":dict(dynamics),"static_result":status}
