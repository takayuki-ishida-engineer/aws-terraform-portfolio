"""WP03 offline candidate verifier. It performs no artifact acquisition or tool execution."""
from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
from collections import Counter
import json
import re
import sys
import xml.etree.ElementTree as ET

from abi_mediation import KAFKA as KAFKA_PREFIX, check, class_files, compare_artifact
from fixtures import run
from packaging_contract import KAFKA, PROVIDED, affected

BASE_ZIPS = {
 "wp01.zip":("2c3661d3183caa4fd20ca2b11dd4021f2047a3a6","4d5f50ab59961dd03f6d13b27141532872e99dcf368ca787f8e5b2ba156de60e",
    "M1/B06/B06-WP-01/20261127/B06-WP-01-Data-Connector-Static-Evidence.zip"),
 "wp02.zip":("c4d2f63c96802c136dd5dab36174d696adcd52a3","ba209116fa335def83cc26fab48b6f48a8166fdcf3a3b8017d18b7c4f03ad87c",
    "M1/B06/B06-WP-02/20261127/B06-WP-02-Runtime-Compatibility-Evidence.zip"),
}
CONNECT="org.apache.flink:flink-connector-kafka"
IAM="software.amazon.msk:aws-msk-iam-auth"
HELPER="api_refs.py"
EXPECTED_PIN="22ac9a5850681becc098a7ebac62125ece361e953c7ba61e4446355bd7d1d8d4"


def sha(data):
    return sha256(data).hexdigest()


def save(n,data):
    Path(n).write_text(json.dumps(data,sort_keys=True,indent=2)+"\n",encoding="utf-8")


def previous():
    loaded={}
    zips=[]
    for name,(commit,digest,rel) in BASE_ZIPS.items():
        data=Path(name).read_bytes()
        check(sha(data)==digest,"PRIOR_EVIDENCE_DIGEST")
        with ZipFile(name) as z:
            need_members={
              "wp01.zip":["EXACT_ARTIFACT_IDENTITY_MANIFEST.json","DEPENDENCY_INVENTORY.json",
                           "CVE_APPLICABILITY_REPORT.json","JAVA_COMPATIBILITY_MATRIX.json"],
              "wp02.zip":["NEW_ARTIFACT_IDENTITY_MANIFEST.json","DEPENDENCY_API_COMPATIBILITY_DELTA.json"],
            }
            loaded[name]={n:json.loads(z.read(n)) for n in need_members[name]}
            if name=="wp02.zip":
                helper=z.read(HELPER)
                check(helper==Path(HELPER).read_bytes(),"REUSED_HARNESS_SOURCE_DIGEST")
                loaded[name]["helper"]={"path":HELPER,"sha256":sha(helper),"size_bytes":len(helper)}
        zips.append(dict(commit=commit,relative_path=rel,sha256=digest,size_bytes=len(data),
                         url="https://raw.githubusercontent.com/takayuki-ishida-engineer/aws-terraform-portfolio/"+commit+"/"+rel))
    return loaded,zips


def verify_inputs(loaded):
    wp1=loaded["wp01.zip"]
    wp2=loaded["wp02.zip"]
    lookup={
      "wp01":{r["name"]:r for r in wp1["EXACT_ARTIFACT_IDENTITY_MANIFEST.json"]["files"]},
      "wp02":{r["name"]:r for r in wp2["NEW_ARTIFACT_IDENTITY_MANIFEST.json"]["originals"]},
    }
    needed={
     "wp01":["org.apache.kafka.kafka-clients.3.9.2.jar","software.amazon.msk.aws-msk-iam-auth.2.4.0.jar",
             "software.amazon.glue.schema-registry-serde.1.1.27.jar","software.amazon.glue.schema-registry-serde.2.0.2.jar"],
     "wp02":["org.apache.flink.flink-connector-kafka.4.0.0-2.0.jar"],
    }
    out={}
    for group,items in needed.items():
        for name in items:
            row=lookup[group][name]
            p=Path(group+"-originals")/name
            b=p.read_bytes()
            check((len(b),sha(b))==(row["size_bytes"],row["sha256"]),"REUSED_ARTIFACT_BYTES")
            out[name]={"path":str(p),"size_bytes":len(b),"sha256":sha(b),"url":row["url"],"source":group}
    return out


def candidate_model(loaded):
    raw=Path("candidate-pom.xml").read_bytes()
    check(not re.search(rb"<!\s*(DOCTYPE|ENTITY)",raw,re.I),"UNSUPPORTED_XML")
    root=ET.fromstring(raw)
    for child in root.iter():
        child.tag=child.tag.rsplit("}",1)[-1]
    check(root.find("build") is None and root.find("profiles") is None and root.find("repositories") is None
          and not root.findall(".//exclusion") and root.find("parent") is None,"POM_SCOPE")
    props={v.tag:v.text for v in root.findall("properties/*")}
    def evaluate(s):
        return props[s[2:-1]] if isinstance(s,str) and s.startswith("${") and s.endswith("}") else s
    def dep(item):
        return {"coordinates":item.findtext("groupId")+":"+item.findtext("artifactId"),
                "declared_version":item.findtext("version"),"scope":item.findtext("scope","compile")}
    management=[dep(x) for x in root.findall("dependencyManagement/dependencies/dependency")]
    check(len(management)==1 and management[0]["coordinates"]==KAFKA and
          evaluate(management[0]["declared_version"])=="3.9.2","CANDIDATE_MANAGED_VERSION")
    deps=[dep(x) for x in root.findall("dependencies/dependency")]
    check({x["coordinates"] for x in deps}==
          {CONNECT,IAM,KAFKA,"org.apache.flink:flink-streaming-java"}
          and len(deps)==4 and props["maven.compiler.release"]=="17","POM_DECLARED_SCOPE")
    declared=[]
    for d in deps:
        v=evaluate(d["declared_version"] or management[0]["declared_version"])
        placement="RUNTIME_PROVIDED_INTENT" if d["scope"]=="provided" else "APPLICATION_OWNED_INTENT"
        declared.append({**d,"projected_version":v,"classification":placement})
    required_versions={CONNECT:"4.0.0-2.0",IAM:"2.4.0",KAFKA:"3.9.2","org.apache.flink:flink-streaming-java":"2.2.1"}
    check(all(d["projected_version"]==required_versions[d["coordinates"]] for d in declared)
          and next(d for d in declared if d["coordinates"]=="org.apache.flink:flink-streaming-java")["scope"]=="provided","POM_FIXED_VERSIONS")
    wp1=loaded["wp01.zip"]["DEPENDENCY_INVENTORY.json"]["models"]
    wp2=loaded["wp02.zip"]["DEPENDENCY_API_COMPATIBILITY_DELTA.json"]
    declared_connector=[d for d in wp2["connector"]["static_direct_scope_projection"] if d.get("scope")!="test"]
    kafka_decl=next(d for d in declared_connector if d["coordinates"]==KAFKA)
    check(kafka_decl["version"]=="3.9.0","ROOT_DEPENDENCY_KAFKA")
    declared_iam=wp1[IAM+":2.4.0"]["static_direct_scope_projection"]
    old_glue={}
    for v in ("1.1.27","2.0.2"):
        m=wp1["software.amazon.glue:schema-registry-serde:"+v]
        old_glue[v]=next(d for d in m["static_direct_scope_projection"] if d["coordinates"]==KAFKA)
    check(old_glue["1.1.27"]["version"]=="3.6.1" and old_glue["2.0.2"]["version"]=="3.9.2","GLUE_PROJECTED_VERSIONS")
    cve=loaded["wp01.zip"]["CVE_APPLICABILITY_REPORT.json"]
    check(cve["advisory"]=="CVE-2026-35554" and affected("3.9.0") and affected("3.6.1") and affected("3.4.0"),"ADVISORY_BOUNDARY")
    return {
      "candidate_pom_sha256":sha(raw),"declared_application_dependencies":declared,
      "management":management,"mediated_projection":{"coordinate":KAFKA,"version":"3.9.2",
          "mechanism":"Direct dependency without inline version, application dependencyManagement also projects version 3.9.2 on ordinary Connector edge",
          "actual_maven_resolution":"NOT_TESTED","effective_managed_classpath":"UNKNOWN"},
      "runtime_candidates":{"primary":"Flink 2.2.1 / Java17","secondary":"Flink 2.3.0 / Java17 with separately reviewed provided API properties; projection only"},
      "connector_declared_non_test_edges":declared_connector,
      "iam_declared_edges":declared_iam,
      "glue_optional_core_edges":old_glue,
      "glue_status":"COMPARISON_ONLY_NOT_IN_CANDIDATE_POM; no Connect Converter or Flink adapter selected",
      "residue_paths":{
       "3.9.0":"Original connector declaration; Maven model may select 3.9.2 for a normal edge, but an upstream bundled/plugin/runtime copy could escape application mediation.",
       "3.6.1":"Glue 1.1.27 Core SerDe declared edge if separately chosen; an assembly/isolated classloader may retain it.",
       "3.4.0":"Absent from the v2 connector declaration; possible old v1.20 artifacts/runtime state or mispackaged legacy dependency. No observed residue.",
      },
      "closure_remaining":["Obtain exact Maven effective dependency graph, including provided scopes, extensions, runtime graph and mediation",
                           "Resolve codec/compression and AWS SDK/Jackson/credentials linkage for runtime",
                           "Inspect actual packaged JAR class and license inventory",
                           "Observe AWS managed parent classloader Kafka identity and origin under separately authorized runtime gate"],
      "advisory":cve["url"],"adoption":"HOLD",
    }


def main(output):
    expected=Path("EXPECTED_RESULT_MANIFEST.json").read_bytes()
    check(sha(expected)==EXPECTED_PIN,"EXPECTED_MANIFEST_CHANGED")
    loaded,zips=previous()
    resolved=verify_inputs(loaded)
    api={c.name:c for c in class_files("wp01-originals/org.apache.kafka.kafka-clients.3.9.2.jar",KAFKA_PREFIX)}
    callers={
      "connector":("org.apache.flink.flink-connector-kafka.4.0.0-2.0.jar","org/apache/flink/"),
      "iam_auth":("software.amazon.msk.aws-msk-iam-auth.2.4.0.jar","software/amazon/msk/"),
      "glue_core_1_1_27_optional":("software.amazon.glue.schema-registry-serde.1.1.27.jar","com/amazonaws/services/schemaregistry/"),
      "glue_core_2_0_2_optional":("software.amazon.glue.schema-registry-serde.2.0.2.jar","com/amazonaws/services/schemaregistry/"),
    }
    abi={role:compare_artifact(resolved[name]["path"],prefix,api) for role,(name,prefix) in callers.items()}
    fixtures=[]
    for case in json.loads(expected)["cases"]:
        r=run(case["id"])
        fixtures.append({"id":case["id"],"expected":{"outcome":case["outcome"],"reason":case["reason"]},
                         "actual":r,"pass":(r["outcome"],r["reason"])==(case["outcome"],case["reason"])})
    check(all(f["pass"] for f in fixtures),"EXPECTED_FIXTURE_MISMATCH")
    abi_summary={k:{s:v[s] for s in ("artifact","application_classes_examined","class_counts","member_counts",
                    "unresolved_reasons","dynamic_inventory","static_result")} for k,v in abi.items()}
    save("ABI_REFERENCE_INVENTORY.json",{
      "kafka_identity":resolved["org.apache.kafka.kafka-clients.3.9.2.jar"],"kafka_types_indexed":len(api),
      "java17_contracts":{
        "Iterable.iterator":"https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/lang/Iterable.html#iterator()",
        "Enum":"https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/lang/Enum.html"},
      "results":abi,
      "unverified":["Real JVM dispatch and hierarchy outside inspected Kafka artifacts","Reflection and string-derived symbols",
                    "ServiceLoader providers","Invokedynamic bootstrap behavior and dynamic linkage",
                    "Runtime loader order, access domains and actual loaded class identity",
                    "Optional Glue SerDe auth/schema/wire compatibility and shaded dependencies"],
      "scope":"Actual compiled constant-pool class/member descriptors and selected JVM opcodes/method handles. Member counts are caller/symbol/invocation-shape tuples. JDK inherited members use explicit Java SE API contracts. Static only.",
    })
    save("PROJECTED_DEPENDENCY_GRAPH.json",candidate_model(loaded))
    save("PACKAGING_CLASSLOADER_CONTRACT.json",{
      "status":"BLOCKED_EFFECTIVE_MANAGED_CLASSPATH_UNKNOWN",
      "expected_application_owned":["org.apache.flink:flink-connector-kafka:4.0.0-2.0",KAFKA+":3.9.2",IAM+":2.4.0",
                                   "Only independently resolved application runtime dependencies; no unverified bundle"],
      "runtime_provided_do_not_bundle":sorted(PROVIDED),
      "forbidden":["Glue Kafka Connect Converter, including repackaged copies of its classes",
                   "Affected Kafka versions and unknown Kafka origin","Any duplicate Kafka class identity, including identical bytes across application and runtime",
                   "Java17-ineligible ordinary classes or classes requiring preview"],
      "packaging_rejection":"Check artifact coordinates, digest, per-class binary name and Java selection after package creation and against known runtime sources. Fail closed on unknown parent identity; no classloader setting change.",
      "provenance_rule":"Future package inventory must map each class and related legal files to one owning version, scope, digest and release. An exclusion must be proven not to remove a runtime-needed library.",
      "runtime_loaded_class_evidence":"NOT_TESTED",
      "greenfield":"Required exact artifact and state-free/runtime witness before activation",
      "existing_migration":"State presence UNKNOWN; require exact operator state/serializer/snapshots, restore rehearsal and preservation. No state change or skip-restore."
    })
    save("EXISTING_EVIDENCE_REUSE_MANIFEST.json",{"wp01_wp02":zips,"verified_binary_inputs":resolved,
      "verified_helper_from_wp02":loaded["wp02.zip"]["helper"],
      "reused_prior_evidence_members":{k:sorted(n for n in v if n!="helper") for k,v in loaded.items()},
      "new_third_party_acquisitions":0,"previous_evidence_mutations":0})
    save(output,{"expected_manifest_sha256":sha(expected),"synthetic_cases":fixtures,"fixture_count":len(fixtures),
       "fixture_pass":sum(f["pass"] for f in fixtures),"kafka_types_indexed":len(api),
       "static_actual_artifact_abi_summary":abi_summary,"dependency_mediation":"STATIC_PROJECTION_ONLY",
       "exact_runtime_selection":"BLOCKED","java_and_maven_execution_count":0,"accepted_for_runtime":False})
    print(json.dumps({"fixtures":len(fixtures),"abi":abi_summary},sort_keys=True))
if __name__=="__main__":
    main(sys.argv[1])
