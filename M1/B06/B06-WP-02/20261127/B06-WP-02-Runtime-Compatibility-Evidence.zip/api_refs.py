"""Class-file symbolic reference comparison. No JVM, classes or plugins are run."""

from collections import defaultdict
from pathlib import Path
from struct import unpack_from
from zipfile import ZipFile
GLUE = "com/amazonaws/services/schemaregistry/"
LENSES = "io/lenses/"
FLINK = "org/apache/flink/"
CONNECT = "org/apache/kafka/connect/"


def check(ok,msg):
    if not ok:
        raise ValueError(msg)


class ClassFile:
    def __init__(self, data):
        check(data[:4]==b"\xca\xfe\xba\xbe","CLASS_MAGIC")
        self.data=data
        self.pos=4
        self.minor,self.major=self.take("HH")
        count=self.take("H")
        self.pool=[None]*count
        i=1
        while i<count:
            tag=self.take("B")
            if tag==1:
                n=self.take("H")
                check(self.pos+n<=len(data),"CLASS_UTF8_SIZE")
                value=data[self.pos:self.pos+n].decode("utf-8",errors="replace")
                self.pos+=n
            elif tag in (7,8,16,19,20):
                value=self.take("H")
            elif tag in (9,10,11,12,17,18):
                value=self.take("HH")
            elif tag in (3,4):
                value=self.take("I")
            elif tag in (5,6):
                value=self.take("II")
                i+=1
            elif tag==15:
                value=self.take("BH")
            else:
                raise ValueError("CLASS_UNKNOWN_POOL_KIND")
            self.pool[i]=(tag,value)
            i+=1
        self.flags,this,superclass=self.take("HHH")
        self.name=self.class_name(this)
        self.parents=([self.class_name(superclass)] if superclass else [])+[
            self.class_name(self.take("H")) for _ in range(self.take("H"))
        ]
        self.members={}
        for kind in ("field","method"):
            for _ in range(self.take("H")):
                flags,name,desc,attributes=self.take("HHHH")
                self.members[(kind,self.utf(name),self.utf(desc))]=flags
                for _ in range(attributes):
                    _,length=self.take("HI")
                    self.pos+=length
                    check(self.pos<=len(data),"CLASS_ATTRIBUTE_SIZE")

    def take(self, fmt):
        out=unpack_from(">"+fmt,self.data,self.pos)
        self.pos+=sum({"B":1,"H":2,"I":4}[c] for c in fmt)
        return out[0] if len(out)==1 else out

    def utf(self,index):
        tag,data=self.pool[index]
        check(tag==1,"EXPECTED_UTF8")
        return data

    def class_name(self,index):
        tag,data=self.pool[index]
        check(tag==7,"EXPECTED_CLASS")
        return self.utf(data)

    def references(self,target):
        classes=set()
        members=set()
        for item in self.pool:
            if item is None:
                continue
            tag,value=item
            if tag==7:
                n=self.utf(value)
                if n.startswith(target):
                    classes.add(n)
            if tag in (9,10,11):
                owner=self.class_name(value[0])
                if owner.startswith(target):
                    pair,n=self.pool[value[1]]
                    check(pair==12,"EXPECTED_MEMBER_DESCRIPTOR")
                    members.add(("field" if tag==9 else "method",owner,self.utf(n[0]),self.utf(n[1])))
        # Types may occur only in a descriptor, without a Class constant.
        for _,_,_,descriptor in members:
            for token in descriptor.replace("(",";").replace(")",";").split(";"):
                token=token.lstrip("[")
                if token.startswith("L"+target):
                    classes.add(token[1:])
        return classes,members


def class_files(source, prefix):
    with ZipFile(source) as z:
        names=[n for n in z.namelist() if n.startswith(prefix) and n.endswith(".class")]
        check(len(names)==len(set(names)),"DUPLICATE_CLASS")
        for name in names:
            info=z.getinfo(name)
            check(info.file_size<2_000_000,"CLASS_SIZE_LIMIT")
            f=ClassFile(z.read(info))
            check(f.name+".class"==name,"CLASS_NAME")
            yield f


def collect(source, own, target):
    classes,members=defaultdict(set),defaultdict(set)
    count=0
    for cf in class_files(source,own):
        count+=1
        cs,ms=cf.references(target)
        for c in cs:
            classes[c].add(cf.name)
        for m in ms:
            members[m].add(cf.name)
    return {"source_classes_examined":count,"classes":[dict(name=n,examples=sorted(cs)[:4],count=len(cs))
            for n,cs in sorted(classes.items())],
            "members":[dict(kind=k,owner=o,name=n,descriptor=d,examples=sorted(ms)[:4],count=len(ms))
                       for (k,o,n,d),ms in sorted(members.items())]}


def locate(api, owner, key, seen=None):
    if seen is None: seen=set()
    if owner in seen: return False
    seen.add(owner)
    cf=api.get(owner)
    if cf is None: return False
    access=cf.members.get(key,0)
    return bool(access & 0x0005) or (key[1] not in ("<init>","<clinit>") and
                                    any(locate(api,parent,key,seen) for parent in cf.parents))


def compare(refs, jars, target):
    api={}
    for jar in jars:
        for cf in class_files(jar,target):
            check(cf.name not in api,"DUPLICATE_API_CLASS "+cf.name)
            api[cf.name]=cf
    classes=[{**c,"status":"FOUND" if c["name"] in api else "MISSING_IN_INSPECTED_APIS"} for c in refs["classes"]]
    members=[]
    for m in refs["members"]:
        key=(m["kind"],m["name"],m["descriptor"])
        owner=api.get(m["owner"])
        if owner is None:
            status="OWNER_NOT_IN_INSPECTED_APIS"
        elif locate(api,m["owner"],key):
            status="EXACT_ACCESSIBLE_DESCRIPTOR_FOUND"
        elif (owner.flags & 0x4000 and owner.parents and owner.parents[0]=="java/lang/Enum"
              and key==("method","name","()Ljava/lang/String;")):
            # java.lang.Enum.name() is a public final Java SE 17 API.
            status="INHERITED_JDK_ENUM_CONTRACT"
        else:
            status="MISSING_DESCRIPTOR_CANDIDATE"
        members.append({**m,"status":status})
    return {"reference_scope":"Constant-pool classes and exact symbolic descriptors; no runtime invocation or reflection resolution.",
            "inspected_jars":[Path(jar).name for jar in jars],"class_results":classes,"member_results":members}
