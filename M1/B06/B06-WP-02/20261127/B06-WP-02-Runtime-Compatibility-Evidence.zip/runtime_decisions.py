"""Record the bounded design disposition from the offline results."""
from acquire import save
from evaluate import read, check, FLINK_DOC, MSK_DOC, DOC

def main():
    delta=read("DEPENDENCY_API_COMPATIBILITY_DELTA.json")
    common={
     "managed_support":"AWS global release table Supported for new and existing applications. Exact account/region deployment not exercised.",
     "region":"ca-central-1 exact managed runtime capability, entitlement, regional quotas and private connectivity OPEN. Generic redirects and Kinesis Data Streams regional listings were excluded.",
     "glue":"Both pinned Glue adapters retain Flink 1.12.2 provided. 5 classes and 4 exact descriptors present in each public Flink Avro API witness; managed linkage OPEN. Keep Core SerDe and Flink adapter separate and exclude Connect Converter from the Flink path.",
     "security":"Connector declares Kafka 3.9.0 in CVE-2026-35554 affected range. Effective resolved classpath, signature, IAM, and security scan not verified.",
     "license":"Exact Connector 4.0.0-2.0 JAR contains META-INF/LICENSE and META-INF/NOTICE. Transitive and runtime license closure OPEN.",
     "release_age":"Exact Connector 4.0.0-2.0 GAV Central index timestamp meets 14 days. Managed regional launch timestamp and final artifact lock OPEN.",
     "checkpoint_savepoint":"NOT_TESTED. AWS documents Flink 1.x Kryo v2 to Flink 2.x Kryo v5 incompatibility and collection serializer changes; require exact state inventory and restoration proof. No skip-restore or data-loss path was approved.",
     "schema_evolution":"NOT_TESTED. Preserve schema IDs, format, framing and serializer semantics.",
     "migration_impact":"Major migration across Flink 1.x / 2.x and Java 11 / 17. No code, classloader, dependency graph, API flags, deployment, or state changed.",
    }
    check(delta["aws_documentary"]["jdk_documented"]=={"1.20.5":11,"2.2.1":17,"2.3.0":17},"matrix input")
    matrix={
     "decision":"OD-B06-RUNTIME-02","exact_runtime_selection":"BLOCKED","runtime_adoption_authorized":False,
     "options":{
      "A_1_20_5_Java11":{
       "status":"BLOCKED","managed_support":common["managed_support"],"provider_enum":"FLINK-1_20; supplied confirmed source, no provider enum execution",
       "region":common["region"],
       "connector":"Existing WP01 3.3.0-1.20 and 3.4.0-1.20 retained as candidates; 3.4.0-1.20 appears in the AWS 2.2 migration comparison.",
       "iam":"Fixed IAM Auth 2.4.0 is major 61 and fails on Java11. Fixed scope retained.",
       "glue":"WP01 Flink SerDe built against Flink 1.12.2 provided; 1.20.5 linkage remains unproved.",
       "security":"WP01 both Kafka Connector candidates declare Kafka 3.4.0 in recorded affected range.",
       "license":"Existing WP01 LICENSE/NOTICE evidence retained; route closure OPEN.",
       "release_age":"WP01 indexed evidence retained; no new artifact selection.",
       "checkpoint_savepoint":"NOT_TESTED","schema_evolution":"NOT_TESTED",
       "migration_impact":"Keeps the 1.20 service line but leaves the pinned IAM JAR incompatible."
      },
      "B_2_2_1_Java17":{**common,"status":"BLOCKED","provider_enum":"FLINK-2_2; supplied confirmed source, no API use",
       "connector":"4.0.0-2.0 on AWS 2.2 column, verified published JAR/POM, no mediated client selected",
       "iam":"2.4.0 major 61 fits Java17 header limit, runtime auth/credential routing/linkage NOT_TESTED"},
      "C_2_3_0_Java17":{**common,"status":"BLOCKED","provider_enum":"FLINK-2_3; supplied confirmed source, no API use",
       "connector":"4.0.0-2.0 on AWS 2.3 column, same dependency condition as 2.2.1",
       "iam":"2.4.0 major 61 fits Java17 header limit, runtime auth/credential routing/linkage NOT_TESTED",
       "migration_impact":common["migration_impact"]+" Also requires the 2.3 application and state compatibility review documented by AWS."},
     },
     "wp02_disposition":"The Java17 header gate can be met by B/C, but both remain blocked under the current dependency, regional and managed-state evidence. No downgrade, override, new adapter, or change to the MSK Connect 3.7.x worker is authorized.",
     "sources":{"catalog":FLINK_DOC+"release-version-list.html","connector_matrix":FLINK_DOC+"how-flink-connectors.html",
                "state":FLINK_DOC+"state-compatibility.html","msk_worker":MSK_DOC+"msk-connect.html",
                "msk_auth":DOC+"MSKC/latest/mskc/API_KafkaClusterClientAuthentication.html",
                "cve":"https://github.com/advisories/GHSA-5qcv-4rpc-jp93"},
     "provided_existing_source_findings":{
      "provenance":"ChatGPT-confirmed source facts supplied in the task. No new fetch of these four sources.",
      "iam_v2_4_0_build_gradle_blob":"fa78d411292d517ecb702dac926b960f08075023",
      "provider_v6_72_0_application_go_blob":"c9ae6dbeb467ccad93ced4391f79a1cb21cfca6c",
      "provider_go_mod_blob":"109bd1ab98f58ca14f380578db3e576d2d401f70",
      "sdk_kinesisanalyticsv2_v1_47_6_enum_blob":"f0f6beba8ba672c45a9017d254d4786c4baa5140",
     }
    }
    save("RUNTIME_DECISION_MATRIX.json",matrix)
    save("REMAINING_GATE_REGISTER.json",{
     "B-06":"HOLD","B-07":"HOLD","M1-TOOLS":"HOLD","CI-INT-01":"HOLD","INT-00":"HOLD",
     "OD-HO-06":"NOT_AUTHORIZED","technical_witnesses":{"count":120,"status":"OPEN"},
     "OD-B06-RUNTIME-02":"BLOCKED_NO_EXACT_RUNTIME_SELECTION","independent_review":"PENDING",
     "publisher_trust":"OPEN","signature_verification":"NOT_TESTED","security_scan":"NOT_TESTED",
     "managed_flink_runtime":"NOT_TESTED","managed_connect_plugin":"NOT_TESTED",
     "checkpoint_restore":"NOT_TESTED","schema_evolution":"NOT_TESTED","wire_compatibility":"NOT_TESTED",
     "L1":"PARTIAL_EXACT_ARTIFACTS_AND_COMPARISON_WITNESSES",
     "L2":"PARTIAL_EFFECTIVE_DEPENDENCY_AND_SECURITY_CLOSURE_OPEN",
     "L3":"PARTIAL_JAVA_HEADER_AND_API_ONLY",
     "L4":"PARTIAL_AGE_AND_RECORDED_CVE_ONLY",
     "L5":"PARTIAL_TARGETED_STATIC_REPLAY",
     "L6":"NOT_TESTED","L7":"NOT_TESTED",
    })
if __name__=="__main__":
    main()
