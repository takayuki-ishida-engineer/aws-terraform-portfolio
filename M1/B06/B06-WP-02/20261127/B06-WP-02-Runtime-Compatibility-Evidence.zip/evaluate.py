"""Offline static compatibility report from pinned public originals and WP01 receipts."""
from collections import Counter
from datetime import datetime, timezone, timedelta
from hashlib import sha1
from html.parser import HTMLParser
from io import BytesIO
from pathlib import Path
from zipfile import ZipFile
import json
import re

from acquire import RAW, identity, key, save
from api_refs import CONNECT, FLINK, GLUE, LENSES, ClassFile, check, collect, compare
from jar_inventory import inspect_jar
from pom_model import inspect_model
from collect_inputs import FIXED

WP01 = Path("wp01-inputs")
ZIP_SHA = "4d5f50ab59961dd03f6d13b27141532872e99dcf368ca787f8e5b2ba156de60e"
CONNECTOR = FIXED[0]
DOC = "https://docs.aws.amazon.com/"
FLINK_DOC = DOC + "managed-flink/latest/java/"
MSK_DOC = DOC + "msk/latest/developerguide/"
HTML_SOURCES = {
    "connectors.html":FLINK_DOC+"how-flink-connectors.html",
    "versions.html":FLINK_DOC+"release-version-list.html",
    "flink-2-2.html":FLINK_DOC+"flink-2-2.html",
    "flink-2-3.html":FLINK_DOC+"flink-2-3.html",
    "flink-1-20.html":FLINK_DOC+"flink-1-20.html",
    "flink-upgrades.html":FLINK_DOC+"how-in-place-version-upgrades.html",
    "flink-state.html":FLINK_DOC+"state-compatibility.html",
    "msk-connect.html":MSK_DOC+"msk-connect.html",
    "msk-iam-role.html":MSK_DOC+"msk-connect-service-execution-role.html",
    "msk-worker-config.html":MSK_DOC+"msk-connect-workers.html",
    "connect-security.html":MSK_DOC+"msk-connect-security.html",
}
NON_EVIDENTIARY = {
    "how-creating-apps-connectors.html":FLINK_DOC+"how-creating-apps-connectors.html",
    "connect-workers.html":MSK_DOC+"msk-connect-supported-kafka-connect-versions.html",
    "flink-regions.html":DOC+"general/latest/gr/kinesisanalytics.html",
    "flink-service-endpoints.html":DOC+"general/latest/gr/ak.html",
    "flink-endpoints-akda.html":DOC+"general/latest/gr/akda.html",
    "msk-create-connector.html":MSK_DOC+"msk-connect-create-connector.html",
}


def read(path):
    return json.loads(Path(path).read_bytes())


class Tables(HTMLParser):
    def __init__(self):
        super().__init__()
        self.rows=[]
        self.row=None
        self.cell=None
        self.parts=[]
    def handle_starttag(self, tag, attrs):
        if tag=="tr":
            self.row=[]
        if self.row is not None and tag in ("th","td"):
            self.cell=[]
    def handle_endtag(self,tag):
        if self.cell is not None and tag in ("th","td"):
            self.row.append(" ".join(" ".join(self.cell).split()))
            self.cell=None
        if tag=="tr" and self.row is not None:
            self.rows.append(self.row)
            self.row=None
    def handle_data(self,data):
        self.parts.append(data)
        if self.cell is not None: self.cell.append(data)


def doc(name):
    obj=Tables()
    obj.feed((RAW/name).read_text())
    return obj.rows," ".join(" ".join(obj.parts).split())


def provenance_docs():
    rows,_=doc("connectors.html")
    kafka=[r for r in rows if r and r[0]=="Apache Kafka" and r[1:]==["flink-connector-kafka 4.0.0-2.0"]*2]
    headers=[r for r in rows if r==["Connector","Flink 2.2 Version","Flink 2.3 Version"]]
    check(kafka and headers,"AWS_CONNECTOR_TABLE")
    rows,_=doc("versions.html")
    runtime={r[0]:r[1:] for r in rows if r and r[0] in {"1.20.5","2.2.1","2.3.0"}}
    check(set(runtime)=={"1.20.5","2.2.1","2.3.0"} and all(x[:2]==["Supported","Supported"] for x in runtime.values()),"AWS_RUNTIME_TABLE")
    _,api=doc("msk-client-auth-api.html")
    _,create=doc("msk-create-api.html")
    _,connect=doc("msk-connect.html")
    _,flink22=doc("flink-2-2.html")
    _,states=doc("flink-state.html")
    rows120,_=doc("flink-1-20.html")
    rows23,_=doc("flink-2-3.html")
    check("NONE | IAM" in api and "kafkaClusterClientAuthentication" in create and "3.7.x" in connect,"AWS_MSK_API")
    check(any(r[:2]==["Java","11 (recommended)"] for r in rows120) and
          any(r[:2]==["Java","17 (recommended)"] for r in rows23)
          and "Java 17 is the default" in flink22,"AWS_JDK_ROWS")
    check("Kryo" in states and "cannot be restored" in states,"AWS_STATE_COMPATIBILITY")
    return {"connector":kafka[0],"aws_runtime_rows":runtime,"runtime_support_columns":["New Application","Existing Application"],
            "jdk_documented":{"1.20.5":11,"2.2.1":17,"2.3.0":17},
            "regional_capability":"OPEN_CA_CENTRAL_1_EXACT_RUNTIME_ACCOUNT_QUOTA_AND_CONNECTIVITY",
            "msk_create_auth_values":["NONE","IAM"],"msk_worker_scope":"3.7.x; public documentation omits the worker's exact patch and private classpath"}


def sources():
    payload=(WP01/"evidence.zip").read_bytes()
    check(identity(payload)==ZIP_SHA,"WP01_ZIP_DIGEST")
    with ZipFile(BytesIO(payload)) as z:
        manifest=json.loads(z.read("EXACT_ARTIFACT_IDENTITY_MANIFEST.json"))
        jar_inventory=json.loads(z.read("JAR_PLUGIN_CLASS_INVENTORY.json"))
        advisory=json.loads(z.read("CVE_APPLICABILITY_REPORT.json"))
        deps=json.loads(z.read("DEPENDENCY_INVENTORY.json"))
        files={r["name"]:r for r in manifest["files"]}
        reused=[]
        inspect_names=["lenses-s3-11.7.3.zip"]
        for v in ("1.1.27","2.0.2"):
            inspect_names += [key(("software.amazon.glue",p,v),t) for p,t in
                              (("schema-registry-flink-serde","jar"),("schema-registry-flink-serde","pom"),
                               ("schema-registry-serde","jar"),("schema-registry-kafkaconnect-converter","jar"))]
        inspect_names += [key(c,"jar") for c in (("org.apache.kafka","kafka-clients","3.9.2"),
                                               ("software.amazon.msk","aws-msk-iam-auth","2.4.0"))]
        for n in inspect_names:
            r=files[n]
            b=(WP01/r["path"]).read_bytes()
            check((len(b),identity(b))==(r["size_bytes"],r["sha256"]),"WP01_RAW_"+n)
            reused.append({k:r[k] for k in ("name","path","size_bytes","sha256","url")})
        helpers=[]
        for n in ("acquire.py","pom_model.py","jar_inventory.py"):
            b=z.read(n)
            local=Path(n).read_bytes()
            # acquire.py had one allowlist extension for the recorded AWS doc receipts.
            if n=="acquire.py":
                local=local.replace(b', "docs.aws.amazon.com"',b"")
            check(b==local,"WP01_SOURCE_"+n)
            helpers.append(dict(name=n,sha256=identity(b)))
    return files,reused,helpers,jar_inventory,advisory,deps


def validate_new(files):
    receipts=[r for p in sorted(Path(".").glob("artifact-*.json")) for r in read(p)]
    by_name={r["name"]:r for r in receipts if r.get("path")}
    for row in read("documentation-receipts.json"):
        n=row["name"]
        check(row["url"]=={**HTML_SOURCES,**NON_EVIDENTIARY}.get(n),"DOCUMENTATION_RECEIPT_URI")
        by_name[n]=row
    checks=[]
    redundant=[]
    rows=[]
    for n,r in sorted(by_name.items()):
        b=Path(r["path"]).read_bytes()
        check((len(b),identity(b))==(r["size_bytes"],r["sha256"]),"RAW_IDENTITY_"+n)
        if (n.endswith(".jar") or n.endswith(".pom")) and n+".sha1" in by_name:
            s=by_name[n+".sha1"]
            expected=Path(s["path"]).read_text().strip().lower()
            actual=sha1(b,usedforsecurity=False).hexdigest()
            check(re.fullmatch("[0-9a-f]{40}",expected) is not None and actual==expected,"CHECKSUM_"+n)
            checks.append(dict(name=n,algorithm="SHA-1_REPOSITORY_CHECKSUM",actual=actual,
                               expected=expected,source=s["url"],outcome="MATCH"))
        if n in files and files[n]["sha256"]==r["sha256"]:
            redundant.append(n)
        rows.append({**r,"publication":"SCRATCH_IMMUTABLE_REFERENCE_ONLY",
                     "prior_identity_match":n in redundant,
                     "publication_reason":"Third-party raw documents, POMs, checksums or binaries. Redistribution clearance not established."})
    check({p.name for p in RAW.iterdir()}==set(by_name),"ORIGINAL_INVENTORY_COVERAGE")
    return rows,checks,redundant,receipts


def main():
    files,reused,helpers,prior,advisory,deps=sources()
    upstream=provenance_docs()
    new,checks,redundant,receipts=validate_new(files)
    connector=inspect_model(CONNECTOR)
    check(not connector["unresolved_parent_or_bom"],"CONNECTOR_MODEL_CONTROLS")
    exact_kafka=[d for d in connector["static_direct_scope_projection"] if d["coordinates"]=="org.apache.kafka:kafka-clients"]
    check(len(exact_kafka)==1 and (exact_kafka[0]["version"],exact_kafka[0]["scope"])==("3.9.0","compile"),"KAFKA_DIRECT")
    jar,_c,_a,_h=inspect_jar(RAW/key(CONNECTOR,"jar"))
    check(jar["java_selection"]["17"]["normal_bytecode_result"]=="PASS_HEADER_ONLY" and jar["base_non_connect_kafka_class_count"]==0,"CONNECTOR_HEADER_AND_CLIENT")
    listing=read(RAW/"flink-kafka-4.central.json")["response"]
    check(listing["numFound"]==1 and listing["docs"][0]["id"]==":".join(CONNECTOR),"INDEXED_GAV")
    p=datetime.fromtimestamp(listing["docs"][0]["timestamp"]/1000,timezone.utc)
    observation=next(r for r in new if r["name"]=="flink-kafka-4.central.json")
    now=datetime.fromisoformat(observation["observed_at_utc"])
    check(now>=p+timedelta(days=14),"CONNECTOR_RELEASE_AGE")
    check(any(x["vulnerable_version_range"]==">= 2.8.0, < 3.9.2" for x in advisory["ranges"]),"RECORDED_ADVISORY")
    glue={}
    api_jars={v:[RAW/key(("org.apache.flink","flink-avro",v),"jar")] for v in ("2.2.1","2.3.0")}
    jar_checks={}
    for coords in (*FIXED,("org.apache.kafka","connect-json","3.7.0")):
        n=key(coords,"jar")
        data=inspect_jar(RAW/n)[0]
        jar_checks[n]={k:data[k] for k in ("archive_safety_crc","java_selection","license_notice_members")}
    for v in ("1.1.27","2.0.2"):
        coords=("software.amazon.glue","schema-registry-flink-serde",v)
        raw=WP01/"originals"/key(coords,"jar")
        refs=collect(raw,GLUE,FLINK)
        matrix={ver:compare(refs,jars,FLINK) for ver,jars in api_jars.items()}
        check(all(len(r["class_results"])==5 and len(r["member_results"])==4 and
                  all(c["status"]=="FOUND" for c in r["class_results"]) and
                  all(m["status"]=="EXACT_ACCESSIBLE_DESCRIPTOR_FOUND" for m in r["member_results"])
                  for r in matrix.values()),"GLUE_TARGETED_AVRO_API")
        provided=[d for d in deps["models"][":".join(coords)]["static_direct_scope_projection"]
                  if d["scope"]=="provided" and d["coordinates"].startswith("org.apache.flink:")]
        glue[v]={"source_classes_examined":refs["source_classes_examined"],"comparisons":matrix,
                 "wp01_provided_flink_declarations":provided,"legacy_flink_risk":"OPEN",
                 "runtime_linkage":"NOT_TESTED"}
    lp=WP01/"originals"/"lenses-s3-11.7.3.zip"
    with ZipFile(lp) as outer:
        nested,=[n for n in outer.namelist() if n.endswith(".jar")]
        lens=BytesIO(outer.read(nested))
    lrefs=collect(lens,LENSES,CONNECT)
    lr=compare(lrefs,[RAW/key(("org.apache.kafka",a,"3.7.0"),"jar") for a in ("connect-api","connect-json")],CONNECT)
    check(Counter(m["status"] for m in lr["member_results"])==
          {"EXACT_ACCESSIBLE_DESCRIPTOR_FOUND":132,"INHERITED_JDK_ENUM_CONTRACT":1},"LENSES_TARGETED_CONNECT_API")
    check(len(lr["class_results"])==30 and all(x["status"]=="FOUND" for x in lr["class_results"]),"LENSES_TARGETED_CONNECT_CLASSES")
    iam=prior["jars"][key(("software.amazon.msk","aws-msk-iam-auth","2.4.0"),"jar")]["java_selection"]
    check(iam["11"]["normal_bytecode_result"]=="FAIL_MAJOR" and iam["17"]["normal_bytecode_result"]=="PASS_HEADER_ONLY","IAM_WP01_BYTECODE")
    try:
        ClassFile(b"invalid")
    except ValueError as e:
        check(str(e)=="CLASS_MAGIC","MALFORMED_CLASS_CONTROL")
    else:
        raise ValueError("MALFORMED_CLASS_NOT_REJECTED")
    save("NEW_ARTIFACT_IDENTITY_MANIFEST.json",{"originals":new,"http_receipts":receipts,"reused_digest_matches":redundant})
    save("EXISTING_EVIDENCE_REUSE_MANIFEST.json",{"wp01_evidence_zip_sha256":ZIP_SHA,
      "prior_commit":"2c3661d3183caa4fd20ca2b11dd4021f2047a3a6",
      "reproduction_url":"https://raw.githubusercontent.com/takayuki-ishida-engineer/aws-terraform-portfolio/2c3661d3183caa4fd20ca2b11dd4021f2047a3a6/M1/B06/B06-WP-01/20261127/B06-WP-01-Data-Connector-Static-Evidence.zip",
      "existing_original_inventory_size":len(files),"targeted_rehashes":reused,"reused_source_files":helpers,
      "wp01_evidence_members_used":["EXACT_ARTIFACT_IDENTITY_MANIFEST.json","JAR_PLUGIN_CLASS_INVENTORY.json",
                                   "DEPENDENCY_INVENTORY.json","CVE_APPLICABILITY_REPORT.json"],
      "already_retained_model_controls_retrieved_again":redundant,
      "note":"Targeted rehash and existing results reuse. No full WP01 reanalysis. The control acquisition fetched four POMs and their checksums already present in WP01; all eight matched the prior bytes."})
    save("DEPENDENCY_API_COMPATIBILITY_DELTA.json",{
      "aws_documentary":upstream,"connector":connector,
      "connector_bytecode":jar["java_selection"],"connector_license_notice":jar["license_notice_members"],
      "connector_kafka_client":{"declared_and_static_model":"3.9.0 compile","bundled_unrelocated_base_kafka_classes":0,
        "relocation_limit":"Targeted archive inspection, no separate relocated client identity established.",
        "kafka_3_9_2_interaction":"Fixed WP01 3.9.2 is first patched for the recorded CVE but is not the connector declaration. No effective mediation or authorized override.",
        "iam_auth_2_4_0_interaction":"Java17 header-compatible. Existing IAM AWS SDK BOM 2.51.2; effective classpath, SDK/Jackson mediation and runtime authentication unverified.",
        "recorded_cve":"CVE-2026-35554: 3.9.0 in affected range. No full vulnerability or reachability conclusion.",
        "advisory_url":advisory["url"]},
      "connector_release":{"central_index_gav":listing["docs"][0]["id"],"index_release_utc":p.isoformat(),
         "observed_at_utc":now.isoformat(),"published_age":"PASS_14_DAY_INDEX_TIMESTAMP_ONLY","signature":"NOT_TESTED","publisher_trust":"OPEN"},
      "glue":glue,"glue_adapter_boundary":
        "Core SerDe is the schema/codec module; the legacy Flink Avro adapter is separate and declares Flink 1.12.2 provided. The Glue Connect Converter remains outside the Flink classpath. Preserve existing schema identifiers, wire framing, serializer semantics and format; no new adapter, migration or proof of runtime compatibility.",
      "lenses":{"api_target":"Apache 3.7.0 connect-api plus connect-json, a fixed comparison witness for AWS 3.7.x; not AWS worker image",
         "project_source_classes_examined":lrefs["source_classes_examined"],"reference_comparison":lr,
         "jdk_enum_contract_url":"https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/lang/Enum.html#name()",
         "wp01_manifest_kafka_marker":"4.1.0","wp01_sbom_kafka_distribution":"8.1.0-ccs",
         "ccs_version_inference":"NONE","existing_glue_collision_summary":prior["route_duplicate_class_candidates"],
         "managed_authentication":"AWS CreateConnector authenticationType IAM/NONE and service execution role govern worker-to-MSK broker authentication.",
         "plugin_authentication":"Plugin-originated client/S3/Glue calls have their own SDK dependencies, credential path and policy. Worker IAM support does not establish plugin classloading or client authentication.",
         "managed_worker_linkage":"NOT_TESTED"},
    })
    save("ACTUAL_STATIC_TEST_RESULTS.json",{"documentary_checks":upstream,"raw_identities_rehashed":len(new),
       "repository_checksum_matches":checks,"archive_header_and_crc":jar_checks,
       "glue_api_checks":{"pairs":4,"class_refs_each":5,"member_refs_each":4,"matched_each":"5/5 classes; 4/4 descriptors"},
       "lenses_api_checks":{"project_classes_examined":lrefs["source_classes_examined"],"classes_found":30,
           "members_exact":132,"jdk_enum_inherited":1,"fraction":"133/133 observed references; no managed linkage claim"},
       "negative_malformed_class":"REJECTED_CLASS_MAGIC","runtime_tests":"NOT_TESTED","approved_to_run":False})
    print(len(new),len(checks),len(redundant),len(reused),len(lr["member_results"]))

if __name__=="__main__":
    main()
