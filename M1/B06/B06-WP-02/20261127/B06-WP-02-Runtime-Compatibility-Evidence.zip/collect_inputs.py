"""Only fixed Kafka connector and minimum API comparison artifacts plus model controls."""
from urllib.parse import urlencode
from pathlib import Path
import json
from acquire import RAW, batch, control_model, key, maven_url, save, xml

FIXED = [
 ("org.apache.flink","flink-connector-kafka","4.0.0-2.0"),
 ("org.apache.flink","flink-avro","2.2.1"),
 ("org.apache.flink","flink-avro","2.3.0"),
 ("org.apache.kafka","connect-api","3.7.0"),
]
def main():
    tasks=[(key(c,s),maven_url(c,s),25_000_000 if s=="jar" else 1_048_576)
           for c in FIXED for s in ("pom","jar","pom.sha1","jar.sha1")]
    g,a,v=FIXED[0]
    query=urlencode(dict(q=f"g:{g} AND a:{a} AND v:{v}",core="gav",rows=1,wt="json"))
    tasks.append(("flink-kafka-4.central.json","https://central.sonatype.com/solrsearch/select?"+query,524288))
    save("artifact-top.json",batch(tasks))
    # POM ancestors/imports of the Kafka Connector, not the Avro/Connect API witness jars.
    root={FIXED[0]}
    visited=set()
    for level in range(6):
        missing=[c for c in root-visited if not (RAW/key(c,"pom")).exists()]
        if missing:
            work=[(key(c,s),maven_url(c,s),1_048_576) for c in sorted(missing) for s in ("pom","pom.sha1")]
            save(f"artifact-controls-{level}.json",batch(work))
        current=root-visited
        if not current: break
        visited |= current
        for c in current:
            p=RAW/key(c,"pom")
            if p.exists():
                root.update(control_model(xml(p.read_bytes())))
    save("connector-control-set.json",sorted(":".join(c) for c in visited))
if __name__=="__main__":
    main()
