"""Verify frozen sources and parse only scoped public documentation sections."""
from collections import defaultdict
from hashlib import sha256
from io import BytesIO
from pathlib import Path
import json
import re
from urllib.parse import urljoin, urlsplit
from zipfile import ZipFile

from lxml import html

ROOT = Path('/workspace')
PRIOR = ROOT / 'scratch/rev6-evidence'
INPUT = ROOT / 'scratch/x01-x04-offline.r0JRat/input'
CONTRACT_NAME = 'Revision6_Final_Contracts.json'
PREPLAN_ZIP = ROOT / 'scratch/Revision6_Codex_Preplan_Evidence_20261126.zip'
FINAL_ZIP_NAME = 'S3-S4-MASTER-PLAN-REV6-FINAL-CONDITIONAL_Package_20261126.zip'
EXACT = {
    'AWS_Terraform_Portfolio_MASTER_POLICY_20261127_v15_2.pdf': '1beba6eb94197247a52718ee05d162dcda27fc6716c809f11643e683714d56e4',
    CONTRACT_NAME: '29a396daf7cadb9eee1f089b7ac427fcb7b7c9100f6e170ac97a3bcbd633a783',
    'REV6_B04_Regional_Capability_Delta_20261127.json': '073ef4da36d0821a52888a6c761e8f878ce10686bd84c6119d41cf9f5f5c5aa5',
    'REV6_B04_CSPM_Membership_Delta_20261127.json': '4846acc12c853b300d0c2d508f615934ba24a0e4af1ac07af52ddda893ea7ff4',
    'REV6_B04_B05_Design_Delta_20261127.json': '5d4444972c86836088aa164eac4894afa310aab383f85097fa2da4bdacbd9e42',
    'REV6_B04_B05_Consolidated_Design_Record_20261127.json': '2f62a0df8b16ab2747c0f3813cf0fdcb7ff8957baa0b92d0ab58a7fe4717e1fc',
    'REV6_INT00_Contract_Review_02_20261127.json': 'ccd97fa4bc32ef9decee173ea3ce53f6318230066babbe1c89d0a305de141c4a',
    'REV6_X01_X04_Implementation_Obligations_20261127.json':'8e72a95318b3811a03bb57b8b7be194f8ebb7e0cb6f398f7169c9205d1f94b4c',
    FINAL_ZIP_NAME: '6e3827ca36ff40d159ad36281bfbb2066269675977d7008a953277e3f4bb4635',
}
CID = re.compile(r'[A-Za-z][A-Za-z0-9]*\.\d+')
HEADING = re.compile(r'^\[(' + CID.pattern + r')\]\s*(.+)$')
# AWS type syntax normally has exactly two groups after AWS::.
RESOURCE = re.compile(r'\bAWS::[A-Za-z0-9]+::[A-Za-z0-9]+\b|\bAWS::::Account\b')
H2_OR_HIGHER = {'h1','h2'}


def need(ok, code):
    if not ok:
        raise ValueError(code)


def digest(data):
    return sha256(data).hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def write(path, obj):
    Path(path).write_text(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True)+'\n')


def check_bytes(path, expected, size=None):
    data = Path(path).read_bytes()
    need(digest(data)==expected and (size is None or len(data)==size), f'IDENTITY_MISMATCH:{Path(path).name}')
    return data


def text(e):
    return ' '.join(e.text_content().split())


def doc(data):
    return html.fromstring(data,parser=html.HTMLParser(no_network=True))


def section(d, anchor, *, closure=False):
    h = d.get_element_by_id(anchor, None)
    need(h is not None and h.tag in ('h1','h2','h3','h4'), 'INCOMPLETE_SOURCE')
    heads = {'h'+str(n) for n in range(1,int(h.tag[-1])+1)}
    body = []
    for e in h.itersiblings():
        if e.tag in heads or e.get('id') in ('main-col-footer','aws-page-footer') or e.tag=='awsdocs-copyright':
            return h,body
        body.append(e)
    need(not closure, 'INCOMPLETE_SOURCE')
    return h,body


def parse_membership(d, anchor, src, expected_ids=None):
    h, body = section(d,anchor,closure=True)
    rows = {}
    for chunk in body:
        for link in chunk.xpath('self::a|.//a'):
            val=text(link)
            m=HEADING.fullmatch(val)
            if not m and not val.startswith('['):
                continue
            need(bool(m) and bool(link.get('href')), 'INCOMPLETE_SOURCE')
            key,title=m.groups()
            need(key not in rows, 'DUPLICATE_CONTROL')
            rows[key]=dict(id=key,title=title,url=urljoin(src,link.get('href')),line=link.sourceline,section=anchor)
    need(bool(rows),'INCOMPLETE_SOURCE')
    if expected_ids is not None:
        need(len(rows)==len(expected_ids),'INCOMPLETE_SOURCE')
        need(rows.keys()==set(expected_ids),'ROW_IDENTITY_CHANGED')
    return rows


def table_rows(d, anchor, headers, n_rows=None):
    h,body=section(d,anchor)
    tables = [t for e in body for t in e.xpath('self::table|.//table')]
    need(len(tables)==1,'INCOMPLETE_SOURCE')
    tr=tables[0].xpath('.//tr')
    need(tr and [text(x) for x in tr[0].xpath('./th')]==headers,'INCOMPLETE_SOURCE')
    rows=[(r.sourceline,[text(x) for x in r.xpath('./td')]) for r in tr[1:]]
    need(bool(rows) and all(len(cs)==len(headers) for _,cs in rows),'INCOMPLETE_SOURCE')
    if n_rows is not None:
        need(len(rows)==n_rows,'INCOMPLETE_SOURCE')
    return rows


def bounded_table(data):
    """Reject a truncated vendor table before using forgiving HTML parsing."""
    s=data.lower()
    opened=len(re.findall(rb'<table(?:\s|>)',s))
    need(opened and opened==s.count(b'</table>'),'INCOMPLETE_SOURCE')


def verify_inputs():
    reuse={}
    objects={}
    for name,pin in EXACT.items():
        if name.endswith(('.pdf','.zip')):
            paths=list((ROOT/'attachments').glob('*/'+name))
        else:
            paths=list(INPUT.rglob(name))
        need(len(paths)==1,'MISSING_OR_AMBIGUOUS_INPUT:'+name)
        data=check_bytes(paths[0],pin)
        reuse[name]=dict(path=str(paths[0].relative_to(ROOT)),size_bytes=len(data),sha256=pin)
        if name.endswith('.json'):
            objects[name]=json.loads(data)
        elif name==FINAL_ZIP_NAME:
            with ZipFile(paths[0]) as z:
                need(digest(z.read(CONTRACT_NAME))==EXACT[CONTRACT_NAME],'Final contract package mismatch')
                for member in ('Revision6_Final_Codex_Task_Packets.json','Revision6_Final_Traceability.json'):
                    b=z.read(member)
                    if (INPUT/'original'/member).is_file():
                        need(b==(INPUT/'original'/member).read_bytes(),'Retained packet bytes differ')
                    reuse[member]=dict(container=FINAL_ZIP_NAME,member=member,size_bytes=len(b),sha256=digest(b))
                    objects[member]=json.loads(b)
                for member in z.namelist():
                    if member.startswith('inputs/'):
                        b=z.read(member)
                        reuse[member]=dict(container=FINAL_ZIP_NAME,member=member,size_bytes=len(b),sha256=digest(b),
                                           role='Archived package preserved; scoped Resolution members verified by path and digest')
                        if 'Package_v1_12_' not in member:
                            continue
                        with ZipFile(BytesIO(b)) as child:
                            scoped=('sources/Resolution_Conditional_Rev6_P6_01_v0_9_20261126.md',
                                    'sources/Resolution_Cross_Contract_Review_v0_2_20261126.md',
                                    'sources/Resolution_Targeted_Closure_v0_6_20261126.md')
                            for inner in scoped:
                                t=child.read(inner)
                                data=t.decode()
                                anchors=[term for term in ('Region','Config','Security Hub','X03','CSPM')
                                         if term.casefold() in data.casefold()]
                                need(anchors,'Missing scoped Resolution anchors')
                                reuse[inner]=dict(container=member,member=inner,size_bytes=len(t),sha256=digest(t),
                                                  matched_scope_terms=anchors,role='Historical scoped source; Final Contracts and delegated decisions control.')
    with ZipFile(PREPLAN_ZIP) as z:
        need(digest(PREPLAN_ZIP.read_bytes())=='360b8f98f78cdf8995ab93ce915fe9d055995f2f6e8067cb8439b1f017c1848f','Preplan ZIP identity')
        for name in ('c-e04-cspm.json','fetch-documents.json'):
            b=z.read(name)
            need(b==(PRIOR/name).read_bytes(),'Preplan byte identity '+name)
            reuse[name]=dict(container=PREPLAN_ZIP.name,member=name,path=str((PRIOR/name).relative_to(ROOT)),size_bytes=len(b),sha256=digest(b))
            objects[name]=json.loads(b)
        for r in objects['fetch-documents.json']:
            b=check_bytes(PRIOR/r['path'],r['sha256'],r['bytes'])
            need(b==z.read(r['path']),'Retained AWS original identity '+r['identity'])
    return reuse,objects


def documentation(objects):
    vendor={}
    receipts={}
    for row in objects['fetch-documents.json']:
        name=row['identity']
        vendor[name]=check_bytes(PRIOR/row['path'],row['sha256'],row['bytes'])
        receipts[name]=dict(id=name,url=row['source_url'],retrieval_utc=row['acquired_at'],
                            path=str((PRIOR/row['path']).relative_to(ROOT)),size_bytes=row['bytes'],sha256=row['sha256'],
                            http=row['http_status'],reused=True)
    rows=read('retrieval.json')+read('retrieval-rules.json')
    for row in rows:
        if row['status']=='RETAINED':
            vendor[row['id']]=check_bytes(row['path'],row['sha256'],row['size'])
            receipts[row['id']]=dict(row,reused=False,size_bytes=row['size'])
        else:
            receipts[row['id']]=row
    for r in receipts.values():
        r['redistribution']='WITHHELD_RAW_VENDOR_DOCUMENTATION'
        r['reason']='Retained for source replay; raw third-party materials are outside this publication.'
        if not r['id'].startswith('detail-'):
            r['section_ids']=[h.get('id') for h in doc(vendor[r['id']]).xpath('//h1|//h2|//h3') if h.get('id')]
    return vendor,receipts


def details(vendor, receipts, ids):
    out={}
    labels={
        'resource type':'evaluated','evaluated resource':'evaluated',
        'required aws config recording resources':'explicit_recording',
        'aws config rule':'rule','aws configrule':'rule',
        'schedule type':'schedule','trigger type':'schedule','related requirements':'requirements',
    }
    for name,data in vendor.items():
        if not name.startswith('detail-'):
            continue
        d=doc(data)
        for h in d.xpath('//h2|//h3|//h4'):
            m=HEADING.fullmatch(text(h))
            if not m or m[1] not in ids:
                continue
            identifier=m[1]
            need(identifier not in out and h.get('id'),'DUPLICATE_CONTROL')
            _,body=section(d,h.get('id'))
            fields={}
            for e in body:
                for p in e.xpath('self::p|.//p'):
                    head, sep, val=text(p).partition(':')
                    tag=labels.get(head.strip().lower())
                    if not sep or not tag:
                        continue
                    field=dict(value=val.strip(),line=p.sourceline,
                               links=[urljoin(receipts[name]['url'], a.get('href')) for a in p.xpath('.//a[@href]')])
                    need(tag not in fields or fields[tag]['value']==field['value'],'conflicting detail fields '+identifier)
                    fields[tag]=field
            out[identifier]=dict(source_id=name,section=h.get('id'),heading_line=h.sourceline,title=m[2],fields=fields)
    return out
