"""Bounded acquisition of public vendor documentation only."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import re
from urllib.parse import urldefrag, urlsplit
from urllib.request import HTTPSHandler, HTTPRedirectHandler, Request, build_opener
from urllib.error import URLError, HTTPError
import sys

SEC = 'https://docs.aws.amazon.com/securityhub/latest/userguide/'
CFG = 'https://docs.aws.amazon.com/config/latest/developerguide/'
ALLOWED_PREFIXES = (SEC, CFG)


class RestrictRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if not newurl.startswith(ALLOWED_PREFIXES):
            raise ValueError('redirect outside authorized documentation scope')
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def get(job):
    key, url = job
    if not url.startswith(ALLOWED_PREFIXES):
        raise ValueError('URL outside authorized scope')
    row = dict(id=key, url=url, path='originals/'+key+'.html', retrieval_utc=datetime.now(timezone.utc).isoformat())
    try:
        opener = build_opener(RestrictRedirect, HTTPSHandler)
        with opener.open(Request(url, headers={'User-Agent':'Portfolio-Static-Qualification', 'Accept-Encoding':'identity'}), timeout=18) as response:
            data=response.read(10_000_001)
            row.update(http=response.status, effective_url=response.geturl(), content_type=response.headers.get_content_type())
        if len(data)>10_000_000:
            raise ValueError('response too large')
        if row['content_type'] != 'text/html':
            raise ValueError('unexpected response type')
        Path(row['path']).write_bytes(data)
        row.update(size=len(data), sha256=sha256(data).hexdigest(), status='RETAINED')
    except (URLError, HTTPError, TimeoutError, ValueError) as e:
        row.update(status=type(e).__name__, http=getattr(e,'code',row.get('http')))
    return row


def details(prior):
    out = {}
    for rows in prior['membership'].values():
        for control in rows:
            url = urldefrag(control['url']).url
            if re.fullmatch(r'https://docs\.aws\.amazon\.com/securityhub/latest/userguide/[a-z0-9-]+-controls\.html',url):
                out['detail-'+Path(urlsplit(url).path).stem] = url
    return out


def main():
    base = {
        'fsbp-current': SEC+'fsbp-standard.html',
        'catalog-current': SEC+'securityhub-controls-reference.html',
        'cspm-regions': SEC+'securityhub-regions.html',
        'config-coverage':CFG+'what-is-resource-config-coverage.html',
        'config-reference':CFG+'resource-config-reference.html',
        'config-global':CFG+'select-resources.html',
        'central-intro':SEC+'central-configuration-intro.html',
        'central-start':SEC+'start-central-configuration.html',
        'central-policy':SEC+'configuration-policies-overview.html',
        'central-assoc':SEC+'create-associate-policy.html',
    }
    if len(sys.argv)>2:
        raise SystemExit('pass at most one prior evidence path')
    if len(sys.argv)==2:
        base.update(details(json.loads(Path(sys.argv[1]).read_bytes())))
    with ThreadPoolExecutor(max_workers=10) as pool:
        rows=list(pool.map(get,sorted(base.items())))
    Path('retrieval.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(len(rows), {r['status']:sum(x['status']==r['status'] for x in rows) for r in rows})
    for r in rows:
        if r['status']!='RETAINED':
            print(r['id'],r['status'],r['http'])


if __name__=='__main__':
    main()
