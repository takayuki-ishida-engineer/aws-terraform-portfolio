"""Join documentary membership, Config evidence and fixed profile/ownership records."""
from collections import Counter, defaultdict
from pathlib import Path
import json
import re
from urllib.parse import urlsplit

from sources import (verify_inputs, documentation, doc, text, section, parse_membership, table_rows,
                     bounded_table, details, write, need, CID, HEADING, RESOURCE, CONTRACT_NAME)

REGIONS = {
    'ca-central-1': ('cacentral1','Canada (Central)','canada-central-section-head'),
    'us-east-1': ('useast1','US East (N. Virginia)','us-east-n-virginia-section-head'),
    'us-east-2': ('useast2','US East (Ohio)','us-east-ohio-section-head'),
}
FSBP_LABEL = {'AWS Foundational Security Best Practices v1.0.0','AWS Foundational Security Best Practices'}
CIS_LABEL = {'CIS AWS Foundations Benchmark v5.0.0'}
IAM_GLOBAL = {'AWS::IAM::Group','AWS::IAM::Policy','AWS::IAM::Role','AWS::IAM::User'}
TYPE_HEADERS=['Resource type','Canada (Central)','Canada West (Calgary)','Mexico (Central)',
              'South America (São Paulo)','US East (N. Virginia)','US East (Ohio)',
              'US West (N. California)','US West (Oregon)']


def slices(objects):
    return {n: next((v for k,v in objects.items() if f'{n}_20261127.json' in k), None)
            for n in ('Regional_Capability_Delta','CSPM_Membership_Delta','B04_B05_Design_Delta',
                      'B04_B05_Consolidated_Design_Record','Contract_Review_02','X01_X04_Implementation_Obligations')}


def get_catalog(vendor):
    def one(key):
        bounded_table(vendor[key])
        rows=table_rows(doc(vendor[key]),'securityhub-controls-reference',
                        ['Security control ID','Security control title','Applicable standards','Severity',
                         'Supports custom parameters','Schedule type'])
        out={}
        for line,(cid,title,standards,_severity,_parameters,schedule) in rows:
            need(CID.fullmatch(cid) and cid not in out,'catalog identity')
            out[cid]={'line':line,'title':title,'standards':{x.strip() for x in standards.split(',')},'schedule':schedule}
        return out
    historical, current = one('CONTROL_CATALOG'), one('catalog-current')
    return historical,current


def memberships(vendor, receipts, prior, details_by_id, catalog_historical, catalog_current, frozen):
    fsbp= parse_membership(doc(vendor['fsbp-current']),'fsbp-controls',receipts['fsbp-current']['url'], frozen['fsbp_ids'])
    old= parse_membership(doc(vendor['FSBP']),'fsbp-controls',receipts['FSBP']['url'],
                          {r['id'] for r in prior['membership']['FSBP1.0.0']})
    need(fsbp.keys()==old.keys(),'Changed historical versus current FSBP membership')
    cis= parse_membership(doc(vendor['CIS']),'cis5v0-controls',receipts['CIS']['url'],frozen['cis_ids_retained'])
    bounded_table(vendor['CIS'])
    requirement=table_rows(doc(vendor['CIS']),'cis-version-comparison',[
        'Control ID and title','CIS v5.0.0 requirement','CIS v3.0.0 requirement',
        'CIS v1.4.0 requirement','CIS v1.2.0 requirement'])
    req_rows={}
    for line, row in requirement:
        m=HEADING.fullmatch(row[0])
        need(m and m[1] not in req_rows,'CIS requirement row identity')
        req_rows[m[1]]=dict(value=row[1],line=line,section='cis-version-comparison')
    def cat_ids(catalog,labels):
        return {i for i, row in catalog.items() if row['standards'] & labels}
    cat_f,cat_c=cat_ids(catalog_current,FSBP_LABEL),cat_ids(catalog_current,CIS_LABEL)
    need(cat_f==cat_ids(catalog_historical,FSBP_LABEL) and cat_c==cat_ids(catalog_historical,CIS_LABEL),
         'current catalog versus frozen history')
    need(cis.keys()==cat_c,'CIS5 catalog cross-check')
    for cid in cis:
        detail = details_by_id[cid]
        req = detail['fields'].get('requirements', {})
        exact = re.findall(r'CIS AWS Foundations Benchmark v?5\.0\.0\s*/\s*(\d+(?:\.\d+)+)', req.get('value',''))
        if cid not in req_rows:
            req_rows[cid]=dict(value=exact[0] if len(exact)==1 else None, source_id=detail['source_id'],
                               line=req.get('line'),section=detail['section'],
                               status='EXACT_V5_FROM_DETAIL' if len(exact)==1 else 'UNKNOWN')
        else:
            need(bool(re.search(r'\d+\.\d+',req_rows[cid]['value'])),'CIS5 requirement missing '+cid)
            req_rows[cid].update(source_id='CIS',detail_v5_label_matches=exact)
            if exact and exact!=[req_rows[cid]['value']]:
                req_rows[cid]['status']='SOURCE_CONFLICT_OPEN'
    regional={}
    for reg,(slug,*_) in REGIONS.items():
        aid='securityhub-control-support-'+slug
        rows=parse_membership(doc(vendor['CSPM-CONTROLS']),aid,receipts['CSPM-CONTROLS']['url'],frozen['regional'][reg]['ids'])
        _, body=section(doc(vendor['CSPM-CONTROLS']),aid,closure=True)
        need('not supported' in text(body[0]).lower(),'regional deny-list semantics absent')
        regional[reg]=rows

    shared=fsbp.keys() & cis.keys()
    dispute=sorted(fsbp.keys() ^ cat_f)
    safe_union=sorted(fsbp.keys() | cis.keys() | cat_f)
    need(set(safe_union)==set(frozen['union_candidate_ids']),'safety union drift')
    expected_retained=set(frozen['disputed_ids_retained'])
    need(cat_f-fsbp.keys()==expected_retained,'disputed safety-side rows')

    def member(i, rows, other, label, ver, source, catalog_set):
        r=rows.get(i)
        return dict(id=i, title=(r or details_by_id[i])['title'], standard=label, version=ver,
                    requirement=({'value':i,'section':'fsbp-controls'} if ver=='1.0.0' else req_rows[i]),
                    source=(dict(source_id=source, section=r['section'],line=r['line'],detail_url=r['url'])
                            if r else dict(source_id='catalog-current',section='securityhub-controls-reference',
                                           line=catalog_current[i]['line'])),
                    listed_in_standard_section=r is not None, listed_in_control_catalog=i in catalog_set,
                    shared_listed_membership=i in rows and i in other, other_standard_listed=i in other,
                    membership_status=('PUBLICATION_DISAGREEMENT_OPEN' if ver=='1.0.0' and i in dispute
                                       else 'DOCUMENTED_IN_STANDARD_AND_CATALOG'),
                    unavailable_regions=[reg for reg, rs in regional.items() if i in rs],
                    retirement_status='NO_EXPLICIT_RETIREMENT_EVIDENCE_IN_SCOPE',
                    technical_acceptance='OPEN')
    write('FSBP_MEMBERSHIP_INVENTORY.json', dict(section_count=len(fsbp),catalog_count=len(cat_f),
          control_ids_in_standard_section=sorted(fsbp),release='1.0.0',unresolved_publication_ids=dispute,
          rows=[member(i,fsbp,cis,'AWS Foundational Security Best Practices','1.0.0','fsbp-current',cat_f)
                for i in sorted(fsbp.keys()|cat_f)]))
    write('CIS_5_0_0_MEMBERSHIP_INVENTORY.json', dict(section_count=len(cis),catalog_count=len(cat_c),
          release='5.0.0',control_ids_in_standard_section=sorted(cis),
          scope='AWS automated controls only; AWS excludes manual benchmark requirements. No older CIS membership imported.',
          rows=[member(i,cis,fsbp,'CIS AWS Foundations Benchmark','5.0.0','CIS',cat_c) for i in sorted(cis)]))
    counts=dict(fsbp_standard_page=len(fsbp),fsbp_control_catalog=len(cat_f),cis_5_0_0=len(cis),
                standard_page_shared=len(shared),standard_page_union=len(fsbp.keys()|cis.keys()),
                confirmed_both_source_union=len((fsbp.keys()&cat_f)|cis.keys()),retained_candidate_union=len(safe_union))
    union=dict(counts=counts,publication_differences=dispute,
          default_action='Preserve scope. No disable or retirement inferred; membership conflict keeps activation blocked.',
          rows=[dict(id=i, fsbp_section=i in fsbp,fsbp_control_catalog=i in cat_f,cis_5_0_0=i in cis,
                     membership=('FSBP_MEMBERSHIP_DISPUTED' if i in dispute else 'DOCUMENTED'),
                     activation='BLOCKED') for i in safe_union])
    write('DEDUPLICATED_CONTROL_UNION.json',union)
    return safe_union,regional,counts,dispute


def config_index(vendor, prior):
    bounded_table(vendor['CONFIG'])
    h,body=section(doc(vendor['CONFIG']),'all-controls-config-resources')
    tables=[t for e in body for t in e.xpath('self::table|.//table')]
    need(len(tables)==1,'Config mapping table completeness')
    table=tables[0]
    need([text(t) for t in table.xpath('.//tr[th][1]/th')]==['AWS service','Resource types','Related controls'],
         'Config headers')
    need(len(table.xpath('.//tr[td]'))==208,'Config pinned row count')
    index=defaultdict(dict)
    seen_service=False
    for row in table.xpath('.//tr[td]'):
        cs=[text(t) for t in row.xpath('./td')]
        if len(cs)==3:
            seen_service=True
        need(seen_service and len(cs) in (2,3),'Config cell layout')
        typ, controls=cs[-2:]
        types=set(RESOURCE.findall(typ))
        need(types or not CID.search(controls),'unparsed scoped Config type')
        for cid in CID.findall(controls):
            for t in types:
                index[cid].setdefault(t,[]).append(row.sourceline)
    for cid,v in prior['joined_control_rows'].items():
        need(set(index[cid])=={r['resource_type'] for r in v['config_resource_rows']},'Config row identity '+cid)
    return index


def config_types(vendor):
    bounded_table(vendor['config-coverage'])
    index={}
    for line, values in table_rows(doc(vendor['config-coverage']),'north-south-america-regions',TYPE_HEADERS,795):
        need(values[0] not in index,'Duplicate regional resource type')
        index[values[0]]={'line':line}
        for reg,(_,label,_) in REGIONS.items():
            v=values[TYPE_HEADERS.index(label)]
            need(v in ('Yes','No'),'Unknown regional table cell')
            index[values[0]][reg]='DOCUMENTED_YES' if v=='Yes' else 'DOCUMENTED_NO'
    reference=doc(vendor['config-reference'])
    resource_reference={text(c): c.sourceline for c in reference.xpath('//td') if RESOURCE.fullmatch(text(c))}
    return index,resource_reference


def home_regions(vendor):
    d=doc(vendor['config-global'])
    tables=d.xpath('//table')
    need(len(tables)==1,'global home-region table')
    names={'US East (N. Virginia) Region':'us-east-1','US West (Oregon) Region':'us-west-2'}
    out={}
    for row in tables[0].xpath('.//tr[td]'):
        cs=[text(c) for c in row.xpath('./td')]
        need(len(cs) in (2,3) and cs[-1] in names,'global home cell')
        out[cs[-2]]=dict(region=names[cs[-1]],line=row.sourceline)
    need(len(out)==8 and out['AWS::CloudFront::Distribution']['region']=='us-east-1','global identities')
    return out


def managed_rule_index(vendor):
    d=doc(vendor['config-managed-rules-region'])
    out={}
    for reg,(*_,anchor) in REGIONS.items():
        h,body=section(d,anchor,closure=True)
        rows={}
        for e in body:
            for a in e.xpath('.//a[@href]'):
                key=Path(urlsplit(a.get('href')).path).stem
                need(key not in rows or rows[key]==text(a),'managed rule duplicate conflict')
                rows[key]=text(a)
        need(len(rows)=={'ca-central-1':755,'us-east-1':833,'us-east-2':773}[reg],'managed rule section unexpectedly incomplete')
        out[reg]=rows
    return out


def config_matrix(vendor, receipts, prior, ids, src, catalog):
    aggregate=config_index(vendor,prior)
    coverage,reference=config_types(vendor)
    homes=home_regions(vendor)
    rules_by_region=managed_rule_index(vendor)
    global_controls=parse_membership(doc(vendor['GLOBAL']),'controls-to-disable-global-resources',receipts['GLOBAL']['url'])
    rows={}
    for cid in ids:
        fields=src[cid]['fields']
        reported=fields.get('rule',{}).get('value','')
        link=next((x for x in fields.get('rule',{}).get('links',[]) if
                   x.startswith('https://docs.aws.amazon.com/config/latest/developerguide/')),None)
        schedule=fields.get('schedule',{}).get('value')
        old_schedule=catalog[cid]['schedule']
        eval_types=sorted(set(RESOURCE.findall(fields.get('evaluated',{}).get('value',''))))
        explicit=set(RESOURCE.findall(fields.get('explicit_recording',{}).get('value','')))
        table_types=set(aggregate[cid])
        virtual=eval_types==['AWS::::Account']
        if not reported:
            rule_status='CONFIG_RULE_UNKNOWN'
            dependency='UNKNOWN'
        elif reported.startswith('None') and 'custom Security Hub CSPM rule' in reported:
            rule_status='CSPM_CUSTOM_NO_PUBLIC_CONFIG_RULE'
            dependency='CONFIG_PREREQUISITE_SPECIAL' if cid=='Config.1' else 'CUSTOM_CONTROL_RECORDING_DEPENDENCY_UNKNOWN'
        elif 'custom Security Hub CSPM rule' in reported:
            rule_status='CSPM_CUSTOM_CONFIG_RULE'
            dependency='CONFIG_BACKED'
        elif link:
            rule_status='PUBLIC_AWS_CONFIG_MANAGED_RULE_REFERENCE'
            dependency='CONFIG_BACKED'
        else:
            rule_status='NAMED_RULE_CLASSIFICATION_UNKNOWN'
            dependency='CONFIG_BACKED'
        if explicit:
            recording=explicit
            rec_status='EXPLICIT_DETAIL_REQUIRED_RECORDING'
        elif table_types:
            recording=table_types
            rec_status='OFFICIAL_CONTROL_TO_REQUIRED_RESOURCE_TABLE'
        elif eval_types and not virtual:
            recording=set()
            rec_status='UNKNOWN_EVALUATED_TYPE_ONLY'
        else:
            recording=set()
            rec_status='UNKNOWN_ACCOUNT_CHECK_NO_RESOURCE_TYPE_ROW' if virtual else 'UNKNOWN_EXACT_RECORDING_RESOURCE'

        possible=sorted(recording|set(eval_types)|table_types)
        types={}
        for t in possible:
            scope='GLOBAL_IAM_PRE_2022' if t in IAM_GLOBAL else (
                'GLOBAL_DOCUMENTED_SERVICE_HOME' if t in homes and t!='AWS::WAFv2::WebACL' else
                'SCOPE_DEPENDS_ON_EXACT_WAF_REGIONAL_OR_CLOUDFRONT_IDENTITY' if t=='AWS::WAFv2::WebACL' else
                'GLOBAL_AURORA_EXCEPTION' if t=='AWS::RDS::GlobalCluster' else
                'ACCOUNT_VIRTUAL_NOT_A_RECORDING_TYPE' if t=='AWS::::Account' else
                'GLOBAL_IAM_SERVER_CERTIFICATE_SEPARATE_TYPE' if t=='AWS::IAM::ServerCertificate' else
                'REGIONAL_CANDIDATE_CONFIRMED_ONLY_BY_EXACT_SCOPE')
            types[t]={'scope':scope,'home_scope':homes.get(t),'reference_line':reference.get(t),
                      'coverage_line':coverage.get(t,{}).get('line'),
                      'regional_coverage':{r:coverage.get(t,{}).get(r,'UNKNOWN_MISSING_EXACT_ROW') for r in REGIONS},
                      'recording_required_evidence':t in recording}
        managed_key=Path(urlsplit(link).path).stem if link else None
        doc_rule_regions={
            r: ('LISTED_PUBLIC_MANAGED_RULE' if managed_key in rules
                else 'NOT_LISTED_PUBLIC_MANAGED_RULE_NO_CSPM_INFERENCE') if managed_key
            else 'NOT_APPLICABLE_TO_CSPM_CUSTOM_OR_UNCLASSIFIED'
            for r,rules in rules_by_region.items()
        }
        unresolved=[]
        if rec_status.startswith('UNKNOWN'):
            unresolved.append(rec_status)
        if dependency.endswith('UNKNOWN'):
            unresolved.append(dependency)
        if rule_status.endswith('UNKNOWN'):
            unresolved.append(rule_status)
        if not schedule or set(schedule.lower().split(' and '))!=set(old_schedule.lower().split(' and ')):
            unresolved.append('DETAIL_CATALOG_TRIGGER_DISAGREEMENT_OR_MISSING')
        if explicit and table_types and explicit!=table_types:
            unresolved.append('DETAIL_AND_REQUIRED_RESOURCE_TABLE_DIFFER')
        missing_eval=sorted(set(eval_types)-recording-{'AWS::::Account'})
        if recording and missing_eval:
            unresolved.append('EVALUATED_RESOURCE_NOT_IN_REQUIRED_TABLE_DO_NOT_UNION_AUTOMATICALLY')
        if any(t not in coverage for t in recording):
            unresolved.append('REQUIRED_TYPE_REGIONAL_COVERAGE_ROW_MISSING')
        detail = {**src[cid], 'fields':{k:v for k,v in fields.items() if k!='requirements'}}
        rows[cid]=dict(id=cid, detail=detail, trigger=schedule or old_schedule,
             catalog_trigger=old_schedule, config_dependency=dependency,
             config_rule=dict(kind=rule_status,published_label=reported or None,aws_managed_rule_reference=link,
                              regional_public_managed_catalog=doc_rule_regions,
                              deployed_rule_name='NOT_VERIFIED; CSPM may create a service-linked rule; no independent Config writer inferred'),
             evaluated_types=eval_types, recording_types=sorted(recording), recording_status=rec_status,
             detail_only_evaluated_vs_recording=missing_eval, type_facts=types,
             required_config_table_lines=aggregate[cid], supplemental_CSPM_global_control=cid in global_controls,
             global_list_source='GLOBAL#controls-to-disable-global-resources' if cid in global_controls else None,
             recording_frequency=('Change-triggered findings can be delayed with daily; exact policy and runtime need review.'
                                  if schedule and 'change triggered' in schedule.casefold()
                                  else 'No per-control required interval established. Periodic trigger and recording cadence are different.'),
             unresolved=unresolved, explicit_account_check_cfg_note=(
                 'Combined CSPM/Unified status PASSED alone says nothing about customer recorder coverage.' if cid=='Config.1' else None))
    counts=Counter()
    for row in rows.values():
        counts['details']+=1
        counts['config_dependency:'+row['config_dependency']]+=1
        counts['rule:'+row['config_rule']['kind']]+=1
        counts['recording:'+row['recording_status']]+=1
        counts['trigger:'+row['trigger']]+=1
        counts['mapped_recording'] += bool(row['recording_types'])
        counts['original_exact_table_mapping'] += bool(row['required_config_table_lines'])
        counts['documentary_row_with_unresolved'] += bool(row['unresolved'])
    write('CONTROL_TO_CONFIG_DEPENDENCY_MATRIX.json',dict(counts=dict(counts),rows=rows,
          source_sections={'RESOURCE_RECORDING':'RECORDER#config-resource-recording','SCOPE':'config-global#select-resources-all',
                           'CONFIG_LOOKUP':'CONFIG#all-controls-config-resources',
                           'PUBLIC_MANAGED_RULE_LOOKUP':'config-managed-rules-region'}))
    return rows,homes,counts


def regional_matrix(vendor, receipts, contract, design, union, regional, config, disputes, homes):
    catalog=contract['catalogs']
    fixed=catalog['current_plan_v130']['technical_candidate_catalogs']['18']
    profile_rows={}
    expected={'R1':'ca-central-1','R2':'ca-central-1','R3':'ca-central-1','R4':'ca-central-1',
              'R5':'us-east-1','R6':'us-east-2','minimal':'ca-central-1','serverless-only':'ca-central-1'}
    inv={p['profile']:p for p in fixed['investigations_profiles']}
    for p in catalog['profiles']:
        key=p['profile_id']
        need(key not in profile_rows and p['scope']['region']==expected[key],'PROFILE_CHANGED')
        profile_rows[key]=dict(region=p['scope']['region'],env_fixture=p['scope']['environment'],
                               contract_profile=p['security_profile'],baseline_selected=p['capabilities']['security_baseline'],
                               unified_desired=p['flags']['security.securityhub_unified'],investigations=dict(inv[key]),
                               security_baseline_root=p['root_modes'].get('security-baseline'),
                               activation='BLOCKED' if p['capabilities']['security_baseline'] else 'NOT_SELECTED')
    need(profile_rows.keys()==expected.keys(),'PROFILE_CHANGED')

    region_doc=doc(vendor['cspm-regions'])
    _, b=section(region_doc,'securityhub-regions-standards-support')
    need(any('Other security standards are available in all the Regions' in text(e) for e in b),'Standard availability caveat')
    scope_facts={}
    for reg,(slug,label,rules_key) in REGIONS.items():
        canonical=set(fixed['cspm_regional_unsupported_control_ids'][reg])
        need(canonical==regional[reg].keys(),'regional contract drift '+reg)
        need(canonical==set(design['CSPM_Membership_Delta']['regional'][reg]['ids']),'regional delta drift '+reg)
        scope_facts[reg]={'standard_status':'DOCUMENTED_IN_CSPM_SUPPORTED_REGION_SUBJECT_TO_CONTROL_LIMITS',
                          'availability_sources':['cspm-regions#securityhub-regions-standards-support',
                                                  'Final Contracts Part 18 REG01',
                                                  'CSPM-CONTROLS#securityhub-control-support-'+slug],
                          'config_region_table_column':label,'config_public_rule_section':rules_key,
                          'account_observation':'NOT_TESTED','home_region_assignment':'UNKNOWN',
                          'central_or_local':'UNKNOWN',
                          'profiles':[k for k,v in profile_rows.items() if v['region']==reg]}
    rows={}
    counts={}
    blocked=[]
    for reg in REGIONS:
        output={}
        for cid in union:
            row=config[cid]
            type_info={typ:vals['regional_coverage'][reg] for typ,vals in row['type_facts'].items()
                       if vals['recording_required_evidence']}
            scope_notes=[row['type_facts'][t]['scope'] for t in type_info]
            avail=('DOCUMENTED_NOT_SUPPORTED' if cid in regional[reg] else
                   'NOT_LISTED_IN_DOCUMENTED_UNSUPPORTED_SECTION')
            global_cspm=('CENTRAL_HOME_WITH_LINKED_FALLBACK_IF_HOME_UNSUPPORTED'
                         if row['supplemental_CSPM_global_control'] else 'EXACT_RESOURCE_SCOPE_OR_RULE_MAY_STILL_RESTRICT')
            missing=[]
            if cid in disputes:
                missing.append('FSBP_PUBLICATION_DISAGREEMENT')
            missing.extend(row['unresolved'])
            if not type_info and row['config_dependency']=='CONFIG_BACKED':
                missing.append('EXACT_RECORDING_REQUIREMENTS_OPEN')
            missing.extend('RESOURCE_TYPE_UNAVAILABLE:'+t for t,v in type_info.items() if v=='DOCUMENTED_NO')
            missing.extend('RESOURCE_TYPE_COVERAGE_UNKNOWN:'+t for t,v in type_info.items() if v.startswith('UNKNOWN'))
            if avail=='DOCUMENTED_NOT_SUPPORTED' or missing:
                blocked.append(dict(region=reg,id=cid,regional_control=avail,reasons=sorted(set(missing))))
            output[cid]=dict(control=avail,control_source='CSPM-CONTROLS#securityhub-control-support-'+REGIONS[reg][0],
                             standard_availability=scope_facts[reg]['standard_status'],
                             config_recording_types=type_info,rules=row['config_rule']['regional_public_managed_catalog'][reg],
                             cspm_service_linked_rule_live_status='NOT_TESTED',
                             config_coverage_source='config-coverage#north-south-america-regions',
                             global_identity_rules=sorted(set(scope_notes)),cspm_global_behavior=global_cspm,
                             global_recording_scope_candidates={
                                 t:{'scope':v['scope'],'recording_required_evidence':v['recording_required_evidence'],
                                    'declared_type_coverage':v['regional_coverage'][reg],'fixed_service_home':v['home_scope']}
                                 for t,v in row['type_facts'].items() if v['scope'].startswith(('GLOBAL_','SCOPE_DEPENDS_'))},
                             account_prerequisites='OWNERSHIP_MATRIX_AND_EXACT_ROLE_REGION_REVIEW_REQUIRED',
                             activation='BLOCKED',missing_exact_evidence=sorted(set(missing)))
        rows[reg]=output
        counts[reg]=dict(rows=len(output),all_controls_documented_unsupported=len(regional[reg]),
                         retained_candidate_controls_documented_unsupported=sum(x in regional[reg] for x in union),
                         rows_with_exact_recording_types=sum(bool(x['config_recording_types']) for x in output.values()),
                         rows_with_all_required_type_cells_known=sum(bool(x['config_recording_types']) and
                             all(y in ('DOCUMENTED_YES','DOCUMENTED_NO') for y in x['config_recording_types'].values())
                             for x in output.values()),
                         rows_with_required_type_no=sum('DOCUMENTED_NO' in x['config_recording_types'].values() for x in output.values()))
    write('REGIONAL_CAPABILITY_MATRIX.json',dict(
        counts=counts,source_boundary='Documentation snapshots. All activations BLOCKED; missing cells/entries remain UNKNOWN. Negative-list absence alone gives no live availability. Exact profile desires retained.',
        region_context=scope_facts,by_region=rows,profiles=profile_rows,
        global_recording=dict(pre_2022_iam=sorted(IAM_GLOBAL),home_region_catalog=homes,
             aurora='RDS GlobalCluster is recorded in all supported enabled AWS Config Regions when selected; explicit exclusions required to prevent it.',
             iam_periodic='Once a pre-2022 IAM global type is recorded in one supported Region, rules can evaluate in other Regions where added; central CSPM control location is a separate concern.',
             waf='For AWS::WAFv2::WebACL resolve exact CLOUDFRONT versus REGIONAL scope. Do not apply CloudFront fixed-home constraints to regional WAF.',
             source_sections=['config-global#select-resources-all','config-global#select-resources-rules-and-global','GLOBAL#controls-to-disable-global-resources'])))
    write('EXACT_UNRESOLVED_ROWS.json',dict(
        scope='Retained union. Aggregate account/service-linked/live gate remains blocked for every row.',
        config_rows={cid: x['unresolved'] for cid,x in config.items() if x['unresolved']},
        region_specific=blocked,disputed_membership=disputes,
        approval='Separate review for any explicit exception without removing required intent.'))
    return counts


def main():
    reuse,objects=verify_inputs()
    vendor,receipts=documentation(objects)
    design=slices(objects)
    prior=objects['c-e04-cspm.json']
    historical,current=get_catalog(vendor)
    union=set(design['CSPM_Membership_Delta']['union_candidate_ids'])
    detail=details(vendor,receipts,union)
    need(detail.keys()==union,'Exact candidate detail heading coverage missing')
    scoped={}
    for i,x in detail.items():
        scoped.setdefault(x['source_id'],[]).append({'control':i,'section':x['section']})
    for n,entries in scoped.items():
        receipts[n]['section_ids']=sorted(entries,key=lambda r:r['control'])
    union,regional,membership_counts,disputes=memberships(vendor,receipts,prior,detail,historical,current,design['CSPM_Membership_Delta'])
    config,homes,config_counts=config_matrix(vendor,receipts,prior,union,detail,current)
    contract=objects[CONTRACT_NAME]
    rcounts=regional_matrix(vendor,receipts,contract,design,union,regional,config,disputes,homes)
    from governance import govern
    govern(vendor,contract,objects,design,membership_counts,config_counts,rcounts,disputes)
    write('FIXED_SOURCE_IDENTITY_AND_REUSE_MANIFEST.json',dict(
        input_identity=reuse,aws_provider='6.72.0 (fixed input; provider not executed)',
        additional_acquisitions=sum(not r.get('reused',False) for r in receipts.values()),
        reused_official_captures=sum(bool(r.get('reused')) for r in receipts.values()),
        source_version_rule='Official public documents are mutable; each receipt identifies retained bytes, not a permanent vendor version.',
        same_time_recheck={'standard_and_catalog_byte_identical_to_retained':
            vendor['FSBP']==vendor['fsbp-current'] and vendor['CONTROL_CATALOG']==vendor['catalog-current'],
            'new_membership_publication_claim':'NO_CHANGE_RECONCILED_WITH_BOUNDED_SOURCE_SNAPSHOTS'},
        raw_vendor_disposition='All snapshots remain in scratch and are excluded from public ZIP.',
        documentation=list(receipts.values())))
    print('membership',membership_counts)
    print('config',dict(config_counts))
    print('regions',rcounts)


if __name__=='__main__':
    main()
