"""Account and recorder candidate matrix and exact contract traceability."""
from sources import doc, text, write, need


def anchor(vendor, source, term, href):
    d=doc(vendor[source])
    lines=[e.sourceline for e in d.xpath('//p|//li|//h2|//h3') if term in text(e)]
    need(lines, 'missing documentary anchor '+source+'#'+href)
    return dict(source_id=source,section=href,lines=sorted(set(lines)))


def govern(vendor, contract, inputs, design, member, config, regions, disputes):
    mode = [
        ['create','ONE_APPROVED_CUSTOMER_WRITER','Exact scoped absence, identity, role and dependency review before mutation.'],
        ['existing','READ_ONLY','External resource and attributes pinned; no import, creation, update or deletion.'],
        ['disabled','NO_MUTATION','No new object or settings; preserve existing resources. Retirement requires separate explicit contract.'],
        ['service-managed','SERVICE_ONLY','Read-only from portfolio; service writer and physical identity evidenced. Internal ownership classification, not new service_modes input.'],
        ['unknown','BLOCKED','Identity, resource/attribute writer, mode or scope unknown.'],
    ]
    rows = [
       dict(case='Standalone CSPM only', central='NOT_APPLICABLE_WITHOUT_ORGANIZATIONS', config='Customer recorder and delivery prerequisites in the approved Region.',
            writer='One customer owner for recorder, recorder status, delivery channel and delivery destination attributes. Security Hub creates applicable service-linked evaluation rules.',
            condition='Bind exact account in future without inventing identity. Reuse existing only read-only and validate coverage.'),
       dict(case='Organization member, self-managed/local CSPM',central='SELF_MANAGED_LOCAL',
            config='Assess member Region and own exact recorder and delivery contract under CSPM-only mode.',
            writer='Single authorized applicable writer per resource/attribute. No central policy writer for self-managed scope.',
            condition='Document member/admin/org proof and no mutation of organizations/roles without approval.'),
       dict(case='Organization management account',central='CENTRAL_PREREQUISITE_ONLY',
            config='Recorder and channel design remains independently scoped.',
            writer='Management account designates an eligible delegated admin. The management account itself may not be that delegated admin.',
            condition='Read-only existence/applicability proof later. No creation of Organization, implicit registration or takeover.'),
       dict(case='Organization delegated administrator/Central',central='MANAGEMENT_FROM_HOME_ONLY',
            config='Verified home, linked Regions and existing recorder mode for each scoped account/Region. Enable the correct resource types under selected mode.',
            writer='One policy writer targets verified account, OU or root from Home Region; association applies in Home and all Linked Regions. Self-managed accounts work separately.',
            condition='Organizations integration and delegated admin required. No opt-in home. Confirm associations/inheritance and reject overlapping local writer or simultaneous declarative policy.'),
       dict(case='CSPM + Unified Security Hub enabled',central='LOCAL_OR_CENTRAL_REQUIRES_SEPARATE_EVIDENCE',
            config='Service-linked AWSConfigurationRecorderForSecurityHubCSPM is service-created per applicable account/Region.',
            writer='Service manages recorder resource and coverage; no portfolio enable/import/manage/delete of this recorder or its service-linked settings, role or service-managed rule.',
            condition='Neither use of existing customer recorder for other purposes nor Config.1 PASSED proves customer audit coverage, delivery channel coverage, or actual applicable controls.'),
       dict(case='Existing customer Config recorder',central='INDEPENDENT_OF_POLICY_MODE',
            config='External read-only. Inspect effective recording scopes, roles, frequency, global recording and delivery configuration later.',
            writer='Existing external writer retained. No second customer recorder/channel, adoption, importer, start/stop, policy mutation or deletion.',
            condition='Coverage gaps or unknown ownership block operations. No default backfill or ownership inference.'),
       dict(case='Customer delivery channel and role',central='INDEPENDENT_OF_CSPM_CONTROL_POLICY',
            config='Model channel, recorder, status, IAM role/service-linked role, destination, policy and encryption as separate physical identities and managed attributes.',
            writer='Exactly one owner per resource/attribute. Existing roles/channels read-only; service-linked role remains service-owned. Follow X04 key history/retention and exact grant rules.',
            condition='No duplicate channel or inferred customer delivery from service-linked recorder. Require typed identity and destination, compatible scoped permissions, regional applicability and explicit audit delivery proof.'),
       dict(case='Security Lake or Unified-only scope',central='FEATURE_IDENTITIES_DISTINCT',
            config='CSPM standards membership applies to CSPM. Unified exposure/attack paths are separate REG02. Security Lake native sources are separate REG09.',
            writer='Preserve producer identity, S3/Glue/Lake resources and writers separately. CSPM/Unified mode does not create Security Lake or an Organization.',
            condition='REG09 CloudTrail management source needs eligible multi-Region organization trail with read/write management events. If absent, required source is blocked; S3/Lambda data sources have independent contracts.'),
    ]
    source = [
       anchor(vendor,'central-start','Organizations management account cannot be set','orgs-integration-prereq'),
       anchor(vendor,'central-start','home Region cannot be a Region','home-region-prereq'),
       anchor(vendor,'central-policy',"can't use declarative policies and central configuration",'configuration-policies-overview'),
       anchor(vendor,'central-assoc','associate','create-associate-policy'),
       anchor(vendor,'GLOBAL',"isn't supported in the home Region",'controls-to-disable-global-resources'),
       anchor(vendor,'RECORDER','AWSConfigurationRecorderForSecurityHubCSPM','service-linked-config-recorder'),
       anchor(vendor,'RECORDER','always has a status of PASSED','config-1-overview'),
       anchor(vendor,'RECORDER','service-linked rules','securityhub-standards-generate-awsconfigrules'),
    ]
    write('ACCOUNT_RECORDER_OWNERSHIP_MATRIX.json',dict(
        approval='DESIGN_CANDIDATE_ONLY', mode_matrix=mode, scenario_rows=rows,
        physical_identity=['partition','account_scope_ref','resource_region_or_GLOBAL','resource_type','physical_resource_identity','managed_attribute'],
        prohibitions=['No existing mutation, no implicit import/delete, no Organization creation.',
                      'Feature labels or project/environment aliases do not split physical account ownership.',
                      'Desired profile or Standard selection never authorizes mutation or suppresses unresolved controls.'],
        account_organization_home_linked_mode='UNKNOWN / NO AUTHENTICATED ACCOUNT DISCOVERY',
        design_compare=['REV6_B04_CSPM_Membership_Delta recorder rule','REV6_B04_B05_Consolidated_Design_Record REG01/REG02/REG09',
                        'X03-REC-01, X04 unchanged'], source=source,
        newly_confirmed_constraint='CSPM declarative policies and central configuration are mutually exclusive per AWS. Exact current management mode and compatibility must be evidenced; this task adopts neither.'))

    inherited=design['CSPM_Membership_Delta']
    scope=contract['catalogs']['current_plan_v130']
    write('EXISTING_DESIGN_DELTA_COMPARISON.json',dict(
        REG01=dict(prior=inherited['counts'],current_memberships=member,current_mapping=dict(config),
                   region_stats=regions,prior_unresolved_publication_disagreement=disputes,disposition='PARTIAL_HOLD',
                   notes=['Rechecked same FSBP membership page and same catalog bytes. Keep all 386 safety-side IDs.',
                          'Use explicit recording fields or exact control-to-required-type table. Standard-wide resource aggregates never serve as per-control data.',
                          'The v5 mapping table omits S3.22/S3.23. Fixed detailed pages supply v5/3.8 and v5/3.9.',
                          'Detailed rule declarations and published independent AWS Config rule regional lists do not prove service-linked rule creation or exact provider state.']),
        REG02=dict(disposition='UNCHANGED_OPEN_FEATURE_REGIONAL_MATRIX',notes='Unified enablement and exposure capability outside WP-01 closure.'),
        REG09=dict(disposition='UNCHANGED_SOURCE_CONDITIONAL',notes='Separate Security Lake prerequisite retained.'),
        retained_design_records=sorted(v['decision_id'] for v in design.values() if isinstance(v,dict) and 'decision_id'in v),
        investigations='OD-R6-01 unchanged; Canada R1-R4 fail closed; R5/R6 remain conditional. No new Regions/profiles or optional features.'))

    packets=inputs['Revision6_Final_Codex_Task_Packets.json']['fu_packets']
    relevant_fields=[f for f in scope['fields'] if f['root']=='security-baseline' and f['field']=='securityhub_standards']
    need(len(relevant_fields)==1,'securityhub standards typed input')
    f=relevant_fields[0]
    cross=[x for x in design['X01_X04_Implementation_Obligations']['original_cross_contracts'] if x['id'] in ('X01','X03','X04')]
    x_review=[x['id'] for x in design['Contract_Review_02']['cases'] if x['id'].startswith(('X03-OWN-','X04-KEY-'))]
    trace=[x for x in inputs['Revision6_Final_Traceability.json']['findings'] if x['id'] in ('AUD-22','AUD-69','AUD-78','G3-007')]
    need(len(trace)==4,'fixed witness IDs')
    write('AFFECTED_FINAL_CONTRACT_WITNESS_MAPPING.json',dict(
        technical_acceptance='OPEN_ALL_120', governing_contracts=['SEC-01','PRF-01','DAG-01','IFC-01'],
        typed_inputs=[
           dict(name='securityhub_standards',position='security-baseline root',scoped_issue=f['condition'],
                evidence=f['required_evidence'],gate=f['gate'],state='OPEN_EVIDENCE'),
           dict(name='service_modes',allowed_modes=['create','existing','disabled'],source='OD-R02 / S3-S4 packet',
                condition='Service managed is a separate ownership classification, never a change to the typed enum.'),
           dict(name='profile-v2 / scope-v3',required=['project','environment','partition','account_id','region'],
                condition='Passive fixed fixtures only; no alteration, actual identity inventory or scope inference.')],
        packets=[dict(id=x['id'],pr=x['pr'],contract=x['contracts'],purpose=x['purpose'],start=x['start']) for x in packets if x['id'] in ('S3','S4')],
        int00=[dict(id=x['id'],gate=x['gate'],contract=x['rev6_contracts'],status='OPEN') for x in cross],
        contract_review_case_ids=x_review,
        supplemental_obligation='X03-REC-01',
        traceability=[dict(id=x['id'],fu=x['fu'],tests=x['tests'],witness=x['witness_v07'],remaining=x['remaining'],
                           technical_acceptance='OPEN') for x in trace],
        x04_boundary='Existing encryption, grant/writer ownership and key history unchanged. No exception added.',
        subsequent_witnesses=['Exact service/standard/control definitions and account scope under later authorization',
             'Effective Config recorder/resource-type/Region/delivery audit in each approved scope',
             'Physical writer registry and reviewed positive/negative plan witnesses for S3/S4',
             'Account prerequisites, approved version/selection and launch gate; exact provider 6.72.0 witness open',
             'M1 acceptance, EXA-05 and OD-HO-06 before any implementation.']))
