"""Targeted fail-closed qualification cases; no account access or runtime claims."""
from pathlib import Path
import sys
import re
from sources import bounded_table, doc, parse_membership, read, write

F='FSBP-1.0.0'
C='CIS-5.0.0'
REGION='ca-central-1'
SYNTHETIC_CATALOG={F: {'Shared.1','Fsbp.2'}, C:{'Shared.1','Cis.3'}}
MEMBER_END='</p><h2 id="next">Next</h2></div></body></html>'
MEMBER_START='<html><body><div><h2 id="members">Members</h2><p>'
SOURCE='https://fixture.example.invalid/'


def check_membership(standard, requested, allowed):
    if standard not in (F,C):
        return 'WRONG_STANDARD'
    if len(requested)!=len(set(requested)):
        return 'DUPLICATE_CONTROL'
    if set(requested)!=allowed[standard]:
        return 'UNKNOWN_CONTROL'
    return 'PASS_STATIC'


def check_regional(control, coverage, dependency, *, iam=True, home=True):
    if control=='unsupported':
        return 'CONTROL_UNSUPPORTED'
    if control!='documented':
        return 'REGION_UNKNOWN'
    if dependency!='known':
        return 'DEPENDENCY_UNKNOWN'
    if not iam:
        return 'GLOBAL_IAM_UNSUPPORTED'
    if not home:
        return 'GLOBAL_HOME_MISMATCH'
    if coverage!='yes':
        return 'RESOURCE_TYPE_UNAVAILABLE'
    return 'PASS_STATIC'


def check_owner(product, mode, operation, writers, *, organization=True, known=True):
    if product!='CSPM':
        return 'WRONG_PRODUCT'
    if not organization:
        return 'ORGANIZATION_REQUIRED'
    if not known:
        return 'OWNERSHIP_UNKNOWN'
    if len(writers)!=1:
        return 'MULTIPLE_WRITERS'
    if mode=='existing' and operation!='read':
        return 'EXISTING_READ_ONLY'
    if mode=='service-managed' and operation!='read':
        return 'SERVICE_WRITER_ONLY'
    if mode=='disabled' and operation=='delete':
        return 'DISABLED_NO_DELETE'
    return 'PASS_STATIC'


def check_scope(*, silent_disable=False, profile_changed=False, membership_basis='standard'):
    if silent_disable:
        return 'UNAPPROVED_DISABLE'
    if profile_changed:
        return 'PROFILE_CHANGED'
    if membership_basis!='standard':
        return 'MEMBERSHIP_UNPROVEN'
    return 'PASS_STATIC'


def parse_links(fragment, expected):
    return parse_membership(doc(fragment.encode()),'members',SOURCE,expected)


def observation(call):
    try:
        result=call()
        return result if isinstance(result,str) else 'PASS_STATIC'
    except ValueError as e:
        return str(e)


def real_membership():
    fsbp=read('FSBP_MEMBERSHIP_INVENTORY.json')
    cis=read('CIS_5_0_0_MEMBERSHIP_INVENTORY.json')
    union=read('DEDUPLICATED_CONTROL_UNION.json')
    delta=read('EXACT_UNRESOLVED_ROWS.json')
    region=read('REGIONAL_CAPABILITY_MATRIX.json')
    ids=set(fsbp['control_ids_in_standard_section']) | set(cis['control_ids_in_standard_section'])
    result_rows={r['id'] for r in union['rows']}
    same=(len(fsbp['control_ids_in_standard_section'])==368 and len(cis['control_ids_in_standard_section'])==40
          and len(ids)==383 and len(result_rows)==len(union['rows'])==386
          and result_rows-ids=={'Cognito.1','RDS.38','RDS.39'}
          and set(delta['disputed_membership'])=={'Cognito.1','RDS.38','RDS.39','CloudTrail.2'}
          and all(set(rows)==result_rows for rows in region['by_region'].values())
          and all(r['activation']=='BLOCKED' for r in union['rows']))
    return 'PASS_STATIC' if same else 'ROW_IDENTITY_CHANGED'


def main():
    bad1='<a href="a">[Fsbp.2] Original</a>'
    bad2='<a href="b">[Fsbp.2] Conflicting</a>'
    replaced='<a href="a">[Fsbp.3] Wrong identity</a>'
    expected=read('EXPECTED_FIXTURE_MANIFEST.json')['cases']
    cases={
      'M01_FSBP_EXACT':lambda:check_membership(F,['Shared.1','Fsbp.2'],SYNTHETIC_CATALOG),
      'M02_CIS5_EXACT':lambda:check_membership(C,['Cis.3','Shared.1'],SYNTHETIC_CATALOG),
      'M03_WRONG_CIS_VERSION':lambda:check_membership('CIS-3.0.0',['Shared.1'],SYNTHETIC_CATALOG),
      'M04_SHARED_DEDUP':lambda:'PASS_STATIC' if SYNTHETIC_CATALOG[F]|SYNTHETIC_CATALOG[C]=={'Fsbp.2','Shared.1','Cis.3'} else 'ROW_IDENTITY_CHANGED',
      'M05_UNKNOWN_CONTROL':lambda:check_membership(F,['Shared.1','Fsbp.4'],SYNTHETIC_CATALOG),
      'M06_CONFLICTING_DUPLICATE':lambda:parse_links(MEMBER_START+bad1+bad2+MEMBER_END,{'Fsbp.2'}),
      'R01_UNSUPPORTED_CONTROL':lambda:check_regional('unsupported','yes','known'),
      'R02_UNKNOWN_REGION':lambda:check_regional('unknown','yes','known'),
      'R03_RESOURCE_ABSENT':lambda:check_regional('documented','no','known'),
      'R04_DEPENDENCY_UNKNOWN':lambda:check_regional('documented','yes','unknown'),
      'R05_GLOBAL_IAM_UNSUPPORTED':lambda:check_regional('documented','yes','known',iam=False),
      'R06_OTHER_GLOBAL_WRONG_HOME':lambda:check_regional('documented','yes','known',home=False),
      'O01_ORG_REQUIRED':lambda:check_owner('CSPM','create','create',['candidate'],organization=False),
      'O02_EXISTING_MUTATION':lambda:check_owner('CSPM','existing','update',['external']),
      'O03_MULTIPLE_WRITERS':lambda:check_owner('CSPM','create','create',['owner1','owner2']),
      'O04_DISABLED_DELETE':lambda:check_owner('CSPM','disabled','delete',['external']),
      'O05_WRONG_PRODUCT':lambda:check_owner('Unified Security Hub','existing','read',['external']),
      'O06_SERVICE_MANAGED_CUSTOMER_WRITE':lambda:check_owner('CSPM','service-managed','update',['service']),
      'O07_UNKNOWN_OWNER':lambda:check_owner('CSPM','existing','read',['external'],known=False),
      'O08_CREATE_REVIEWED':lambda:check_owner('CSPM','create','create',['candidate']),
      'G01_SILENT_DISABLE':lambda:check_scope(silent_disable=True),
      'G02_UNAPPROVED_PROFILE_CHANGE':lambda:check_scope(profile_changed=True),
      'G03_NEGATIVE_LIST_INFERENCE':lambda:check_scope(membership_basis='not-in-regional-deny-list'),
      'P01_INCOMPLETE_SECTION':lambda:parse_links(MEMBER_START+bad1,{'Fsbp.2'}),
      'P02_UNCLOSED_TABLE':lambda:bounded_table(b'<table><tr><td>x</td></tr>'),
      'P03_ROW_IDENTITY_LOSS':lambda:parse_links(MEMBER_START+replaced+MEMBER_END,{'Fsbp.2'}),
      'P04_REAL_RETAINED_SOURCES':real_membership,
    }
    actual={k:observation(run) for k,run in cases.items()}
    summary=dict(total=len(expected),passed=sum(actual.get(k)==v for k,v in expected.items()),
                 rows=[dict(case=k,expected=expected[k],actual=actual.get(k),passed=actual.get(k)==expected[k]) for k in sorted(expected)],
                 scope='Offline synthetic predicates and real retained-document parsing only. AWS, provider, effective account/state and authorization not tested.')
    write(sys.argv[1],summary)
    if expected!=actual:
        raise SystemExit('Unexpected fixture result or coverage')

if __name__=='__main__':
    main()
