"""Run successor fixtures and the applicable original regressions without parsing vendor pages."""
from dataclasses import replace
from pathlib import Path
import hashlib
import json
import sys

from ownership import (Mode as M, Operation as O, Management as G, Organization as Org,
                       Role, OwnerType, ManagementContext as Context, Target, Writer, check_owner)
sys.path.insert(0, str(Path('original-verifier').resolve()))
import fixtures as original


def load(path):
    return json.loads(Path(path).read_bytes())


T = Target('aws', 'fixture-scope', 'ca-central-1', 'customer-recorder', 'fixture-recorder', 'recording')
W = Writer(T, 'fixture-owner', OwnerType.CUSTOMER)
S = replace(W, classification=OwnerType.SERVICE)
CENTRAL = Context((G.CENTRAL,), Org.IN_ORGANIZATION, Role.DELEGATED, True, True)
DECLARATIVE = Context((G.DECLARATIVE,), Org.IN_ORGANIZATION, Role.MANAGEMENT,
                      declarative_scope_and_access_verified=True)


def owner(mode=M.CREATE, op=O.CREATE, *, writers=(W,), target=T, context=Context(), known=True,
          product='CSPM', grant=True):
    return check_owner(product, mode, op, target, writers, context=context, owner_known=known,
                       synthetic_write_grant=(T, W.principal, op) if grant else None)


def legacy_owner(product, mode, operation, writers, *, organization=True, known=True):
    context = Context() if organization else replace(CENTRAL, organization=Org.STANDALONE)
    mapped = tuple(Writer(T, x, OwnerType.SERVICE if mode=='service-managed' else OwnerType.CUSTOMER) for x in writers)
    selected = M.EXISTING if mode=='service-managed' else M(mode)
    op = O(operation)
    grant = (T, 'candidate', op) if writers == ['candidate'] else None
    return check_owner(product, selected, op, T, mapped, context=context, owner_known=known,
                       synthetic_write_grant=grant)


def main():
    tests = {
        **{'D_'+op.name: owner(M.DISABLED, op) for op in O},
        'L_STANDALONE':owner(), 'L_MEMBER':owner(context=Context(organization=Org.IN_ORGANIZATION)),
        'L_ORG_UNKNOWN':owner(context=Context(organization=Org.UNKNOWN)),
        'C_NO_ORG':owner(context=replace(CENTRAL, organization=Org.STANDALONE)),
        'P_NO_ORG':owner(context=replace(DECLARATIVE, organization=Org.STANDALONE)),
        'CP_BOTH':owner(context=Context((G.CENTRAL,G.DECLARATIVE))),
        'C_ORG_UNKNOWN':owner(context=replace(CENTRAL, organization=Org.UNKNOWN)),
        'P_ORG_UNKNOWN':owner(context=replace(DECLARATIVE, organization=Org.UNKNOWN)),
        'C_VALID':owner(context=CENTRAL), 'C_WRONG_ROLE':owner(context=replace(CENTRAL,role=Role.MANAGEMENT)),
        'C_HOME_MISSING':owner(context=replace(CENTRAL,home_and_linked_scope_verified=False)),
        'P_MANAGEMENT_VALID':owner(context=DECLARATIVE),
        'P_DELEGATED_NO_GRANT':owner(context=replace(DECLARATIVE,role=Role.DELEGATED)),
        'P_DELEGATED_VALID':owner(context=replace(DECLARATIVE,role=Role.DELEGATED,declarative_delegation_verified=True)),
        'T_BAD_MODE':owner('service-managed'), 'T_BAD_OP':owner(op='patch'),
        'T_BAD_PAIR':owner(op=O.IMPORT), 'T_BAD_MGMT':owner(context=Context(('unknown',))),
        'T_UNKNOWN_RESOURCE':owner(target=replace(T,physical_id='unknown')),
        'T_UNKNOWN_OWNER':owner(known=False), 'T_DUP_PHYSICAL':owner(writers=(W,replace(W,principal='other'))),
        'T_WRONG_ATTRIBUTE':owner(target=replace(T,attribute='delivery')),
        'T_CROSS_SCOPE':owner(target=replace(T,account_ref='other-scope')),
        'T_WRITER_UNAPPROVED':owner(grant=False), 'T_WRONG_PRODUCT':owner(product='Unified Security Hub'),
        'T_SERVICE_MUTATION':owner(M.EXISTING,O.UPDATE,writers=(S,)),
        'T_SERVICE_READ':owner(M.EXISTING,O.READ,writers=(S,),grant=False),
        'T_SERVICE_WRITER':owner(M.EXISTING,O.READ,writers=(replace(S,principal='unknown'),),grant=False),
        'T_EXISTING_MUTATION':owner(M.EXISTING,O.DELETE), 'T_CREATE_VALID':owner(),
    }
    historical_manifest = load('original-verifier/EXPECTED_FIXTURE_MANIFEST.json')['cases']
    expected = load('EXPECTED_FIXTURE_MANIFEST.json')
    successor = expected['historical_successor_expectations']
    if historical_manifest.keys() != successor.keys() or len(successor) != 27 or len(tests) != 40:
        raise SystemExit('Fixture coverage changed')
    # Run only the original fixture entry point against the previously extracted, digest-verified
    # outputs. Its ownership callable is explicitly replaced with the successor adapter.
    original.check_owner = legacy_owner
    original.read = lambda name: {'cases': successor} if name == 'EXPECTED_FIXTURE_MANIFEST.json' else load(Path('original-verifier')/name)
    saved = sys.argv
    sys.argv = ['fixtures.py', 'historical-run.json']
    try:
        original.main()
    finally:
        sys.argv = saved
    result = load('historical-run.json')
    new_rows=[dict(case=k,expected=v,actual=tests.get(k),passed=tests.get(k)==v) for k,v in expected['new'].items()]
    actual = {'historical':result,'new':new_rows,'passed':result['passed']+sum(x['passed'] for x in new_rows),
              'total':len(successor)+len(tests), 'technical_acceptance':'OPEN'}
    Path(sys.argv[1]).write_text(json.dumps(actual,sort_keys=True,indent=2)+'\n')
    if tests != expected['new']:
        raise SystemExit('Unexpected targeted test result')

if __name__ == '__main__':
    main()
