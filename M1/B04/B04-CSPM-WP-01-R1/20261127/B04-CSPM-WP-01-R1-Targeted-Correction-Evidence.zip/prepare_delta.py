"""Byte-check original evidence and extract only explicitly scoped documentary corrections."""
from hashlib import sha256
from pathlib import Path
import json
import re
from zipfile import ZipFile
from lxml import html

PREV=Path('/workspace/scratch/b04-cspm-wp01.l4qGOu')
ARCHIVE='B04-CSPM-WP-01-Static-Contract-Evidence.zip'
PIN='857cba1c7bb17c59dbe86f6b9b7680e241ae74272e1997e467b568b59b7f543c'
POLICY='1beba6eb94197247a52718ee05d162dcda27fc6716c809f11643e683714d56e4'
CONTRACT='29a396daf7cadb9eee1f089b7ac427fcb7b7c9100f6e170ac97a3bcbd633a783'
DISPUTED={'CloudTrail.2','Cognito.1','RDS.38','RDS.39'}


def need(ok,error):
    if not ok:
        raise ValueError(error)


def hash_bytes(data):
    return sha256(data).hexdigest()


def file_bytes(path,pin,size=None):
    raw=path.read_bytes()
    need(hash_bytes(raw)==pin and (size is None or len(raw)==size),'Identity mismatch: '+path.name)
    return raw


def write(path,value):
    Path(path).write_text(json.dumps(value,indent=2,ensure_ascii=False,sort_keys=True)+'\n')


def main():
    base=PREV/'remote'/ARCHIVE
    raw=file_bytes(base,PIN,151207)
    del raw
    p=next(Path('/workspace/attachments').glob('*/AWS_Terraform_Portfolio_MASTER_POLICY_20261127_v15_2.pdf'))
    root=Path('/workspace/scratch/x01-x04-offline.r0JRat/input')
    pinned={
        p:POLICY, root/'original/Revision6_Final_Contracts.json':CONTRACT,
        next(root.rglob('REV6_B04_CSPM_Membership_Delta_20261127.json')):'4846acc12c853b300d0c2d508f615934ba24a0e4af1ac07af52ddda893ea7ff4',
        next(root.rglob('REV6_B04_B05_Design_Delta_20261127.json')):'5d4444972c86836088aa164eac4894afa310aab383f85097fa2da4bdacbd9e42',
        next(root.rglob('REV6_X01_X04_Implementation_Obligations_20261127.json')):'8e72a95318b3811a03bb57b8b7be194f8ebb7e0cb6f398f7169c9205d1f94b4c'}
    pinned_rows=[dict(path=str(path),sha256=pin,size_bytes=len(file_bytes(path,pin))) for path,pin in pinned.items()]
    stage=Path('original-verifier')
    stage.mkdir(exist_ok=True)
    with ZipFile(base) as z:
        names=set(z.namelist())
        need(len(names)==len(z.namelist())==26 and z.testzip() is None,'Original CRC')
        sums=dict(line.split('  ',1)[::-1] for line in z.read('SHA256SUMS').decode().splitlines())
        need(set(sums)==names-{'SHA256SUMS'} and all(hash_bytes(z.read(n))==v for n,v in sums.items()),'Original ZIP checksums')
        m=json.loads(z.read('MANIFEST.json'))['files']
        need(len(m)==24 and {x['path'] for x in m}==names-{'MANIFEST.json','SHA256SUMS'},'Original manifest')
        need(all(len(z.read(x['path']))==x['size_bytes'] and hash_bytes(z.read(x['path']))==x['sha256'] for x in m),'Original member identity')
        required=('fixtures.py','sources.py','EXPECTED_FIXTURE_MANIFEST.json','FSBP_MEMBERSHIP_INVENTORY.json',
                  'CIS_5_0_0_MEMBERSHIP_INVENTORY.json','DEDUPLICATED_CONTROL_UNION.json','REGIONAL_CAPABILITY_MATRIX.json',
                  'EXACT_UNRESOLVED_ROWS.json')
        for n in required:
            (stage/n).write_bytes(z.read(n))
        source_index={x['id']:x for x in json.loads(z.read('FIXED_SOURCE_IDENTITY_AND_REUSE_MANIFEST.json'))['documentation']}
        prior_tests=json.loads(z.read('ACTUAL_STATIC_RESULTS.json'))
        need(prior_tests['passed']==prior_tests['total']==27,'Original results')
        union=json.loads(z.read('DEDUPLICATED_CONTROL_UNION.json'))
        ids={x['id'] for x in union['rows']}
        regional=json.loads(z.read('REGIONAL_CAPABILITY_MATRIX.json'))['by_region']
        need(len(ids)==386 and len(regional)==3 and all(set(v)==ids for v in regional.values()),'Original row identity')
        need(set(union['publication_differences'])==DISPUTED,'Original disputes')
        matrix=json.loads(z.read('CONTROL_TO_CONFIG_DEPENDENCY_MATRIX.json'))['rows']
        reused=[dict(path=n,sha256=hash_bytes(z.read(n)),size_bytes=len(z.read(n))) for n in
                sorted(set(required)|{'ACTUAL_STATIC_RESULTS.json','CONTROL_TO_CONFIG_DEPENDENCY_MATRIX.json','FIXED_SOURCE_IDENTITY_AND_REUSE_MANIFEST.json'})]
    write('ORIGINAL_EVIDENCE_REUSE_MANIFEST.json',dict(
        zip=dict(name=ARCHIVE,sha256=PIN,size_bytes=151207,commit='afb4ad5ee73f78bbc2fc769e6e9365b0f0b1ac97',
                 repository_relative_path='M1/B04/B04-CSPM-WP-01/20261127/'+ARCHIVE,entries=26,acceptance='LIMITED_ACCEPTANCE'),
        members=reused,pinned_design_inputs=pinned_rows,original_fixture_count=27,
        membership_id_count=386,regional_id_count=sum(map(len,regional.values())),
        methodology='Verify frozen output digests and identity only. No prior qualification, parser or original fixture file edited.'))
    new={x['id']:x for x in json.loads(Path('retrieval.json').read_bytes())}
    register=[]
    documents={}
    retained=['CONFIG','detail-workspaces-controls','config-reference','detail-servicecatalog-controls','CONTROL_CATALOG',
              'central-intro','central-start']
    for key in [*retained,*new]:
        reused_source=key in retained
        row=(source_index if reused_source else new)[key]
        path=Path(row['path'])
        if reused_source:
            path=(Path('/workspace') if row['reused'] else PREV)/path
        size=row.get('size_bytes',row.get('size'))
        b=file_bytes(path,row['sha256'],size)
        documents[key]=html.fromstring(b,parser=html.HTMLParser(no_network=True))
        register.append(dict(id=key,url=row['url'],size_bytes=size,sha256=row['sha256'],path=str(path),
                             retrieval_utc=row['retrieval_utc'],http=row['http'],reused=reused_source,
                             redistribution='WITHHELD_VENDOR_DOCUMENT_BYTES'))
    def txt(e):
        return ' '.join(e.text_content().split())

    def find(key, xpath, predicate):
        matches=[x.sourceline for x in documents[key].xpath(xpath) if predicate(txt(x))]
        need(matches,'Missing targeted anchor: '+key)
        return dict(source_id=key,lines=sorted(set(matches)))

    old_type='AWS::WorkSpaces::WorkSpace'
    canonical='AWS::WorkSpaces::Workspace'
    rec=find('CONFIG','//tr[td]',lambda s:old_type in s and all(x in s for x in ('WorkSpaces.1','WorkSpaces.2')))
    ref=find('config-reference','//td',lambda s:s==canonical)
    root_rule=find('workspaces-root','//p',lambda s:s=='Resource Types: '+canonical)
    user_rule=find('workspaces-user','//p',lambda s:s=='Resource Types: '+canonical)
    ws=[]
    for cid,rule in [('WorkSpaces.1',user_rule),('WorkSpaces.2',root_rule)]:
        row=matrix[cid]
        need(row['recording_types']==[old_type] and row['evaluated_types']==[canonical],cid)
        ws.append(dict(id=cid,original_recording=old_type,canonical_candidate=canonical,
                       detail_evaluated=canonical,detail_section=row['detail']['section'],
                       original_recording_source=rec,resource_reference=ref,managed_rule=rule,
                       decision='Evidence-supported spelling normalization for a documentation join only.',
                       exact_cspm_recording='OPEN; preserve vendor spelling in historical record; verify requirement and effective recorder behavior later.',
                       runtime='NOT_TESTED'))
    write('WORKSPACES_CANONICAL_TYPE_DELTA.json',ws)
    sc=matrix['ServiceCatalog.1']
    need(sc['trigger']=='Change triggered' and sc['catalog_trigger']=='Periodic','ServiceCatalog prior identity')
    write('SERVICECATALOG_TRIGGER_CONFLICT.json',dict(id='ServiceCatalog.1',
        detail=dict(value=sc['trigger'],section=sc['detail']['section'],
                    **find('detail-servicecatalog-controls','//p',lambda s:s=='Schedule type: Change triggered')),
        catalog=dict(value=sc['catalog_trigger'],**find('CONTROL_CATALOG','//tr',lambda s:s.startswith('ServiceCatalog.1 ') and s.endswith('Periodic'))),
        public_managed_rule=dict(value='Configuration changes',**find('servicecatalog-rule','//p',lambda s:s=='Trigger type: Configuration changes')),
        effective_service_linked_schedule='UNKNOWN / NOT_TESTED',verdict='DOCUMENTARY_CONFLICT_RETAINED'))
    history=find('history','//tr[td]',lambda s:'December 17, 2024' in s and all(x in s for x in DISPUTED-{'CloudTrail.2'}))
    write('MEMBERSHIP_DISCREPANCY_SUPPLEMENT.json',dict(disputed=sorted(DISPUTED),candidate_count=386,
        regional_id_count=1158,release_evidence=dict(date='2024-12-17',ids=sorted(DISPUTED-{'CloudTrail.2'}),**history),
        disposition='Release history confirms those launches. Current FSBP membership remains disputed for all four IDs. No retirement, removal or disable inferred.'))
    management=[
        find('accounts','//p',lambda s:'if you have a standalone account' in s),
        find('policy-modes','//p',lambda s:'mechanisms are mutually exclusive' in s),
        find('central-start','//p',lambda s:'must integrate Security Hub CSPM and Organizations' in s),
        find('central-start','//p',lambda s:'management account cannot be set' in s),
        find('central-intro','//p',lambda s:'Self-managed accounts can configure' in s)
    ]
    write('FIXED_SOURCE_IDENTITY_REGISTER.json',dict(captures=register,exclusion='Vendor documents retained in Scratch. Only derived factual records and project-written source are published.',
          management_anchors=management,documents_are_mutable=True))


if __name__=='__main__':
    main()
