"""Synthetic X03 predicate. Inputs represent reviewed fixture facts only."""
from dataclasses import dataclass
from enum import Enum


class Mode(str, Enum):
    CREATE = 'create'
    EXISTING = 'existing'
    DISABLED = 'disabled'


class Operation(str, Enum):
    READ = 'read'
    NOOP = 'noop'
    CREATE = 'create'
    UPDATE = 'update'
    DELETE = 'delete'
    IMPORT = 'import'
    ADOPT = 'adopt'
    REPLACE = 'replace'
    ACTIVATE = 'activate'
    RETIRE = 'retire'


class Management(str, Enum):
    LOCAL = 'local'
    CENTRAL = 'central'
    DECLARATIVE = 'declarative'


class Organization(str, Enum):
    STANDALONE = 'standalone'
    IN_ORGANIZATION = 'in-organization'
    UNKNOWN = 'unknown'


class Role(str, Enum):
    LOCAL = 'local-account'
    MANAGEMENT = 'organization-management'
    DELEGATED = 'delegated-admin'


class OwnerType(str, Enum):
    CUSTOMER = 'customer'
    EXTERNAL = 'external'
    SERVICE = 'service-managed'


@dataclass(frozen=True)
class Target:
    partition: str
    account_ref: str
    resource_region: str
    resource_type: str
    physical_id: str
    attribute: str


@dataclass(frozen=True)
class Writer:
    target: Target
    principal: str
    classification: OwnerType


@dataclass(frozen=True)
class ManagementContext:
    selections: tuple = (Management.LOCAL,)
    organization: Organization = Organization.STANDALONE
    role: Role = Role.LOCAL
    cspm_integration: bool = False
    home_and_linked_scope_verified: bool = False
    declarative_scope_and_access_verified: bool = False
    declarative_delegation_verified: bool = False


def check_management(context):
    selections = context.selections
    if not selections or any(not isinstance(x, Management) for x in selections):
        return 'MANAGEMENT_MODE_UNKNOWN'
    if len(selections) != 1:
        return 'MANAGEMENT_CONFLICT'
    mode = selections[0]
    if mode is Management.LOCAL:
        return None if context.role is Role.LOCAL else 'MANAGEMENT_ROLE_INVALID'
    if context.organization is Organization.UNKNOWN or not isinstance(context.organization, Organization):
        return 'ORGANIZATION_UNKNOWN'
    if context.organization is Organization.STANDALONE:
        return 'ORGANIZATION_REQUIRED'
    if mode is Management.CENTRAL:
        if context.role is not Role.DELEGATED or context.cspm_integration is not True:
            return 'MANAGEMENT_ROLE_INVALID'
        if context.home_and_linked_scope_verified is not True:
            return 'MANAGEMENT_SCOPE_UNKNOWN'
        return None
    if context.role is not Role.MANAGEMENT and not (
        context.role is Role.DELEGATED and context.declarative_delegation_verified is True
    ):
        return 'MANAGEMENT_ROLE_INVALID'
    if context.declarative_scope_and_access_verified is not True:
        return 'MANAGEMENT_SCOPE_UNKNOWN'
    return None


def known(value):
    return isinstance(value, str) and bool(value.strip()) and value.strip().casefold() not in {'unknown', 'pending'}


def check_owner(product, mode, op, target, writers, *, context=ManagementContext(), owner_known=True,
                synthetic_write_grant=None):
    if product != 'CSPM':
        return 'WRONG_PRODUCT'
    if not isinstance(mode, Mode):
        return 'MODE_UNKNOWN'
    if not isinstance(op, Operation):
        return 'OPERATION_UNKNOWN'
    management_issue = check_management(context)
    if management_issue:
        return management_issue
    if not isinstance(target, Target) or not all(known(v) for v in vars(target).values()):
        return 'PHYSICAL_IDENTITY_UNKNOWN'
    matching = [w for w in writers if w.target == target]
    if len(matching) > 1:
        return 'MULTIPLE_WRITERS'
    if owner_known is not True or not matching or not known(matching[0].principal) or not isinstance(matching[0].classification, OwnerType):
        return 'OWNERSHIP_UNKNOWN'
    writer = matching[0]
    if op in (Operation.READ, Operation.NOOP):
        return 'PASS_STATIC'
    if mode is Mode.DISABLED:
        return 'DISABLED_MUTATION'
    if writer.classification is OwnerType.SERVICE:
        return 'SERVICE_WRITER_ONLY'
    if mode is Mode.EXISTING:
        return 'EXISTING_READ_ONLY'
    if op not in (Operation.CREATE, Operation.UPDATE):
        return 'UNSUPPORTED_MODE_OPERATION'
    if writer.classification is not OwnerType.CUSTOMER or synthetic_write_grant != (target, writer.principal, op):
        return 'AUTHORIZATION_REQUIRED'
    return 'PASS_STATIC'
