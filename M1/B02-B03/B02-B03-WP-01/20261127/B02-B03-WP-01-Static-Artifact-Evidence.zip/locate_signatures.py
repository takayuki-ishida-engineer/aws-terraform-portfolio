"""Locate legacy Cosign signature manifest tags without retrieving blobs."""

from pathlib import Path
import json
from acquire import BASE, INDEX, MANIFEST, Unavailable, fetch, public_session, write_json

PUB = "https://raw.githubusercontent.com/aws/karpenter-provider-aws/v1.15.2/"
PUBLISHER_FILES = {
    "publisher-release-workflow.yaml": ".github/workflows/release.yaml",
    "publisher-Makefile": "Makefile",
    "publisher-release-script.sh": "hack/release/release.sh",
    "publisher-common-script.sh": "hack/release/common.sh",
}


def main():
    d = json.loads(Path("acquisition-results.json").read_bytes())
    token = public_session("legacy-signature-registry")
    state = {}
    for key, repo, field in (("A", "karpenter", "manifest"), ("B", "karpenter-crd", "manifest"),
                             ("C", "controller", "index")):
        digest = d["tracks"][key][field]["digest"]
        reference = digest.replace(":", "-", 1) + ".sig"
        url = f"{BASE}/v2/karpenter/{repo}/manifests/{reference}"
        try:
            _, receipt = fetch(url, f"{repo}.legacy-signature.json", ", ".join(sorted(INDEX | MANIFEST)), token)
            state[key] = {"status": "LOCATOR_HTTP_READ", "subject": digest, "receipt": receipt,
                          "verified": False}
        except (Unavailable, ValueError):
            state[key] = {"status": "DISCOVERY_UNAVAILABLE", "url": url, "verified": False}
    write_json("signature-locators.json", state)


if __name__ == "__main__":
    main()
