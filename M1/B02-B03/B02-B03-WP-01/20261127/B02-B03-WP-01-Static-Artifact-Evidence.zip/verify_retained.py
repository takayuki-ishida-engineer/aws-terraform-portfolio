"""Recheck previously acquired OCI graph using retained files only."""
from pathlib import Path
import json
import acquire
from acquire import need, sha, write_json


def main():
    source = json.loads(Path("acquisition-results.json").read_bytes())
    acquire.RECEIPTS.extend(source["http_receipts"])
    acquire.LOCAL_ONLY = True
    actual = {
        "A": acquire.chart("karpenter", None, acquire.A),
        "B": acquire.chart("karpenter-crd", None, {}),
        "C": acquire.image(None),
    }
    need(actual == source["tracks"], "LOCAL_REPLAY_MISMATCH")
    need(len(acquire.RECEIPTS) == len(source["http_receipts"]), "UNEXPECTED_REPLAY_REQUEST")
    for row in source["http_receipts"]:
        if "path" in row:
            data = Path(row["path"]).read_bytes()
            need((sha(data), len(data)) == (row["digest"], row["size_bytes"]), "ORIGINAL_RECEIPT_MISMATCH")
    write_json("retained-verification-results.json", {
        "network_requests": 0, "tracks": actual, "byte_identity": "PASS",
        "originals_rehashed": sum("path" in r for r in source["http_receipts"]),
    })


if __name__ == "__main__":
    main()
