"""Read only the three fixed public OCI families. Never download controller layers."""

from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
from urllib.parse import urlencode, urlparse
import json
import re
import subprocess

BASE = "https://public.ecr.aws"
RELEASE = "https://api.github.com/repos/aws/karpenter-provider-aws/releases/tags/v1.15.2"
TAG = "1.15.2"
INDEX = {"application/vnd.oci.image.index.v1+json", "application/vnd.docker.distribution.manifest.list.v2+json"}
MANIFEST = {"application/vnd.oci.image.manifest.v1+json", "application/vnd.docker.distribution.manifest.v2+json"}
CHART_CONFIG = "application/vnd.cncf.helm.config.v1+json"
CHART_LAYER = "application/vnd.cncf.helm.chart.content.v1.tar+gzip"
IMAGE_CONFIG = {"application/vnd.oci.image.config.v1+json", "application/vnd.docker.container.image.v1+json"}
LAYER_TYPES = {"application/vnd.oci.image.layer.v1.tar+gzip", "application/vnd.oci.image.layer.v1.tar",
               "application/vnd.oci.image.layer.v1.tar+zstd", "application/vnd.docker.image.rootfs.diff.tar.gzip"}
A = {
    "manifest": "sha256:fe0155bd92b9c491afce246e7ec600d56e03fe8c04a2bd92becaf4c960b72c90",
    "config": "sha256:fafd648cf878b8280e96db21a4d9c5417b571709f1f852d8483f5217e2101568",
    "layer": "sha256:ba0b5e555e79abb2254e89ecea9aad318b7f2061644413003f2af045ae29dbd0",
}
C = {
    "index": "sha256:4a7dc37f85ad8987ece1cf5df55e607aa17a879a6faa76f5258c5bf182fbdfff",
    "amd64": "sha256:e724af79c6630a5633219425f4d51edb60e6f71d548e973606e786e2e604db30",
}
RAW = Path("originals")
RECEIPTS = []
LOCAL_ONLY = False


class Unavailable(Exception):
    pass


def need(condition, diagnostic):
    if not condition:
        raise Unavailable(diagnostic)


def sha(data):
    return "sha256:" + sha256(data).hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def fetch(url, name, accept=None, token=None, redirects=False):
    """Bounded GET. Secrets and raw response headers are excluded from receipts."""
    target = RAW / name
    if target.exists():
        prior = next((row for row in RECEIPTS if row.get("path") == str(target)), None)
        need(prior is not None and prior["url"] == url, "MISSING_EXISTING_RECEIPT")
        existing = target.read_bytes()
        need(len(existing) == prior["size_bytes"] and sha(existing) == prior["digest"], "EXISTING_BYTES_CHANGED")
        return existing, prior
    need(not LOCAL_ONLY, "LOCAL_REPLAY_INPUT_MISSING")
    start = datetime.now(timezone.utc).isoformat()
    args = [
        "curl", "-q", "--silent", "--show-error", "--proto", "=https", "--proto-redir",
        "=https", "--connect-timeout", "8", "--max-time", "25", "--max-filesize", "4194304",
        "--write-out", "%{stderr}RECEIPT %{http_code}\t%{http_connect}\t%{content_type}\t%{url_effective}",
    ]
    if redirects:
        args.extend(["--location", "--max-redirs", "3"])
    if accept:
        args.extend(["--header", "Accept: " + accept])
    if token:
        # curl does not forward Authorization across origins without location-trusted.
        args.extend(["--config", "-"])
    args.append(url)
    auth = f'header = "Authorization: Bearer {token}"\n'.encode() if token else b""
    result = subprocess.run(args, input=auth, capture_output=True, timeout=30, check=False)
    suffix = result.stderr.decode(errors="replace").rpartition("RECEIPT ")[2]
    parts = suffix.split("\t", 3)
    need(len(parts) == 4, "MISSING_HTTP_RECEIPT")
    origin, proxy, response_type, effective = parts
    row = {
        "target": name, "url": url, "attempted_at_utc": start,
        "http_status": int(origin), "proxy_connect_status": int(proxy),
        "curl_exit": result.returncode, "content_type": response_type.split(";")[0],
        "effective_host": urlparse(effective).hostname,
    }
    RECEIPTS.append(row)
    if result.returncode or int(origin) != 200:
        row["result"] = "HTTP_OR_TRANSPORT_UNAVAILABLE"
        return None, row
    if name.endswith(".token"):
        row["result"] = "ANONYMOUS_PUBLIC_REGISTRY_SESSION"
        return result.stdout, row
    with target.open("xb") as dst:
        dst.write(result.stdout)
    row.update(path=str(target), size_bytes=len(result.stdout), digest=sha(result.stdout),
               result="RAW_BYTES_ACQUIRED_STATIC_ONLY")
    return result.stdout, row


def public_session(repo):
    # The registry's public challenge advertised this issuer, service and scope.
    query = urlencode({"service": "public.ecr.aws", "scope": "aws"})
    body, receipt = fetch(BASE + "/token/?" + query, repo + ".token", "application/json")
    need(body is not None, f"ANONYMOUS_PUBLIC_SESSION_HTTP_{receipt['http_status']}")
    token = json.loads(body).get("token")
    need(isinstance(token, str) and re.fullmatch(r"[A-Za-z0-9+/=._-]+", token), "INVALID_TOKEN_SHAPE")
    return token


def oci(repo, route, identity, suffix, token, types=None):
    need(route in ("manifests", "blobs", "referrers"), "INVALID_OCI_ROUTE")
    need(identity == TAG or re.fullmatch(r"sha256:[0-9a-f]{64}", identity), "INVALID_OCI_IDENTITY")
    url = f"{BASE}/v2/karpenter/{repo}/{route}/{identity}"
    body, receipt = fetch(url, f"{repo}.{suffix}", ", ".join(sorted(types)) if types else None,
                          token, redirects=route == "blobs")
    need(body is not None, f"{suffix}_HTTP_{receipt['http_status']}_CONNECT_{receipt['proxy_connect_status']}")
    if identity.startswith("sha256:") and route != "referrers":
        need(sha(body) == identity, f"{suffix}_DIGEST_MISMATCH")
    return body, receipt


def descriptor(row, allowed):
    need(isinstance(row, dict), "INVALID_DESCRIPTOR")
    need(re.fullmatch(r"sha256:[0-9a-f]{64}", row.get("digest", "")) is not None
         and type(row.get("size")) is int and row["size"] > 0 and row.get("mediaType") in allowed,
         "INVALID_DESCRIPTOR_FIELDS")
    return {k: row[k] for k in ("digest", "size", "mediaType")}


def document(body, receipt, types):
    d = json.loads(body)
    # OCI mediaType is optional in the JSON document. An explicit body value
    # must agree with the negotiated OCI type; otherwise use the HTTP type.
    media_type = receipt["content_type"]
    need(d.get("schemaVersion") == 2 and media_type in types
         and d.get("mediaType", media_type) == media_type, "MANIFEST_MEDIA_TYPE_OR_SCHEMA")
    return d


def tagged_manifest(repo, token, types, expected=None):
    body, receipt = oci(repo, "manifests", TAG, "tag.json", token, types)
    identity = sha(body)
    need(expected is None or identity == expected, "TAG_PUBLISHED_DIGEST_MISMATCH")
    by_digest, pinned = oci(repo, "manifests", identity, "pinned.json", token, types)
    need(body == by_digest, "TAG_TO_PINNED_BODY_MISMATCH")
    return document(body, receipt, types), pinned


def read_blob(repo, token, desc, suffix):
    # Call sites are limited to Helm config/content and controller config.
    body, receipt = oci(repo, "blobs", desc["digest"], suffix, token)
    need(len(body) == desc["size"], suffix + "_SIZE_MISMATCH")
    accepted = {"application/octet-stream", "binary/octet-stream", desc["mediaType"]}
    need(receipt["content_type"] in accepted, suffix + "_TRANSPORT_MEDIA_TYPE_MISMATCH")
    return body, receipt


def referrers(repo, token, subject):
    try:
        url = f"{BASE}/v2/karpenter/{repo}/referrers/{subject}"
        body, receipt = fetch(url, f"{repo}.referrers-{subject[7:19]}.json", ", ".join(sorted(INDEX)), token)
        if body is None:
            return {"status": "DISCOVERY_UNAVAILABLE", "http_status": receipt["http_status"], "url": url}
        data = document(body, receipt, INDEX)
        return {"status": "DISCOVERY_ONLY", "url": url, "descriptors": [
            {k: item[k] for k in ("digest", "size", "mediaType", "artifactType") if k in item}
            for item in data["manifests"]
        ]}
    except (Unavailable, ValueError, KeyError, TypeError, AttributeError):
        return {"status": "DISCOVERY_UNVERIFIED"}


def chart(repo, token, pinned):
    data, manifest = tagged_manifest(repo, token, MANIFEST, pinned.get("manifest"))
    config = descriptor(data["config"], {CHART_CONFIG})
    need(len(data["layers"]) == 1, "CHART_LAYER_COUNT")
    layer = descriptor(data["layers"][0], {CHART_LAYER})
    if pinned:
        need((config["digest"], config["size"]) == (pinned["config"], 1071)
             and (layer["digest"], layer["size"]) == (pinned["layer"], 38293),
             "REPORTED_DESCRIPTOR_MISMATCH")
    config_body, cfg = read_blob(repo, token, config, "config.json")
    chart_config = json.loads(config_body)
    need(chart_config.get("name") == repo and chart_config.get("version") == TAG, "CONFIG_CHART_IDENTITY")
    _, tgz = read_blob(repo, token, layer, "published.tgz")
    return {"oci_raw_integrity": "PASS", "tag_binding": "PASS", "manifest": manifest,
            "config_descriptor": config, "chart_descriptor": layer, "config": cfg, "archive": tgz,
            "referrers": referrers(repo, token, manifest["digest"])}


def image(token):
    repo = "controller"
    # Use the fixed index rather than repeat the previous rate-limited tag URL.
    body, index = oci(repo, "manifests", C["index"], "pinned.json", token, INDEX)
    data = document(body, index, INDEX)
    selected = [row for row in data["manifests"]
                if (row.get("platform", {}).get("os"), row.get("platform", {}).get("architecture"))
                == ("linux", "amd64")]
    need(len(selected) == 1, "AMD64_DESCRIPTOR_NOT_UNIQUE")
    desc = descriptor(selected[0], MANIFEST)
    need(desc["digest"] == C["amd64"], "REPORTED_CHILD_DIGEST_MISMATCH")
    child, child_receipt = oci(repo, "manifests", desc["digest"], "amd64.json", token, MANIFEST)
    nested = document(child, child_receipt, MANIFEST)
    need(len(child) == desc["size"] and child_receipt["content_type"] == desc["mediaType"], "CHILD_SIZE_OR_TYPE")
    config = descriptor(nested["config"], IMAGE_CONFIG)
    config_body, cfg = read_blob(repo, token, config, "config.json")
    settings = json.loads(config_body)
    need((settings.get("os"), settings.get("architecture")) == ("linux", "amd64"), "CONFIG_PLATFORM")
    layers = [descriptor(d, LAYER_TYPES) for d in nested["layers"]]
    index_descriptors = [
        {**descriptor(row, MANIFEST | INDEX), "platform": row.get("platform")}
        for row in data["manifests"]
    ]
    return {"descriptor_integrity": "PASS", "tag_binding": "NOT_TESTED_TAG_HTTP_429", "index": index,
            "index_descriptors": index_descriptors, "amd64_descriptor": {**desc, "platform": selected[0]["platform"]},
            "amd64_manifest": child_receipt, "config_descriptor": config, "config": cfg,
            "config_platform": {"os": settings["os"], "architecture": settings["architecture"]},
            "layers": layers, "layer_bytes": "NOT_TESTED_NOT_FETCHED",
            "referrers": {"index": referrers(repo, token, index["digest"]),
                          "amd64": referrers(repo, token, desc["digest"])}}


def main():
    RAW.mkdir(exist_ok=True)
    prior = Path("acquisition-results.json")
    if prior.exists():
        RECEIPTS.extend(json.loads(prior.read_bytes())["http_receipts"])
    body, receipt = fetch(RELEASE, "github-release.json", "application/vnd.github+json")
    release = {"status": "UNAVAILABLE", "receipt": receipt}
    if body is not None:
        data = json.loads(body)
        if data.get("tag_name") == "v1.15.2" and data.get("draft") is False:
            release = {"status": "UPSTREAM_RELEASE_METADATA_MEASURED", "receipt": receipt,
                       **{k: data.get(k) for k in ("tag_name", "published_at", "html_url", "prerelease")},
                       "assets": [asset["name"] for asset in data["assets"]]}
    outputs = {}
    try:
        token = public_session("registry")
    except (Unavailable, ValueError, KeyError, TypeError, subprocess.TimeoutExpired):
        token = None
    for label, repo in (("A", "karpenter"), ("B", "karpenter-crd"), ("C", "controller")):
        if token is None:
            outputs[label] = {"status": "BLOCKED", "reason": "PUBLIC_REGISTRY_SESSION_UNAVAILABLE"}
            continue
        try:
            outputs[label] = image(token) if label == "C" else chart(repo, token, A if label == "A" else {})
        except Unavailable as exc:
            outputs[label] = {"status": "HOLD", "reason": str(exc)}
        except (ValueError, KeyError, TypeError, AttributeError, subprocess.TimeoutExpired):
            outputs[label] = {"status": "HOLD", "reason": "MALFORMED_OR_UNAVAILABLE_RESPONSE"}
    write_json("acquisition-results.json", {"tracks": outputs, "release": release, "http_receipts": RECEIPTS})


if __name__ == "__main__":
    main()
