"""Offline inspection of the retained chart archives. This code does not render Helm templates."""

import gzip
import io
import json
from pathlib import Path, PurePosixPath
import re
import tarfile

import yaml

from acquire import TAG, Unavailable, need, sha, write_json

MAX_UNCOMPRESSED = 8 * 1024 * 1024
ANNOTATION_BLOCK = (
    "    {{- with .Values.additionalAnnotations }}\n"
    "      {{- toYaml . | nindent 4 }}\n"
    "    {{- end }}\n"
)


class UniqueSafeLoader(yaml.SafeLoader):
    def construct_mapping(self, node, deep=False):
        self.flatten_mapping(node)
        mapping = {}
        for key_node, value_node in node.value:
            key = self.construct_object(key_node, deep=deep)
            need(key not in mapping, "YAML_DUPLICATE_KEY")
            mapping[key] = self.construct_object(value_node, deep=deep)
        return mapping


def definition(data):
    return yaml.load(data, Loader=UniqueSafeLoader)


def archive_members(data, root):
    with gzip.GzipFile(fileobj=io.BytesIO(data)) as stream:
        contents = stream.read(MAX_UNCOMPRESSED + 1)
    need(len(contents) <= MAX_UNCOMPRESSED, "ARCHIVE_UNCOMPRESSED_LIMIT")
    files, directories = {}, set()
    with tarfile.open(fileobj=io.BytesIO(contents), mode="r:") as archive:
        for member in archive:
            name = member.name
            path = PurePosixPath(name)
            need(path.parts and path.parts[0] == root and not path.is_absolute()
                 and ".." not in path.parts and str(path) == name
                 and not re.search(r"[\\\x00-\x1f]", name), "ARCHIVE_UNSAFE_PATH")
            need(name not in files and name not in directories, "ARCHIVE_DUPLICATE_MEMBER")
            need(member.isfile() or member.isdir(), "ARCHIVE_LINK_OR_SPECIAL")
            if member.isdir():
                directories.add(name)
            else:
                stream = archive.extractfile(member)
                need(stream is not None, "ARCHIVE_MISSING_MEMBER")
                files[name] = stream.read()
    need(not any(p.as_posix() in files for name in (*files, *directories)
                 for p in PurePosixPath(name).parents), "ARCHIVE_FILE_DIRECTORY_COLLISION")
    return files, sorted(directories)


def inspect_crd(data, path, template):
    source = data.decode("utf-8")
    removed = template and ANNOTATION_BLOCK in source
    if removed:
        need(source.count(ANNOTATION_BLOCK) == 1, "CRD_ANNOTATIONS_TEMPLATE_COUNT")
        source = source.replace(ANNOTATION_BLOCK, "", 1)
    need("{{" not in source and "{%" not in source, "UNRESOLVED_TEMPLATE_REMAINS")
    d = definition(source)
    need(d["apiVersion"] == "apiextensions.k8s.io/v1" and d["kind"] == "CustomResourceDefinition",
         "NOT_A_V1_CRD")
    spec = d["spec"]
    group = spec["group"]
    names = spec["names"]
    name = d["metadata"]["name"]
    need(name == names["plural"] + "." + group, "CRD_NAME_MISMATCH")
    versions = [{k: row[k] for k in ("name", "served", "storage")} for row in spec["versions"]]
    need(len(versions) == len({v["name"] for v in versions})
         and all(type(v["served"]) is bool and type(v["storage"]) is bool for v in versions)
         and sum(v["storage"] for v in versions) == 1, "CRD_INVALID_STORAGE_OR_VERSION")
    conversion = spec.get("conversion")
    mode = "IMPLICIT_NONE_BY_STATIC_SPEC" if conversion is None else "EXPLICIT_CONFIGURATION"
    return {
        "path": path, "raw_member_sha256": sha(data), "crd_name": name, "group": group,
        "kind": names["kind"], "scope": spec["scope"], "versions": versions,
        "conversion": conversion, "conversion_mode": mode,
        "static_template_handling": "REMOVED_EXACT_METADATA_ANNOTATION_BLOCK" if removed else "PLAIN_YAML",
        # Helps compare full spec without redistributing its source.
        "spec_sha256": sha(json.dumps(spec, sort_keys=True, separators=(",", ":")).encode()),
    }


def inspect_chart(repo, raw_receipt):
    archive = Path(raw_receipt["archive"]["path"])
    body = archive.read_bytes()
    need(sha(body) == raw_receipt["chart_descriptor"]["digest"]
         and len(body) == raw_receipt["chart_descriptor"]["size"], "CHART_BYTES_CHANGED")
    files, dirs = archive_members(body, repo)
    chart = definition(files[f"{repo}/Chart.yaml"])
    config_data = Path(raw_receipt["config"]["path"]).read_bytes()
    need(sha(config_data) == raw_receipt["config_descriptor"]["digest"]
         and len(config_data) == raw_receipt["config_descriptor"]["size"], "CONFIG_BYTES_CHANGED")
    config = json.loads(config_data)
    need((chart["name"], chart["version"], chart["appVersion"]) == (repo, TAG, TAG),
         "CHART_METADATA_IDENTITY")
    need(all(chart[k] == config[k] for k in ("name", "version", "appVersion")), "CONFIG_CHART_VERSION")
    declared = chart.get("dependencies", [])
    need(isinstance(declared, list), "DEPENDENCY_FORMAT")
    dependencies = [{k: d[k] for k in ("name", "version", "repository", "condition", "alias") if k in d}
                    for d in declared]
    candidates = [p for p in files if p.startswith(f"{repo}/crds/") or
                  (repo == "karpenter-crd" and p.startswith(f"{repo}/templates/")
                   and re.search(r"/(?:karpenter\.|karpenter\.k8s\.aws_|autoscaling\.x-k8s\.io_)", p))]
    static = [inspect_crd(files[path], path, "/templates/" in path) for path in sorted(candidates)
              if path.endswith((".yaml", ".yml"))]
    need(len(static) == len({row["crd_name"] for row in static}), "CRD_DUPLICATE_NAME")
    legal = {k: [p for p in files if PurePosixPath(p).name.casefold().startswith(k)]
             for k in ("license", "licence", "notice", "copying")}
    image = None
    if repo == "karpenter":
        values = definition(files[f"{repo}/values.yaml"])
        defaults = values["controller"]["image"]
        image = {k: defaults[k] for k in ("repository", "tag", "digest")}
    bundled = sorted(p for p in files if p.startswith(f"{repo}/charts/"))
    return {
        "archive_integrity": "PASS", "identity": {k: chart[k] for k in ("name", "version", "appVersion")},
        "regular_files": len(files), "directories": dirs,
        "members": [{"path": k, "size_bytes": len(v), "sha256": sha(v)} for k, v in sorted(files.items())],
        "dependencies_declared": dependencies, "bundled_chart_members": bundled,
        "chart_lock_present": f"{repo}/Chart.lock" in files,
        "dependency_inventory": ("NO_DECLARED_OR_BUNDLED_SUBCHARTS" if not dependencies and not bundled
                                 else "DOCUMENTED_STATIC_ONLY"),
        "dependency_closure": "NOT_TESTED_EFFECTIVE_RENDER_RUNTIME",
        "license_notice_inventory": legal,
        "license": "ARCHIVE_LICENSE_NOTICE_NOT_PRESENT" if not any(legal.values()) else "ARCHIVE_FILES_PRESENT",
        "controller_image_values": image, "crds": static,
    }


def guard_tests():
    def payload(names):
        out = io.BytesIO()
        with tarfile.open(fileobj=out, mode="w:gz") as t:
            for name, kind in names:
                m = tarfile.TarInfo(name)
                m.type = kind
                m.linkname = "chart/elsewhere" if kind in (tarfile.SYMTYPE, tarfile.LNKTYPE) else ""
                t.addfile(m, io.BytesIO())
        return out.getvalue()
    tests = {
        "normal": ([("chart/Chart.yaml", tarfile.REGTYPE)], "ACCEPT"),
        "traversal": ([("chart/../outside", tarfile.REGTYPE)], "ARCHIVE_UNSAFE_PATH"),
        "duplicate": ([("chart/Chart.yaml", tarfile.REGTYPE)] * 2, "ARCHIVE_DUPLICATE_MEMBER"),
        "symlink": ([("chart/link", tarfile.SYMTYPE)], "ARCHIVE_LINK_OR_SPECIAL"),
        "hardlink": ([("chart/link", tarfile.LNKTYPE)], "ARCHIVE_LINK_OR_SPECIAL"),
    }
    out = {}
    for key, (members, expected) in tests.items():
        try:
            archive_members(payload(members), "chart")
            actual = "ACCEPT"
        except Unavailable as error:
            actual = str(error)
        out[key] = {"expected": expected, "actual": actual, "match": expected == actual}
    need(all(row["match"] for row in out.values()), "OFFLINE_GUARD_FIXTURE_FAILURE")
    return out


def main():
    acq = json.loads(Path("acquisition-results.json").read_bytes())["tracks"]
    charts = {}
    for label, repo in (("A", "karpenter"), ("B", "karpenter-crd")):
        if acq[label].get("oci_raw_integrity") != "PASS":
            charts[label] = {"archive_integrity": "NOT_TESTED"}
            continue
        try:
            charts[label] = inspect_chart(repo, acq[label])
        except (Unavailable, yaml.YAMLError, KeyError, TypeError, ValueError) as exc:
            charts[label] = {"archive_integrity": "HOLD", "reason": str(exc) if isinstance(exc, Unavailable)
                             else type(exc).__name__}
    matrix = []
    if all(chart["archive_integrity"] == "PASS" for chart in charts.values()):
        by_chart = {key: {row["crd_name"]: row for row in chart["crds"]} for key, chart in charts.items()}
        for name in sorted(by_chart["A"].keys() | by_chart["B"].keys()):
            a, b = (by_chart[k].get(name) for k in ("A", "B"))
            matrix.append({
                "crd_name": name, "controller_chart_path": a["path"] if a else None,
                "crd_chart_path": b["path"] if b else None,
                "static_overlap": a is not None and b is not None,
                "same_static_spec_sha256": a["spec_sha256"] == b["spec_sha256"] if a and b else None,
                "single_writer_acceptance": "OPEN_NEEDS_EFFECTIVE_INSTALL_INVENTORY" if a and b else "NOT_TESTED",
            })
    write_json("chart-static-inventory.json", {
        "scope": "STATIC_ARCHIVE_ONLY", "charts": charts, "ownership_matrix": matrix,
        "rendered_effective_inventory": "NOT_TESTED", "guard_tests": guard_tests(),
        "controller_chart_default_vs_fixed_index": (
            charts.get("A", {}).get("controller_image_values", {}).get("digest")
            == acq["C"].get("index", {}).get("digest") if charts.get("A", {}).get("controller_image_values")
            and acq["C"].get("index") else None),
    })


if __name__ == "__main__":
    main()
